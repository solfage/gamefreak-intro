<?php
return [
    'enabled' => true,
    'mode' => 'sandbox',
    'client_id' => 'YOUR_PAYPAL_CLIENT_ID',
    'client_secret' => 'YOUR_PAYPAL_CLIENT_SECRET',
    'currency' => 'EUR',
    'brand_name' => 'GameFreak Store',
    'return_url' => 'http://localhost/gamefreak_store_v5_billing_profile_configurable/paypal_return.php',
    'cancel_url' => 'http://localhost/gamefreak_store_v5_billing_profile_configurable/checkout.php',
];
