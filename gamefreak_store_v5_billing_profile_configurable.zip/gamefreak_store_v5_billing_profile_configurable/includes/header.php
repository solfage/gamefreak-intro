<?php
if(session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__.'/functions.php';
if(!isset($_SESSION['cart'])) $_SESSION['cart']=[];
if(!isset($_SESSION['wishlist'])) $_SESSION['wishlist']=[];
$pageTitle=$pageTitle ?? 'GameFreak Store';
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?></title>
<link rel="stylesheet" href="assets/style.css">
</head><body><header class="topbar"><div class="container nav-wrap">
<a href="index.php" class="logo">GAME<span>FREAK</span></a>
<nav class="nav">
<a href="index.php">Home</a><a href="products.php">Products</a>
<?php if(isLoggedIn()): ?><a href="profile.php">Profile</a><?php endif; ?>
<a href="wishlist.php">Wishlist (<?= wishlistCount() ?>)</a><a href="cart.php">Cart (<?= cartCount() ?>)</a>
<?php if(isLoggedIn()): ?><a href="logout.php">Logout</a><?php else: ?><a href="login.php">Login</a><a href="register.php">Register</a><?php endif; ?>
<?php if(isAdmin()): ?><a href="admin/products.php">Admin</a><?php endif; ?>
</nav></div></header><main>
