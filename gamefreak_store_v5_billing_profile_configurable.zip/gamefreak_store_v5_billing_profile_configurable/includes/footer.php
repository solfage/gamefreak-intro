</main><footer class="footer"><div class="container">© GameFreak Store</div></footer><script src="assets/app.js"></script></body></html>
