<?php
function e(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
function isLoggedIn(): bool { return !empty($_SESSION['user']); }
function isAdmin(): bool { return !empty($_SESSION['user']) && (($_SESSION['user']['role'] ?? '')==='admin'); }
function cartCount(): int { return empty($_SESSION['cart']) ? 0 : array_sum($_SESSION['cart']); }
function wishlistCount(): int { return empty($_SESSION['wishlist']) ? 0 : count($_SESSION['wishlist']); }
function formatPrice(float $p): string { return '€'.number_format($p,2); }
function redirect(string $p): void { header("Location: $p"); exit; }
