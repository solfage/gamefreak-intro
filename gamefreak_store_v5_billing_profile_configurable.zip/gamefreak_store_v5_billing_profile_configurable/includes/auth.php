<?php
if(session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__.'/functions.php';
if(!isAdmin()){ header('Location: ../login.php'); exit; }
