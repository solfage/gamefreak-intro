document.querySelectorAll('[data-qty-minus]').forEach(b=>b.addEventListener('click',()=>{const i=b.parentElement.querySelector('input');i.value=Math.max(1,(parseInt(i.value||'1',10)-1));}));
document.querySelectorAll('[data-qty-plus]').forEach(b=>b.addEventListener('click',()=>{const i=b.parentElement.querySelector('input');i.value=Math.max(1,(parseInt(i.value||'1',10)+1));}));
