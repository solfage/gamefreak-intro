<?php
class PayPalService {
    private array $config;
    public function __construct(array $config) { $this->config = $config; }
    public function createCheckoutPlaceholder(int $orderId, float $total): array {
        return [
            'order_id' => $orderId,
            'status' => 'created',
            'provider' => 'paypal',
            'mode' => $this->config['mode'] ?? 'sandbox',
            'currency' => $this->config['currency'] ?? 'EUR',
            'redirect_url' => ($this->config['return_url'] ?? '') . '?order_id=' . $orderId . '&paypal=1',
            'amount' => $total,
        ];
    }
}
