<?php
require 'config/db.php'; require 'services/paypal_service.php'; $paypalConfig=require 'config/paypal.php'; $paypalService=new PayPalService($paypalConfig); include 'includes/header.php';
$userData=null; if(isLoggedIn()){ $uStmt=$pdo->prepare("SELECT * FROM users WHERE id=? LIMIT 1"); $uStmt->execute([(int)$_SESSION['user']['id']]); $userData=$uStmt->fetch(); }
$error=''; $total=99.99;
if($_SERVER['REQUEST_METHOD']==='POST'){
    $fullName=trim($_POST['full_name'] ?? ''); $email=trim($_POST['email'] ?? ''); $address=trim($_POST['address_line'] ?? ''); $city=trim($_POST['city'] ?? ''); $postalCode=trim($_POST['postal_code'] ?? ''); $paymentMethod=trim($_POST['payment_method'] ?? 'card');
    if($fullName===''||$email===''||$address===''||$city===''||$postalCode===''){ $error='Please complete all checkout fields.'; }
    else{
        $status=$paymentMethod==='paypal' ? 'pending' : 'paid'; $userId=$_SESSION['user']['id'] ?? null;
        $stmt=$pdo->prepare('INSERT INTO orders (user_id, full_name, email, address_line, city, postal_code, total, payment_method, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$userId,$fullName,$email,$address,$city,$postalCode,$total,$paymentMethod,$status]); $orderId=$pdo->lastInsertId();
        if($paymentMethod==='paypal'){ $checkout=$paypalService->createCheckoutPlaceholder((int)$orderId, (float)$total); redirect($checkout['redirect_url']); }
        redirect('order_success.php?id='.$orderId);
    }
}
?><section class="section"><div class="container"><h1>Checkout</h1><div class="checkout-layout"><div class="form-box"><?php if($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?><form method="post" class="form-grid two-col"><input class="input" type="text" name="full_name" value="<?= e($userData['name'] ?? '') ?>" placeholder="Full Name" required><input class="input" type="email" name="email" value="<?= e($userData['email'] ?? '') ?>" placeholder="Email" required><input class="input" type="text" name="address_line" value="<?= e($userData['billing_address'] ?? '') ?>" placeholder="Address" required><input class="input" type="text" name="city" value="<?= e($userData['billing_city'] ?? '') ?>" placeholder="City" required><input class="input" type="text" name="postal_code" value="<?= e($userData['billing_postal_code'] ?? '') ?>" placeholder="Postal Code" required><select class="input" name="payment_method" required><option value="card">Card Checkout</option><option value="paypal">PayPal</option></select><button class="btn primary" type="submit">Place Order</button></form></div><div class="summary-box"><h2>Summary</h2><p class="price">Total: €99.99</p></div></div></div></section><?php include 'includes/footer.php'; ?>
