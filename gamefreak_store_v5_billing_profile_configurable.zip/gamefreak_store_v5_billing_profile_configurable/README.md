# GameFreak Store v5 ENTERPRISE - Billing Profile Configurable

Includes:
- configurable billing information in profile
- checkout auto-fills billing fields from profile
- configurable PayPal settings in config/paypal.php
- PayPal service placeholder wrapper
- admin product delete
