<?php
// Sample plugin entry file.
