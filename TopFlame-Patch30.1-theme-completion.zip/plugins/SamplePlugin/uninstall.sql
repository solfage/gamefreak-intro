DROP TABLE IF EXISTS sample_plugin_data;
