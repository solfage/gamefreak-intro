ALTER TABLE sample_plugin_data ADD COLUMN notes TEXT NULL;
