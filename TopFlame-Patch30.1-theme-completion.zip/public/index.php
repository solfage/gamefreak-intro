<?php

declare(strict_types=1);

require dirname(__DIR__) . '/bootstrap.php';

$router = new Router();

$router->get('/', [HomeController::class, 'index']);
$router->get('/servers', [ServerController::class, 'index']);
$router->get('/server', [ServerController::class, 'show']);
$router->get('/vote-gateway', [ServerController::class, 'voteGateway']);
$router->post('/vote', [ServerController::class, 'vote']);

$router->get('/login', [AuthController::class, 'loginForm']);
$router->post('/login', [AuthController::class, 'login']);
$router->get('/register', [AuthController::class, 'registerForm']);
$router->post('/register', [AuthController::class, 'register']);
$router->post('/logout', [AuthController::class, 'logout']);

$router->get('/dashboard', [DashboardController::class, 'user']);
$router->get('/dashboard/my-servers', [DashboardController::class, 'userServers']);
$router->get('/dashboard/banner-codes', [DashboardController::class, 'userBannerCodes']);
$router->get('/dashboard/servers/create', [ServerController::class, 'createForm']);
$router->post('/dashboard/servers/create', [ServerController::class, 'create']);
$router->get('/dashboard/servers/edit', [ServerController::class, 'editForm']);
$router->post('/dashboard/servers/update', [ServerController::class, 'update']);

$router->get('/admin', [DashboardController::class, 'admin']);
$router->get('/admin/servers', [DashboardController::class, 'adminServers']);
$router->get('/admin/premium', [DashboardController::class, 'adminPremium']);
$router->get('/admin/users', [DashboardController::class, 'adminUsers']);
$router->get('/admin/banners', [DashboardController::class, 'adminBanners']);
$router->get('/admin/plugins', [DashboardController::class, 'adminPlugins']);
$router->get('/admin/updater', [DashboardController::class, 'adminUpdater']);
$router->post('/admin/plugins/upload', [DashboardController::class, 'uploadPlugin']);
$router->post('/admin/banners/upload', [DashboardController::class, 'adminBannerUpload']);
$router->post('/admin/banners/delete', [DashboardController::class, 'adminBannerDelete']);
$router->post('/admin/plugins/toggle', [DashboardController::class, 'toggleModule']);
$router->post('/admin/plugins/uninstall', [DashboardController::class, 'uninstallPlugin']);
$router->post('/admin/updater/upload', [DashboardController::class, 'uploadCoreUpdate']);
$router->get('/admin/logs', [DashboardController::class, 'adminLogs']);
$router->post('/admin/servers/approve', [DashboardController::class, 'approveServer']);
$router->post('/admin/servers/reject', [DashboardController::class, 'rejectServer']);
$router->post('/admin/servers/disable', [DashboardController::class, 'disableServer']);
$router->post('/admin/servers/premium', [DashboardController::class, 'updatePremium']);
$router->post('/admin/servers/delete', [DashboardController::class, 'deleteServer']);

$router->get('/admin/themes', static function (): void {
    requireAdmin();
    ensureThemesTable();
    syncThemesRegistry();
    $themes = db()->select("SELECT * FROM themes ORDER BY is_active DESC, name ASC");
    view('dashboard/themes', compact('themes'));
});

$router->post('/admin/themes/upload', static function (): void {
    requireAdmin();
    verifyCsrf();

    try {
        if (!isset($_FILES['theme_zip']) || !is_array($_FILES['theme_zip'])) {
            throw new RuntimeException('No theme ZIP file was uploaded.');
        }

        installUploadedThemeZip($_FILES['theme_zip']);
        $_SESSION['flash'] = 'Theme uploaded successfully.';
    } catch (Throwable $e) {
        $_SESSION['flash'] = 'Theme upload failed: ' . $e->getMessage();
    }

    redirect('/admin/themes');
});

$router->post('/admin/themes/activate', static function (): void {
    requireAdmin();
    verifyCsrf();

    $themeKey = trim((string) ($_POST['theme_key'] ?? ''));
    if ($themeKey === '') {
        $_SESSION['flash'] = 'Invalid theme.';
        redirect('/admin/themes');
    }

    try {
        setActiveTheme($themeKey);
        $_SESSION['flash'] = 'Theme activated successfully.';
    } catch (Throwable $e) {
        $_SESSION['flash'] = 'Theme activation failed: ' . $e->getMessage();
    }

    redirect('/admin/themes');
});

$router->dispatch($_SERVER['REQUEST_URI'] ?? '/', $_SERVER['REQUEST_METHOD'] ?? 'GET');
