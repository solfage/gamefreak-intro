<section class="hero">
    <div class="hero-shell theme-spotlight">
        <div class="theme-hero-grid">
            <div>
                <div class="badge badge-premium">Default Advanced Theme</div>
                <h1 class="title"><span class="gold">TopFlame</span> now ships with a real built-in advanced layout, not only fallback hooks.</h1>
                <p class="subtitle">Το homepage χρησιμοποιεί πλέον δικό του theme structure, δικό του spotlight section και καλύτερο visual hierarchy ώστε το theme engine να φαίνεται ολοκληρωμένο και όχι μισό.</p>
                <div class="action-row" style="margin-top:22px">
                    <a class="btn" href="/servers">Browse rankings</a>
                    <a class="btn-secondary" href="/dashboard/servers/create">Submit your server</a>
                </div>
                <div class="theme-kpi-grid" style="margin-top:22px">
                    <div class="theme-kpi"><span class="muted">Top ranked</span><strong><?= count($topServers) ?></strong></div>
                    <div class="theme-kpi"><span class="muted">Premium</span><strong><?= count($premiumServers) ?></strong></div>
                    <div class="theme-kpi"><span class="muted">Latest approved</span><strong><?= count($latestServers) ?></strong></div>
                    <div class="theme-kpi"><span class="muted">System state</span><strong>Ready</strong></div>
                </div>
            </div>
            <div class="theme-panel">
                <h3 style="margin-top:0">What this theme now proves</h3>
                <ul class="theme-list">
                    <li>Dedicated header and footer layouts</li>
                    <li>Custom homepage and server browsing views</li>
                    <li>Real auth and dashboard overrides</li>
                    <li>Preview image + richer metadata for admin theme manager</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="theme-section-grid">
        <div class="card">
            <div class="section-header">
                <div>
                    <h2>Featured premium servers</h2>
                    <p>Premium entries get a stronger visual block inside the built-in advanced theme.</p>
                </div>
                <a class="btn-secondary" href="/servers?premium=1">Premium list</a>
            </div>
            <div class="grid grid-2">
                <?php foreach ($premiumServers as $server): ?>
                    <div class="card premium server-card">
                        <div class="server-top">
                            <div>
                                <div class="badge badge-premium">Premium</div>
                                <h3 class="server-title"><?= e($server['title']) ?></h3>
                            </div>
                            <div class="mini-icon">🔥</div>
                        </div>
                        <p class="server-sub"><?= e($server['short_description']) ?></p>
                        <div class="theme-mini-grid">
                            <div class="theme-mini-box"><span class="k">Chronicle</span><span class="v"><?= e($server['chronicle']) ?></span></div>
                            <div class="theme-mini-box"><span class="k">Votes</span><span class="v"><?= e((string) (($server['raw_votes_total'] ?? 0) ?? 0)) ?></span></div>
                        </div>
                        <div class="action-row"><a class="btn" href="/server?id=<?= (int) $server['id'] ?>">Open server</a></div>
                    </div>
                <?php endforeach; ?>
                <?php if (!$premiumServers): ?>
                    <div class="empty-state">No premium servers are live yet.</div>
                <?php endif; ?>
            </div>
        </div>
        <div class="theme-cover">
            <div class="badge">Portal positioning</div>
            <h2 style="margin:0">A cleaner premium-ready listing experience</h2>
            <p class="muted" style="margin:0">The built-in default theme now demonstrates full layout support with dedicated sections, stronger admin preview readiness, and a more believable production baseline.</p>
            <div class="cover-banner">
                <div class="stats-inline">
                    <span class="pill">Installer included</span>
                    <span class="pill">Theme upload ready</span>
                    <span class="pill">Vote gateway flow</span>
                    <span class="pill">Admin moderation</span>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="section-header">
        <div>
            <h2>Top ranked servers</h2>
            <p>The ranking table remains compact but now sits inside the advanced theme shell.</p>
        </div>
    </div>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>#</th><th>Server</th><th>Chronicle</th><th>Votes</th><th>Score</th></tr></thead>
            <tbody>
            <?php foreach ($topServers as $i => $server): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><a href="/server?id=<?= (int) $server['id'] ?>"><?= e($server['title']) ?></a><?php if ((int) $server['is_premium'] === 1): ?> <span class="badge badge-premium">Premium</span><?php endif; ?></td>
                    <td><?= e($server['chronicle']) ?></td>
                    <td><?= e((string) (($server['raw_votes_total'] ?? 0) ?? 0)) ?></td>
                    <td><?= e((string) (($server['ranking_score'] ?? 0) ?? 0)) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$topServers): ?><tr><td colspan="5">Δεν υπάρχουν ακόμη καταχωρήσεις.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
