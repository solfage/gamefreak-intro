</main>
    <footer class="footer">
        <div class="container theme-footer-grid">
            <div class="theme-footer-box">
                <div class="brand" style="font-size:18px"><?= e(config('app.name', 'TopFlame')) ?></div>
                <p class="muted" style="margin:10px 0 0;max-width:560px">Advanced built-in theme with full layout hooks, protected fallback rendering, and a clearer premium/fantasy visual direction for the Lineage 2 ranking portal.</p>
            </div>
            <div class="theme-footer-box">
                <h3 style="margin:0 0 10px">Navigation</h3>
                <ul class="list-clean">
                    <li><a href="/">Home</a></li>
                    <li><a href="/servers">Server Rankings</a></li>
                    <li><a href="/register">Create Account</a></li>
                </ul>
            </div>
            <div class="theme-footer-box">
                <h3 style="margin:0 0 10px">Theme Support</h3>
                <ul class="list-clean">
                    <li>Custom header / footer</li>
                    <li>Safe page override fallback</li>
                    <li>Preview-ready admin theme manager</li>
                </ul>
            </div>
        </div>
    </footer>
</body>
</html>
