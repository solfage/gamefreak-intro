<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e(config('app.name', 'TopFlame')) ?> · Default Advanced</title>
    <style>
        :root{
            --bg:#060912;--bg-soft:#0b1020;--panel:#101728;--text:#eef4ff;--muted:#93a2c5;--line:rgba(92,225,255,.14);--gold: #ffcc66;--cyan:#5ce1ff;--violet:#ad7bff;--danger:#ff7b7b;--radius:22px;--shadow:0 24px 80px rgba(0,0,0,.34);
        }
        *{box-sizing:border-box} html{scroll-behavior:smooth} body{margin:0;font-family:Inter,Segoe UI,Arial,sans-serif;color:var(--text);background:radial-gradient(circle at top left, rgba(92,225,255,.08), transparent 24%),radial-gradient(circle at top right, rgba(255,204,102,.08), transparent 28%),linear-gradient(180deg, #080b14, #060912 56%, #05070d);min-height:100vh} a{color:var(--cyan);text-decoration:none} img{max-width:100%}
        .container{width:min(1240px,92%);margin:0 auto}.nav{position:sticky;top:0;z-index:50;background:rgba(6,9,18,.78);backdrop-filter:blur(14px);border-bottom:1px solid var(--line)}.nav-inner{display:flex;justify-content:space-between;align-items:center;gap:18px;padding:14px 0;flex-wrap:wrap}.brand-wrap{display:flex;align-items:center;gap:14px}.brand-badge{width:42px;height:42px;border-radius:14px;border:1px solid rgba(255,204,102,.25);background:linear-gradient(180deg, rgba(255,204,102,.24), rgba(92,225,255,.14));box-shadow:0 0 24px rgba(255,204,102,.12)}.brand{font-size:20px;font-weight:900;letter-spacing:.14em;text-transform:uppercase}.brand-sub{font-size:11px;letter-spacing:.20em;text-transform:uppercase;color:var(--muted)}
        .menu{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.nav-link,.btn,.btn-secondary,.btn-danger{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:44px;padding:11px 16px;border-radius:14px;font-weight:700;transition:.16s ease;border:1px solid transparent}.nav-link{color:#dfe8ff}.nav-link:hover,.btn:hover,.btn-secondary:hover,.btn-danger:hover{transform:translateY(-1px)}.nav-link:hover{border-color:var(--line);background:rgba(255,255,255,.03)}.btn{border-color:rgba(255,204,102,.26);background:linear-gradient(180deg, rgba(255,204,102,.24), rgba(255,124,77,.16));color:#fff;box-shadow:0 0 20px rgba(255,204,102,.12)}.btn-secondary{border-color:var(--line);background:linear-gradient(180deg, rgba(92,225,255,.10), rgba(173,123,255,.08));color:#eef5ff}.btn-danger{border-color:rgba(255,123,123,.24);background:linear-gradient(180deg, rgba(255,123,123,.18), rgba(255,90,217,.12));color:#fff}
        .hero{padding:58px 0 24px}.hero-shell,.card,.stat-card,.feature-card,.table-wrap{border-radius:28px;border:1px solid rgba(255,255,255,.06);background:linear-gradient(180deg, rgba(16,23,40,.94), rgba(8,12,22,.94));box-shadow:var(--shadow)}.hero-shell{padding:34px;overflow:hidden;position:relative}.title{font-size:clamp(34px,5vw,58px);line-height:1.02;margin:0 0 14px;font-weight:900}.title .gold{color:var(--gold)}.subtitle,.muted{color:var(--muted)}.section{padding:18px 0 34px}.section-header{display:flex;justify-content:space-between;align-items:end;gap:16px;flex-wrap:wrap;margin-bottom:18px}.section-header h2,.card h2,.card h3{margin:0 0 8px}.section-header p{margin:0;color:var(--muted)}
        .grid{display:grid;gap:18px}.grid-2{grid-template-columns:repeat(auto-fit,minmax(280px,1fr))}.grid-3{grid-template-columns:repeat(auto-fit,minmax(250px,1fr))}.grid-4{grid-template-columns:repeat(auto-fit,minmax(200px,1fr))}.card,.stat-card,.feature-card{padding:20px}.feature-icon,.mini-icon{display:inline-flex;align-items:center;justify-content:center;width:52px;height:52px;border-radius:16px;border:1px solid var(--line);background:linear-gradient(180deg, rgba(92,225,255,.10), rgba(173,123,255,.08))}.mini-icon{width:38px;height:38px;font-size:16px}.stat-card .rank{font-size:34px;font-weight:900}.badge,.pill,.status-badge,.listing-badge{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border-radius:999px;border:1px solid var(--line);background:rgba(255,255,255,.03);font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}.badge-premium{border-color:rgba(255,204,102,.28);background:rgba(255,204,102,.08);color:#ffe7b5}.status-approved{border-color:rgba(91,255,158,.24);background:rgba(91,255,158,.08);color:#d6ffe6}.status-pending{border-color:rgba(255,204,102,.28);background:rgba(255,204,102,.08);color:#ffe9bc}.status-disabled,.status-rejected{border-color:rgba(255,123,123,.24);background:rgba(255,123,123,.08);color:#ffd5d5}
        .flash{padding:14px 16px;margin:20px 0;border-radius:16px;border:1px solid rgba(91,255,158,.24);background:rgba(91,255,158,.08)}.action-row,.stats-inline,.pill-row,.tag-row,.toolbar,.links-grid,.meta-grid,.badge-tag-row,.listing-badge-row{display:flex;gap:12px;flex-wrap:wrap}.stack{display:grid;gap:18px}.server-card{position:relative;overflow:hidden;display:flex;flex-direction:column;gap:14px}.server-top{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}.server-title{font-size:24px;font-weight:800;margin:0}.server-sub{margin:0;color:var(--muted);line-height:1.6}.stats-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.stat-box,.link-tile,.theme-mini-box{padding:14px;border-radius:16px;border:1px solid rgba(255,255,255,.05);background:rgba(255,255,255,.03)}.stat-box strong{display:block;font-size:22px;margin-top:6px}.table-wrap{overflow:hidden}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:14px 16px;border-bottom:1px solid rgba(255,255,255,.06);text-align:left;vertical-align:top}.table th{font-size:12px;letter-spacing:.10em;text-transform:uppercase;color:#d1ddf5;background:rgba(255,255,255,.02)}.table tr:last-child td{border-bottom:none}
        input,textarea,select{width:100%;padding:13px 14px;border-radius:14px;border:1px solid var(--line);background:#0c1320;color:#fff;outline:none}input:focus,textarea:focus,select:focus{border-color:rgba(92,225,255,.36);box-shadow:0 0 0 4px rgba(92,225,255,.08)}textarea{min-height:148px}.code-area{font-family:Consolas,Monaco,"Courier New",monospace;font-size:13px;line-height:1.5}label{display:block;margin:0 0 8px;font-size:13px;color:#dfe8ff;font-weight:700}.form-group{margin-bottom:16px}.form-note{font-size:13px;color:var(--muted)}
        .admin-shell{display:grid;grid-template-columns:280px minmax(0,1fr);gap:22px;align-items:start}.admin-side{position:sticky;top:100px}.admin-main{min-width:0}.admin-nav{display:flex;flex-direction:column;gap:10px;margin-top:14px}.admin-nav-link{display:block;padding:12px 14px;border-radius:14px;border:1px solid var(--line);background:rgba(255,255,255,.02);color:#dbe8ff}.admin-nav-link.active,.admin-nav-link:hover{background:linear-gradient(180deg, rgba(92,225,255,.12), rgba(173,123,255,.12))}.inline-form{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;align-items:center}
        .dash-shell,.user-page-shell{display:grid;gap:18px}.dash-topbar{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;flex-wrap:wrap}.user-page-shell{grid-template-columns:280px minmax(0,1fr)}.user-nav-card{display:grid;gap:10px}.user-nav-link{display:block;padding:12px 14px;border-radius:14px;border:1px solid var(--line);background:rgba(255,255,255,.02);color:#dce8ff}.user-nav-link.active,.user-nav-link:hover{background:linear-gradient(180deg, rgba(92,225,255,.12), rgba(173,123,255,.10))}.user-soft-divider{height:1px;background:rgba(255,255,255,.06);margin:18px 0}.user-stat-grid,.user-meta-grid,.user-server-stack,.theme-admin-summary{display:grid;gap:12px}.user-stat-grid{grid-template-columns:repeat(auto-fit,minmax(160px,1fr))}.user-stat-card,.user-mini-box,.empty-state-card,.user-feature-card,.user-server-card,.user-banner-item{padding:16px;border-radius:18px;border:1px solid rgba(255,255,255,.06);background:rgba(255,255,255,.03)}.user-highlight-card{border-color:rgba(255,204,102,.20)}.user-stat-card .label,.user-mini-box .k{display:block;font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}.user-stat-card .value,.user-mini-box .v{display:block;margin-top:6px;font-size:24px;font-weight:900}.user-feature-card,.user-server-top,.banner-preview-panel,.banner-code-panel{display:grid;gap:12px}.user-server-actions,.dash-topbar-actions{display:flex;gap:10px;flex-wrap:wrap}
        .footer{margin-top:36px;padding:30px 0 42px;border-top:1px solid var(--line);background:linear-gradient(180deg, transparent, rgba(255,255,255,.02))}.list-clean{list-style:none;margin:0;padding:0}.list-clean li{padding:10px 0;border-bottom:1px solid rgba(255,255,255,.06)}.list-clean li:last-child{border-bottom:none}.empty-state{padding:28px;border-radius:20px;border:1px dashed rgba(255,255,255,.12);text-align:center;color:var(--muted)}
        @media (max-width: 980px){.admin-shell,.user-page-shell{grid-template-columns:1fr}.admin-side{position:static}.inline-form{grid-template-columns:1fr 1fr}.hero-shell{padding:24px}.title{font-size:36px}}
    </style>
    <?php if (function_exists('activeThemeCssPath') && activeThemeCssPath()): ?>
        <link rel="stylesheet" href="<?= e((string) activeThemeCssPath()) ?>?v=<?= e((string) ((activeThemeRow()['version'] ?? '1.0.0'))) ?>">
    <?php endif; ?>
</head>
<?php $themeRow = function_exists('activeThemeRow') ? activeThemeRow() : null; ?>
<body class="theme-default-advanced theme-<?= e((string) ($themeRow['theme_key'] ?? 'default-advanced')) ?>">
    <nav class="nav">
        <div class="container nav-inner">
            <div class="brand-wrap">
                <div class="brand-badge"></div>
                <div>
                    <div class="brand"><?= e(config('app.name', 'TopFlame')) ?></div>
                    <div class="brand-sub">Lineage 2 ranking gateway</div>
                </div>
            </div>
            <div class="menu">
                <span class="theme-nav-accent">Advanced Theme Active</span>
                <a class="nav-link" href="/">Home</a>
                <a class="nav-link" href="/servers">Servers</a>
                <?php if (isLoggedIn()): ?>
                    <a class="nav-link" href="/dashboard">Panel</a>
                    <a class="nav-link" href="/dashboard/servers/create">Submit Server</a>
                    <?php if (isAdmin()): ?><a class="nav-link" href="/admin">Admin</a><?php endif; ?>
                    <form method="post" action="/logout" style="margin:0">
                        <?= csrfField() ?>
                        <button class="btn-secondary" type="submit">Logout</button>
                    </form>
                <?php else: ?>
                    <a class="nav-link" href="/login">Login</a>
                    <a class="btn" href="/register">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <main class="container">
        <?php if (!empty($_SESSION['flash'])): ?>
            <div class="flash"><?= e($_SESSION['flash']); unset($_SESSION['flash']); ?></div>
        <?php endif; ?>
