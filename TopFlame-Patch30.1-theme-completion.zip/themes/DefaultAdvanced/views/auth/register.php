<section class="hero">
    <div class="hero-shell theme-auth-shell">
        <div class="theme-auth-grid">
            <div class="theme-auth-side">
                <div class="badge badge-premium">New Owner Registration</div>
                <h1 class="title" style="font-size:40px">Create your <span class="gold">TopFlame</span> account</h1>
                <p class="subtitle">Create an account to submit a server, use the vote gateway, and manage your page from the owner dashboard.</p>
                <div class="theme-auth-checks">
                    <div>One account for listing and banner tools</div>
                    <div>Premium upgrades can be attached later</div>
                    <div>Admin approval flow stays separate and safe</div>
                </div>
            </div>
            <div class="card soft">
                <form method="post" action="/register">
                    <?= csrfField() ?>
                    <div class="grid grid-2">
                        <div class="form-group"><label>Username</label><input type="text" name="username" required></div>
                        <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
                    </div>
                    <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
                    <div class="action-row"><button class="btn" type="submit">Create account</button><a class="btn-secondary" href="/login">Already have account?</a></div>
                </form>
            </div>
        </div>
    </div>
</section>
