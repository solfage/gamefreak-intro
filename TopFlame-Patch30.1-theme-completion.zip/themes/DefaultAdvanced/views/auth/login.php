<section class="hero">
    <div class="hero-shell theme-auth-shell">
        <div class="theme-auth-grid">
            <div class="theme-auth-side">
                <div class="badge">Owner Access</div>
                <h1 class="title" style="font-size:40px">Sign in to manage your <span class="gold">TopFlame</span> server listings</h1>
                <p class="subtitle">The advanced theme now gives auth pages their own structure instead of only inheriting the core layout.</p>
                <div class="theme-auth-checks">
                    <div>Access your listing dashboard</div>
                    <div>Generate vote gateway banner codes</div>
                    <div>Manage premium-ready server data</div>
                </div>
            </div>
            <div class="card soft">
                <form method="post" action="/login">
                    <?= csrfField() ?>
                    <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
                    <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
                    <div class="action-row"><button class="btn" type="submit">Sign in</button><a class="btn-secondary" href="/register">Create account</a></div>
                </form>
            </div>
        </div>
    </div>
</section>
