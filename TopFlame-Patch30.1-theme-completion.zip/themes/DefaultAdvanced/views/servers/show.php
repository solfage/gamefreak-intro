<section class="hero">
    <div class="hero-shell">
        <div class="section-header" style="margin-bottom:0">
            <div>
                <div class="badge <?= (int) ($server['is_premium'] ?? 0) === 1 ? 'badge-premium' : '' ?>"><?= (int) ($server['is_premium'] ?? 0) === 1 ? 'Premium Listing' : 'Server Listing' ?></div>
                <h1 class="title" style="font-size:44px"><?= e($server['title']) ?></h1>
                <p class="subtitle"><?= e($server['short_description'] ?: 'Detailed server profile with links, rates, features, and vote gateway tools.') ?></p>
            </div>
            <div class="theme-kpi-grid" style="max-width:420px;width:100%">
                <div class="theme-kpi"><span class="muted">Votes</span><strong><?= e((string) ($server['raw_votes_total'] ?? 0)) ?></strong></div>
                <div class="theme-kpi"><span class="muted">Score</span><strong><?= e((string) ($server['ranking_score'] ?? 0)) ?></strong></div>
                <div class="theme-kpi"><span class="muted">Views</span><strong><?= e((string) ($server['views_count'] ?? 0)) ?></strong></div>
                <div class="theme-kpi"><span class="muted">Status</span><strong><?= e(ucfirst((string) ($server['status'] ?? 'approved'))) ?></strong></div>
            </div>
        </div>
    </div>
</section>
<section class="section" style="padding-top:0">
    <?php require BASE_PATH . '/app/Views/servers/show.php'; ?>
</section>
