<section class="hero">
    <div class="hero-shell">
        <div class="section-header" style="margin-bottom:0">
            <div>
                <div class="badge">Server Rankings</div>
                <h1 class="title" style="font-size:44px">Browse approved <span class="gold">Lineage 2</span> servers</h1>
                <p class="subtitle">The advanced theme now gives the server list its own page banner, stronger summary cards, and cleaner ranking presentation.</p>
            </div>
            <div class="action-row">
                <a class="btn" href="/dashboard/servers/create">Submit server</a>
                <a class="btn-secondary" href="/servers?premium=1">Premium only</a>
            </div>
        </div>
    </div>
</section>
<section class="section" style="padding-top:0">
    <div class="theme-admin-summary">
        <div class="theme-mini-box"><span class="k">Entries</span><span class="v"><?= count($servers) ?></span></div>
        <div class="theme-mini-box"><span class="k">View mode</span><span class="v"><?= !empty($_GET['premium']) ? 'Premium' : 'All' ?></span></div>
        <div class="theme-mini-box"><span class="k">Portal</span><span class="v">TopFlame</span></div>
    </div>
    <?php require BASE_PATH . '/app/Views/servers/index.php'; ?>
</section>
