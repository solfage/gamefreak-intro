<section class="hero">
    <div class="hero-shell">
        <div class="badge">Admin / Themes</div>
        <h1 class="title" style="font-size:42px">Advanced <span class="gold">Theme Engine</span></h1>
        <p class="subtitle">The built-in manager now shows preview artwork, compatibility data, support flags, and a stricter package baseline.</p>
    </div>
</section>
<section class="section" style="padding-top:0">
<?php require BASE_PATH . '/app/Views/dashboard/_admin_nav.php'; ?>
<div class="admin-main">
    <div class="theme-admin-summary">
        <div class="theme-mini-box"><span class="k">Installed themes</span><span class="v"><?= count($themes) ?></span></div>
        <div class="theme-mini-box"><span class="k">Active layouts</span><span class="v">Header / Footer</span></div>
        <div class="theme-mini-box"><span class="k">ZIP requirement</span><span class="v"><?= class_exists('ZipArchive') ? 'OK' : 'Missing' ?></span></div>
    </div>
    <div class="card" style="margin-bottom:20px">
        <div class="section-header"><div><h2>Upload Theme ZIP</h2><p>Upload a theme package with <code>theme.json</code>, <code>theme.css</code>, and a <code>views/</code> directory for layout or page overrides.</p></div></div>
        <form method="post" action="/admin/themes/upload" enctype="multipart/form-data">
            <?= csrfField() ?>
            <div class="grid grid-2">
                <div class="form-group"><label>Theme ZIP Package</label><input type="file" name="theme_zip" accept=".zip,application/zip" required></div>
                <div class="form-group"><label>Package baseline</label><div class="form-note"><strong>Required:</strong> <code>theme.json</code><br><strong>Required:</strong> <code>theme.css</code><br><strong>Required:</strong> <code>views/</code> directory<br><strong>Optional:</strong> <code>preview.png</code> and richer metadata</div></div>
            </div>
            <div style="margin-top:16px"><button class="btn" type="submit">Upload Theme</button></div>
        </form>
    </div>
    <div class="card">
        <div class="section-header"><div><h2>Installed Themes</h2><p>Each theme can now advertise preview, compatibility, and support tags.</p></div></div>
        <?php if (empty($themes)): ?>
            <div class="empty-state">No themes found. Upload a theme package first.</div>
        <?php else: ?>
            <div class="grid grid-2">
                <?php foreach ($themes as $theme): ?>
                    <?php $supports = json_decode((string) ($theme['supports_json'] ?? '[]'), true) ?: []; ?>
                    <div class="card theme-preview-card" style="padding:18px;border:1px solid rgba(255,204,102,.14);background:linear-gradient(180deg, rgba(16,23,38,.92), rgba(8,12,22,.92));">
                        <div class="section-header">
                            <div>
                                <div class="badge-tag-row" style="margin:0 0 8px 0"><?php if ((int) ($theme['is_active'] ?? 0) === 1): ?><span class="status-badge status-approved">Active</span><?php else: ?><span class="pill">Inactive</span><?php endif; ?><span class="pill"><?= e((string) ($theme['version'] ?? '1.0.0')) ?></span><?php if (!empty($theme['compatibility'])): ?><span class="pill"><?= e((string) $theme['compatibility']) ?></span><?php endif; ?></div>
                                <h3 style="margin:0 0 8px 0"><?= e((string) ($theme['name'] ?? 'Theme')) ?></h3>
                                <p class="muted" style="margin:0"><?= e((string) ($theme['description'] ?? '')) ?></p>
                                <div class="muted" style="margin-top:8px">Key: <code><?= e((string) ($theme['theme_key'] ?? '')) ?></code><?php if (!empty($theme['homepage_layout'])): ?> · Layout: <code><?= e((string) $theme['homepage_layout']) ?></code><?php endif; ?></div>
                            </div>
                        </div>
                        <?php if (!empty($theme['preview_image'])): ?>
                            <div class="theme-preview-frame" style="margin-bottom:14px"><img src="<?= e((string) $theme['preview_image']) ?>" alt="<?= e((string) ($theme['name'] ?? 'Theme preview')) ?>"></div>
                        <?php endif; ?>
                        <?php if ($supports): ?><div class="theme-supports"><?php foreach ($supports as $support): ?><span class="theme-support-chip"><?= e((string) $support) ?></span><?php endforeach; ?></div><?php endif; ?>
                        <div style="margin-top:16px">
                            <?php if ((int) ($theme['is_active'] ?? 0) !== 1): ?>
                                <form method="post" action="/admin/themes/activate"><?= csrfField() ?><input type="hidden" name="theme_key" value="<?= e((string) ($theme['theme_key'] ?? '')) ?>"><button class="btn" type="submit">Activate Theme</button></form>
                            <?php else: ?>
                                <div class="muted">This theme is currently active.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div></section>
