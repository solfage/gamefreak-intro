<section class="hero">
    <div class="hero-shell">
        <?php require BASE_PATH . '/app/Views/dashboard/_user_nav.php'; ?>
            <div class="theme-page-banner">
                <div class="badge">Advanced Dashboard Overview</div>
                <h2 style="margin:10px 0 8px">Your control center now uses a dedicated theme banner</h2>
                <p class="muted" style="margin:0">Overview, recent activity, and server actions are still driven by the core dashboard logic but now sit inside a real theme override.</p>
            </div>
            <div class="card" style="margin-top:18px">
                <div class="user-section-title"><div><h2 style="margin:0">Overview</h2><p class="muted" style="margin:6px 0 0">Advanced default theme override for the owner overview page.</p></div></div>
                <div class="user-soft-divider"></div>
                <div class="user-stat-grid user-stat-grid-wide">
                    <div class="user-stat-card user-highlight-card"><span class="label">Servers</span><span class="value"><?= (int) ($stats['servers'] ?? 0) ?></span></div>
                    <div class="user-stat-card"><span class="label">Premium</span><span class="value"><?= (int) ($stats['premium'] ?? 0) ?></span></div>
                    <div class="user-stat-card"><span class="label">Votes</span><span class="value"><?= (int) ($stats['votes'] ?? 0) ?></span></div>
                    <div class="user-stat-card"><span class="label">Views</span><span class="value"><?= (int) ($stats['views'] ?? 0) ?></span></div>
                </div>
                <?php if ($recentServer): ?>
                    <div class="user-soft-divider"></div>
                    <div class="user-feature-card">
                        <div>
                            <div class="badge-tag-row" style="margin:0 0 10px 0"><?php if ((int) ($recentServer['is_premium'] ?? 0) === 1): ?><span class="pill badge-premium">Premium</span><?php endif; ?><span class="pill"><?= e(ucfirst((string) ($recentServer['status'] ?? 'unknown'))) ?></span></div>
                            <h3 style="margin:0 0 8px 0"><?= e($recentServer['title']) ?></h3>
                            <p class="muted" style="margin:0">Latest server activity at a glance with quick access to edit, open, and banner utilities.</p>
                        </div>
                        <div class="user-server-actions"><a class="btn-secondary" href="/server?id=<?= (int) $recentServer['id'] ?>">Open page</a><a class="btn-secondary" href="/dashboard/servers/edit?id=<?= (int) $recentServer['id'] ?>">Edit</a><a class="btn" href="/dashboard/banner-codes">Banner codes</a></div>
                    </div>
                <?php else: ?>
                    <div class="empty-state-card" style="margin-top:18px"><h3>No server added yet</h3><p class="muted">Create your first server listing to unlock the rest of the dashboard pages.</p><a class="btn" href="/dashboard/servers/create">Create Server</a></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
