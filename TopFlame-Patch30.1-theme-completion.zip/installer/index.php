<?php
declare(strict_types=1);

require dirname(__DIR__) . '/bootstrap.php';

$lockFile = dirname(__DIR__) . '/storage/installed.lock';
if (file_exists($lockFile)) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Installer Locked</title></head><body style="font-family:Inter,Arial,sans-serif;background:#070910;color:#edf2ff;padding:40px"><div style="max-width:900px;margin:0 auto;padding:24px;border-radius:24px;border:1px solid rgba(255,204,102,.18);background:linear-gradient(180deg,#101726,#0b0f19)"><h2>Installer is locked.</h2><p>Delete <code>storage/installed.lock</code> only if you intentionally want to reinstall.</p></div></body></html>';
    exit;
}

$errors = $_SESSION['installer_errors'] ?? [];
$old = $_SESSION['installer_old'] ?? [];
unset($_SESSION['installer_errors'], $_SESSION['installer_old']);
$checks = installerChecks();
$hasBlockingErrors = false;
foreach ($checks as $check) {
    if (!$check['ok']) {
        $hasBlockingErrors = true;
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TopFlame Installer</title>
    <style>
        :root{--bg:#070910;--panel:#101726;--panel2:#151d2f;--text:#edf2ff;--muted:#95a1bb;--gold:#ffcc66;--cyan:#5ce1ff;--line:rgba(122,202,255,.16);--glow:0 0 28px rgba(255,204,102,.14)}
        *{box-sizing:border-box} body{margin:0;font-family:Inter,Segoe UI,Arial,sans-serif;color:var(--text);background:
        radial-gradient(circle at 10% 0%, rgba(255,204,102,.16), transparent 28%),
        radial-gradient(circle at 100% 10%, rgba(179,108,255,.18), transparent 26%),
        linear-gradient(180deg,#090c14 0%,#070910 55%,#06070d 100%);}
        .wrap{width:min(1180px,92%);margin:34px auto;padding:0 0 30px}
        .hero{padding:28px;border-radius:28px;border:1px solid rgba(255,204,102,.18);background:linear-gradient(180deg,rgba(16,23,38,.96),rgba(8,12,22,.96));box-shadow:var(--glow);margin-bottom:22px}
        .badge{display:inline-flex;align-items:center;padding:8px 12px;border-radius:999px;border:1px solid rgba(255,204,102,.24);background:rgba(255,204,102,.08);color:var(--gold);font-weight:700}
        h1{margin:12px 0 10px;font-size:44px}.gold{color:var(--gold)} p{color:var(--muted)}
        .card{padding:22px;border-radius:24px;border:1px solid var(--line);background:linear-gradient(180deg,rgba(16,23,38,.96),rgba(8,12,22,.96));margin-bottom:20px}
        .grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
        label{display:block;margin:0 0 8px;font-weight:700}
        input{width:100%;padding:14px 14px;border-radius:14px;border:1px solid rgba(122,202,255,.18);background:#0d1320;color:#fff}
        .btn{padding:14px 18px;background:linear-gradient(90deg, rgba(255,204,102,.16), rgba(179,108,255,.12));border:1px solid rgba(255,204,102,.28);color:#fff;border-radius:14px;cursor:pointer;font-weight:700}
        .error{padding:14px;border-radius:16px;background:rgba(255,0,80,.08);border:1px solid rgba(255,0,80,.3);margin-bottom:14px}
        .ok{padding:14px;border-radius:16px;background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.3);margin-bottom:14px}
        .diag{margin-bottom:10px;border-collapse:collapse;width:100%}.diag td,.diag th{padding:12px;border-bottom:1px solid rgba(255,255,255,.08);text-align:left}
        .diag th{color:var(--gold)} .status-ok{color:#5bff9e}.status-fail{color:#ff7b7b}
        .section-title{margin:0 0 14px;font-size:24px}
        @media (max-width: 800px){.grid{grid-template-columns:1fr}h1{font-size:34px}}
    </style>
</head>
<body>
<div class="wrap">
    <section class="hero">
        <div class="badge">Installer</div>
        <h1>TopFlame <span class="gold">Setup Wizard</span></h1>
        <p>Configure the site, clean the selected database, import the schema, seed defaults, and create the first administrator with the same fantasy / gold visual style used across the platform.</p>
    </section>

    <section class="card">
        <h2 class="section-title">Environment Checks</h2>
        <table class="diag">
            <thead><tr><th>Check</th><th>Status</th><th>Details</th></tr></thead>
            <tbody>
            <?php foreach ($checks as $check): ?>
                <tr>
                    <td><?= htmlspecialchars($check['label'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td class="<?= $check['ok'] ? 'status-ok' : 'status-fail' ?>"><?= $check['ok'] ? 'OK' : 'FAIL' ?></td>
                    <td><?= htmlspecialchars((string) $check['details'], ENT_QUOTES, 'UTF-8') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php if ($hasBlockingErrors): ?>
            <div class="error">There are failing environment checks. Fix them before continuing.</div>
        <?php else: ?>
            <div class="ok">All required checks passed.</div>
        <?php endif; ?>
    </section>

    <section class="card">
        <h2 class="section-title">Install Configuration</h2>
        <?php foreach ($errors as $error): ?>
            <div class="error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endforeach; ?>

        <form method="post" action="install.php">
            <?= csrfField() ?>
            <div class="grid">
                <div><label>Site Name</label><input type="text" name="site_name" value="<?= htmlspecialchars((string) ($old['site_name'] ?? 'TopFlame'), ENT_QUOTES, 'UTF-8') ?>"></div>
                <div><label>Base URL</label><input type="text" name="app_url" value="<?= htmlspecialchars((string) ($old['app_url'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"></div>
                <div><label>Database Host</label><input type="text" name="db_host" value="<?= htmlspecialchars((string) ($old['db_host'] ?? '127.0.0.1'), ENT_QUOTES, 'UTF-8') ?>"></div>
                <div><label>Database Port</label><input type="number" name="db_port" value="<?= htmlspecialchars((string) ($old['db_port'] ?? '3306'), ENT_QUOTES, 'UTF-8') ?>"></div>
                <div><label>Database Name</label><input type="text" name="db_name" value="<?= htmlspecialchars((string) ($old['db_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"></div>
                <div><label>Database User</label><input type="text" name="db_user" value="<?= htmlspecialchars((string) ($old['db_user'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"></div>
                <div><label>Database Password</label><input type="password" name="db_password" value="<?= htmlspecialchars((string) ($old['db_password'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"></div>
                <div><label>Admin Username</label><input type="text" name="admin_username" value="<?= htmlspecialchars((string) ($old['admin_username'] ?? 'admin'), ENT_QUOTES, 'UTF-8') ?>"></div>
                <div><label>Admin Email</label><input type="email" name="admin_email" value="<?= htmlspecialchars((string) ($old['admin_email'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"></div>
                <div><label>Admin Password</label><input type="password" name="admin_password"></div>
            </div>
            <div style="margin-top:18px">
                <button class="btn" type="submit" <?= $hasBlockingErrors ? 'disabled' : '' ?>>Run Installer</button>
            </div>
        </form>
    </section>
</div>
</body>
</html>
