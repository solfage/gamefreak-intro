<?php
declare(strict_types=1);

require dirname(__DIR__) . '/bootstrap.php';
verifyCsrf();

$projectRoot = dirname(__DIR__);
$lockFile = $projectRoot . '/storage/installed.lock';

if (file_exists($lockFile)) {
    exit('Installer is locked.');
}

$data = [
    'site_name' => trim((string) ($_POST['site_name'] ?? '')),
    'app_url' => trim((string) ($_POST['app_url'] ?? '')),
    'db_host' => trim((string) ($_POST['db_host'] ?? '127.0.0.1')),
    'db_port' => (int) ($_POST['db_port'] ?? 3306),
    'db_name' => trim((string) ($_POST['db_name'] ?? '')),
    'db_user' => trim((string) ($_POST['db_user'] ?? '')),
    'db_password' => (string) ($_POST['db_password'] ?? ''),
    'admin_username' => trim((string) ($_POST['admin_username'] ?? 'admin')),
    'admin_email' => trim((string) ($_POST['admin_email'] ?? '')),
    'admin_password' => (string) ($_POST['admin_password'] ?? ''),
];

$errors = [];
if ($data['site_name'] === '') $errors[] = 'Site name is required.';
if ($data['app_url'] === '') $errors[] = 'Base URL is required.';
if ($data['db_name'] === '' || $data['db_user'] === '') $errors[] = 'Database name and user are required.';
if ($data['admin_email'] === '' || !filter_var($data['admin_email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid admin email is required.';
if ($data['admin_password'] === '' || strlen($data['admin_password']) < 6) $errors[] = 'Admin password must be at least 6 characters.';

if ($errors) {
    $_SESSION['installer_errors'] = $errors;
    $_SESSION['installer_old'] = $data;
    header('Location: index.php');
    exit;
}


function quoteIdentifier(string $identifier): string
{
    return '`' . str_replace('`', '``', $identifier) . '`';
}

function cleanDatabase(PDO $pdo, string $dbName): void
{
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');

    $views = $pdo->query("SELECT TABLE_NAME FROM information_schema.VIEWS WHERE TABLE_SCHEMA = " . $pdo->quote($dbName))->fetchAll(PDO::FETCH_COLUMN) ?: [];
    foreach ($views as $view) {
        $pdo->exec('DROP VIEW IF EXISTS ' . quoteIdentifier((string) $view));
    }

    $tables = $pdo->query("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = " . $pdo->quote($dbName) . " AND TABLE_TYPE = 'BASE TABLE'")->fetchAll(PDO::FETCH_COLUMN) ?: [];
    foreach ($tables as $table) {
        $pdo->exec('DROP TABLE IF EXISTS ' . quoteIdentifier((string) $table));
    }

    $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
}

try {
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $data['db_host'], $data['db_port'], $data['db_name']);
    $pdo = new PDO($dsn, $data['db_user'], $data['db_password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    $schema = file_get_contents($projectRoot . '/database/schema.sql');
    if ($schema === false) {
        throw new RuntimeException('schema.sql could not be read.');
    }

    cleanDatabase($pdo, $data['db_name']);

    $statements = array_filter(array_map('trim', preg_split('/;\s*(?:\r?\n|$)/', $schema)));
foreach ($statements as $index => $statement) {
    if ($statement !== '') {
        try {
            $pdo->exec($statement);
        } catch (Throwable $e) {
            throw new RuntimeException('Schema import failed on statement #' . ($index + 1) . ': ' . $e->getMessage());
        }
    }
}

    $passwordHash = password_hash($data['admin_password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare(
        "INSERT INTO users (username, email, password_hash, role, status, email_verified_at, created_at, updated_at)
         VALUES (:username, :email, :password_hash, 'admin', 'active', NOW(), NOW(), NOW())
         ON DUPLICATE KEY UPDATE
             username = VALUES(username),
             password_hash = VALUES(password_hash),
             role = 'admin',
             status = 'active',
             updated_at = NOW()"
    );

    $stmt->execute([
        'username' => $data['admin_username'],
        'email' => $data['admin_email'],
        'password_hash' => $passwordHash,
    ]);

    $config = "<?php\nreturn " . var_export([
        'app' => [
            'name' => $data['site_name'],
            'url' => $data['app_url'],
            'env' => 'production',
            'debug' => false,
        ],
        'db' => [
            'host' => $data['db_host'],
            'port' => $data['db_port'],
            'database' => $data['db_name'],
            'username' => $data['db_user'],
            'password' => $data['db_password'],
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
        ],
    ], true) . ";\n";

    if (file_put_contents($projectRoot . '/config/app.php', $config) === false) {
        throw new RuntimeException('Could not write config/app.php');
    }

    foreach ([$projectRoot . '/storage', $projectRoot . '/storage/cache', $projectRoot . '/storage/uploads', $projectRoot . '/storage/rate_limits'] as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
    }

    file_put_contents($lockFile, 'installed:' . date('c'));

    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Installed</title></head><body style="font-family:Arial;background:#090b12;color:#fff;padding:30px">';
    echo '<div style="max-width:760px;margin:0 auto;background:#121827;padding:24px;border-radius:18px;border:1px solid rgba(52,214,255,.18)">';
    echo '<h1>Installation complete</h1>';
    echo '<p>Database cleaned, config file written, SQL schema imported, and the first admin account was created.</p>';
    echo '<p><strong>Admin email:</strong> ' . htmlspecialchars($data['admin_email'], ENT_QUOTES, 'UTF-8') . '</p>';
    echo '<p><a href="../" style="color:#34d6ff">Open the site</a></p>';
    echo '<p><a href="../login" style="color:#34d6ff">Go to login</a></p>';
    echo '</div></body></html>';
} catch (Throwable $e) {
    $_SESSION['installer_errors'] = ['Install failed: ' . $e->getMessage()];
    $_SESSION['installer_old'] = $data;
    header('Location: index.php');
    exit;
}


try {
    $pdo->exec("ALTER TABLE server_banners MODIFY server_id INT NULL");
} catch (Throwable $e) {
}


try {
    $stmt = $pdo->query("SHOW COLUMNS FROM server_banners LIKE 'server_id'");
    $col = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : false;
    if ($col && strtoupper((string) ($col['Null'] ?? 'NO')) !== 'YES') {
        $createStmt = $pdo->query("SHOW CREATE TABLE server_banners");
        $createRow = $createStmt ? $createStmt->fetch(PDO::FETCH_ASSOC) : [];
        $createSql = (string) ($createRow['Create Table'] ?? array_values($createRow ?: [])[1] ?? '');
        if (preg_match_all('/CONSTRAINT `?([^` ]+)`? FOREIGN KEY \(`?server_id`?\)/i', $createSql, $matches)) {
            foreach (($matches[1] ?? []) as $fkName) {
                try {
                    $pdo->exec("ALTER TABLE server_banners DROP FOREIGN KEY `" . $fkName . "`");
                } catch (Throwable $e) {
                }
            }
        }
        try {
            $pdo->exec("ALTER TABLE server_banners MODIFY server_id INT NULL");
        } catch (Throwable $e) {
        }
    }
} catch (Throwable $e) {
}
