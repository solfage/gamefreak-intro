<?php
return [
    'app' => [
        'name' => 'Lineage 2 Private Servers',
        'url' => 'http://localhost',
        'env' => 'production',
        'debug' => false,
    ],
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'database' => 'l2_private_servers',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
    ],
];
