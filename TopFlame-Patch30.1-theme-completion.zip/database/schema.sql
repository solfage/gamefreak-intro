SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user','admin') NOT NULL DEFAULT 'user',
    status ENUM('active','suspended','banned') NOT NULL DEFAULT 'active',
    email_verified_at DATETIME NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categories (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    slug VARCHAR(140) NOT NULL UNIQUE,
    created_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS servers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NULL,
    title VARCHAR(180) NOT NULL,
    slug VARCHAR(200) NOT NULL UNIQUE,
    short_description VARCHAR(300) NULL,
    full_description TEXT NULL,
    chronicle VARCHAR(80) NOT NULL,
    xp_rate DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    sp_rate DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    adena_rate DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    drop_rate DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    country VARCHAR(80) NULL,
    language VARCHAR(80) NULL,
    website_url VARCHAR(255) NULL,
    register_url VARCHAR(255) NULL,
    download_url VARCHAR(255) NULL,
    patch_url VARCHAR(255) NULL,
    updater_url VARCHAR(255) NULL,
    vote_gateway_url VARCHAR(255) NULL,
    login_server_status TINYINT(1) NOT NULL DEFAULT 0,
    game_server_status TINYINT(1) NOT NULL DEFAULT 0,
    login_ip VARCHAR(100) NULL,
    login_port INT UNSIGNED NULL,
    game_ip VARCHAR(100) NULL,
    game_port INT UNSIGNED NULL,
    uptime_percent DECIMAL(5,2) NOT NULL DEFAULT 100.00,
    online_players_enabled TINYINT(1) NOT NULL DEFAULT 0,
    online_players INT UNSIGNED NULL,
    last_status_check_at DATETIME NULL,
    feature_gm_shop TINYINT(1) NOT NULL DEFAULT 0,
    feature_buffer TINYINT(1) NOT NULL DEFAULT 0,
    feature_gatekeeper TINYINT(1) NOT NULL DEFAULT 0,
    safe_enchant INT UNSIGNED NULL,
    max_enchant INT UNSIGNED NULL,
    normal_enchant_rate DECIMAL(5,2) NULL,
    blessed_enchant_rate DECIMAL(5,2) NULL,
    install_guide TEXT NULL,
    logo_path VARCHAR(255) NULL,
    banner_path VARCHAR(255) NULL,
    status ENUM('pending','approved','rejected','disabled') NOT NULL DEFAULT 'pending',
    is_premium TINYINT(1) NOT NULL DEFAULT 0,
    premium_until DATETIME NULL,
    premium_boost_type ENUM('percent','fixed') NOT NULL DEFAULT 'percent',
    premium_boost_value DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    raw_votes_total INT UNSIGNED NOT NULL DEFAULT 0,
    raw_votes_daily INT UNSIGNED NOT NULL DEFAULT 0,
    raw_votes_weekly INT UNSIGNED NOT NULL DEFAULT 0,
    raw_votes_monthly INT UNSIGNED NOT NULL DEFAULT 0,
    ranking_score DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    views_count INT UNSIGNED NOT NULL DEFAULT 0,
    featured_order INT UNSIGNED NOT NULL DEFAULT 9999,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    KEY idx_servers_status (status),
    KEY idx_servers_user (user_id),
    KEY idx_servers_premium (is_premium, premium_until),
    KEY idx_servers_ranking (ranking_score, raw_votes_total),
    CONSTRAINT fk_servers_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS server_images (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    server_id BIGINT UNSIGNED NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    sort_order INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NULL,
    KEY idx_server_images_server (server_id, sort_order),
    CONSTRAINT fk_server_images_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categories_servers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    server_id BIGINT UNSIGNED NOT NULL,
    category_id BIGINT UNSIGNED NOT NULL,
    UNIQUE KEY uq_server_category (server_id, category_id),
    KEY idx_cs_category (category_id),
    CONSTRAINT fk_cs_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
    CONSTRAINT fk_cs_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS server_votes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    server_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent VARCHAR(255) NULL,
    vote_date DATE NOT NULL,
    source VARCHAR(120) NULL,
    created_at DATETIME NULL,
    KEY idx_server_vote_date (server_id, vote_date),
    KEY idx_vote_ip_date (ip_address, vote_date),
    KEY idx_server_votes_user (user_id),
    CONSTRAINT fk_server_votes_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
    CONSTRAINT fk_server_votes_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS premium_packages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    duration_days INT UNSIGNED NOT NULL DEFAULT 30,
    boost_type ENUM('percent','fixed') NOT NULL DEFAULT 'percent',
    boost_value DECIMAL(10,2) NOT NULL DEFAULT 10.00,
    allow_logo TINYINT(1) NOT NULL DEFAULT 1,
    allow_banner TINYINT(1) NOT NULL DEFAULT 1,
    featured_homepage TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS premium_orders (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    server_id BIGINT UNSIGNED NOT NULL,
    package_id BIGINT UNSIGNED NOT NULL,
    payment_method VARCHAR(80) NULL,
    payment_status ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
    amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    premium_start DATETIME NULL,
    premium_end DATETIME NULL,
    created_at DATETIME NULL,
    KEY idx_premium_orders_user (user_id),
    KEY idx_premium_orders_server (server_id),
    KEY idx_premium_orders_package (package_id),
    CONSTRAINT fk_premium_orders_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_premium_orders_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
    CONSTRAINT fk_premium_orders_package FOREIGN KEY (package_id) REFERENCES premium_packages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS click_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    server_id BIGINT UNSIGNED NULL,
    user_id BIGINT UNSIGNED NULL,
    action_type VARCHAR(50) NOT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    created_at DATETIME NULL,
    KEY idx_click_action (action_type),
    KEY idx_click_server (server_id),
    KEY idx_click_user (user_id),
    CONSTRAINT fk_click_logs_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE SET NULL,
    CONSTRAINT fk_click_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reports (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    server_id BIGINT UNSIGNED NULL,
    user_id BIGINT UNSIGNED NULL,
    reason VARCHAR(120) NOT NULL,
    message TEXT NULL,
    status ENUM('open','reviewing','closed') NOT NULL DEFAULT 'open',
    created_at DATETIME NULL,
    KEY idx_reports_server (server_id),
    KEY idx_reports_user (user_id),
    KEY idx_reports_status (status),
    CONSTRAINT fk_reports_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE SET NULL,
    CONSTRAINT fk_reports_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admin_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_user_id BIGINT UNSIGNED NOT NULL,
    action VARCHAR(120) NOT NULL,
    target_type VARCHAR(80) NULL,
    target_id BIGINT UNSIGNED NULL,
    details TEXT NULL,
    payload LONGTEXT NULL,
    created_at DATETIME NULL,
    KEY idx_admin_logs_admin (admin_user_id),
    KEY idx_admin_logs_action (action),
    CONSTRAINT fk_admin_logs_admin FOREIGN KEY (admin_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(120) NOT NULL UNIQUE,
    setting_value TEXT NULL,
    updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS server_banners (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    server_id BIGINT UNSIGNED NULL,
    title VARCHAR(140) NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    size_label VARCHAR(40) NULL,
    sort_order INT UNSIGNED NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    KEY idx_server_banners_scope (server_id, is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO categories (name, slug, created_at) VALUES
('Interlude', 'interlude', NOW()),
('High Five', 'high-five', NOW()),
('Classic', 'classic', NOW()),
('Essence', 'essence', NOW()),
('Custom', 'custom', NOW())
ON DUPLICATE KEY UPDATE
    name = VALUES(name);

INSERT INTO premium_packages (name, duration_days, boost_type, boost_value, allow_logo, allow_banner, featured_homepage, created_at) VALUES
('Premium Starter', 30, 'percent', 10.00, 1, 1, 1, NOW()),
('Premium Plus', 30, 'percent', 15.00, 1, 1, 1, NOW()),
('Premium Elite', 30, 'percent', 20.00, 1, 1, 1, NOW());

INSERT INTO settings (setting_key, setting_value, updated_at) VALUES
('site_theme', 'dark-neon-gaming', NOW()),
('vote_mode', 'account_plus_ip', NOW()),
('site_status', 'online', NOW())
ON DUPLICATE KEY UPDATE
    setting_value = VALUES(setting_value),
    updated_at = NOW();

SET FOREIGN_KEY_CHECKS = 1;


CREATE TABLE IF NOT EXISTS modules (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    module_key VARCHAR(120) NOT NULL UNIQUE,
    name VARCHAR(160) NOT NULL,
    type ENUM('core','plugin') NOT NULL DEFAULT 'core',
    source ENUM('internal','external') NOT NULL DEFAULT 'internal',
    version VARCHAR(40) NOT NULL DEFAULT '1.0.0',
    description TEXT NULL,
    is_enabled TINYINT(1) NOT NULL DEFAULT 1,
    is_locked TINYINT(1) NOT NULL DEFAULT 0,
    path VARCHAR(255) NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;


CREATE TABLE IF NOT EXISTS module_migrations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    module_key VARCHAR(120) NOT NULL,
    version VARCHAR(40) NOT NULL,
    migration_name VARCHAR(190) NOT NULL,
    executed_at DATETIME NULL,
    UNIQUE KEY uq_module_migration (module_key, version, migration_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS core_update_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_user_id BIGINT UNSIGNED NULL,
    package_name VARCHAR(190) NOT NULL,
    package_version VARCHAR(60) NULL,
    status ENUM('started','completed','failed') NOT NULL DEFAULT 'started',
    backup_path VARCHAR(255) NULL,
    details TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
