INSERT INTO servers (
    user_id, title, slug, short_description, full_description, chronicle,
    xp_rate, sp_rate, adena_rate, drop_rate, country, language,
    website_url, register_url, download_url, patch_url, updater_url,
    status, is_premium, premium_until, premium_boost_type, premium_boost_value,
    raw_votes_total, raw_votes_daily, raw_votes_weekly, raw_votes_monthly, ranking_score, featured_order, created_at, updated_at
) VALUES
(1, 'L2 NeonWorld', 'l2-neonworld', 'High Five private server with neon-styled portal listing.', 'Sample premium server created for demonstration.', 'High Five',
20, 20, 10, 5, 'Global', 'English',
'https://example.com', 'https://example.com/register', 'https://example.com/download', 'https://example.com/patch', 'https://example.com/updater',
'approved', 1, DATE_ADD(NOW(), INTERVAL 30 DAY), 'percent', 15, 120, 12, 35, 77, 138.00, 1, NOW(), NOW()),
(1, 'L2 Eternity', 'l2-eternity', 'Interlude low-rate server sample entry.', 'Sample non-premium listing for starter project.', 'Interlude',
5, 5, 3, 2, 'EU', 'English',
'https://example.org', 'https://example.org/register', 'https://example.org/download', 'https://example.org/patch', 'https://example.org/updater',
'approved', 0, NULL, 'percent', 0, 77, 7, 19, 40, 77.00, 9999, NOW(), NOW());
