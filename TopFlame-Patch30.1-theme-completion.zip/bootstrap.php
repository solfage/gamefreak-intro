<?php

declare(strict_types=1);

$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['SERVER_PORT'] ?? null) === '443');

if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');
    if ($https) {
        ini_set('session.cookie_secure', '1');
    }
    session_start();
}

if (!defined('BASE_PATH')) {
    define('BASE_PATH', __DIR__);
}

$configFile = BASE_PATH . '/config/app.php';
$requestUri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
if (!file_exists($configFile) && strpos($requestUri, '/installer') !== 0) {
    header('Location: /installer/');
    exit;
}

$config = file_exists($configFile) ? require $configFile : [];

require_once BASE_PATH . '/app/Core/helpers.php';
require_once BASE_PATH . '/app/Core/Database.php';
require_once BASE_PATH . '/app/Core/Router.php';

spl_autoload_register(static function (string $class): void {
    $paths = [
        BASE_PATH . '/app/Core/' . $class . '.php',
        BASE_PATH . '/app/Controllers/' . $class . '.php',
    ];

    foreach ($paths as $path) {
        if (file_exists($path)) {
            require_once $path;
            return;
        }
    }
});

ensureStorageDirectories();
bootstrapSecurityState();
if (file_exists($configFile)) {
    ensureOptionalServerColumns();
    ensureServerBannerTable();
    if (function_exists('ensureThemesTable')) { ensureThemesTable(); }
}
