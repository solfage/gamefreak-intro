<?php

declare(strict_types=1);

final class Router
{
    private array $getRoutes = [];
    private array $postRoutes = [];

    public function get(string $path, callable|array $handler): void
    {
        $this->getRoutes[$path] = $handler;
    }

    public function post(string $path, callable|array $handler): void
    {
        $this->postRoutes[$path] = $handler;
    }

    public function dispatch(string $requestUri, string $method): void
    {
        $path = parse_url($requestUri, PHP_URL_PATH) ?: '/';
        $routes = strtoupper($method) === 'POST' ? $this->postRoutes : $this->getRoutes;
        $handler = $routes[$path] ?? null;

        if ($handler === null) {
            renderErrorPage(404, 'Η σελίδα που ζήτησες δεν βρέθηκε.', '404 Not Found');
        }

        if (is_array($handler)) {
            [$class, $action] = $handler;
            require_once BASE_PATH . '/app/Controllers/' . $class . '.php';
            $controller = new $class();
            $controller->{$action}();
            return;
        }

        $handler();
    }
}
