<?php

declare(strict_types=1);

function config(string $key, mixed $default = null): mixed
{
    global $config;

    $segments = explode('.', $key);
    $value = $config ?? [];

    foreach ($segments as $segment) {
        if (!is_array($value) || !array_key_exists($segment, $value)) {
            return $default;
        }
        $value = $value[$segment];
    }

    return $value;
}

function ensureStorageDirectories(): void
{
    $paths = [
        BASE_PATH . '/storage',
        BASE_PATH . '/storage/cache',
        BASE_PATH . '/storage/uploads',
        BASE_PATH . '/storage/rate_limits',
    ];

    foreach ($paths as $path) {
        if (!is_dir($path)) {
            mkdir($path, 0775, true);
        }
    }
}

function bootstrapSecurityState(): void
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}

function view(string $name, array $data = []): void
{
    extract($data, EXTR_SKIP);
    $defaultViewFile = BASE_PATH . '/app/Views/' . $name . '.php';
    $viewFile = function_exists('resolveThemeView') ? (resolveThemeView($name) ?? $defaultViewFile) : $defaultViewFile;

    if (!file_exists($viewFile)) {
        http_response_code(500);
        echo 'View not found: ' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
        exit;
    }

    $defaultHeader = BASE_PATH . '/app/Views/layouts/header.php';
    $defaultFooter = BASE_PATH . '/app/Views/layouts/footer.php';
    $headerFile = function_exists('themeLayoutOrDefault') ? themeLayoutOrDefault('header', $defaultHeader) : $defaultHeader;
    $footerFile = function_exists('themeLayoutOrDefault') ? themeLayoutOrDefault('footer', $defaultFooter) : $defaultFooter;

    require $headerFile;
    require $viewFile;
    require $footerFile;
}

function redirect(string $path): never
{
    header('Location: ' . $path);
    exit;
}

function renderErrorPage(int $statusCode, string $message, string $title = 'Κάτι πήγε λάθος'): never
{
    http_response_code($statusCode);
    view('errors/generic', [
        'statusCode' => $statusCode,
        'title' => $title,
        'message' => $message,
    ]);
    exit;
}

function slugify(string $text): string
{
    $text = mb_strtolower(trim($text), 'UTF-8');
    $text = preg_replace('/[^\p{L}\p{N}]+/u', '-', $text) ?? '';
    $text = trim($text, '-');

    return $text !== '' ? $text : 'server';
}

function uniqueServerSlug(string $title): string
{
    $base = slugify($title);
    $slug = $base;
    $suffix = 1;

    while (db()->first("SELECT id FROM servers WHERE slug = :slug LIMIT 1", ['slug' => $slug])) {
        $suffix++;
        $slug = $base . '-' . $suffix;
    }

    return $slug;
}

function validationRedirect(string $message): never
{
    $_SESSION['flash'] = $message;
    $back = $_SERVER['HTTP_REFERER'] ?? '/';
    redirect((string) $back);
}

function logAdminAction(string $action, ?string $targetType = null, int|string|null $targetId = null, ?array $payload = null): void
{
    if (!isAdmin()) {
        return;
    }

    db()->statement(
        "INSERT INTO admin_logs (admin_user_id, action, target_type, target_id, payload, created_at)
         VALUES (:admin_user_id, :action, :target_type, :target_id, :payload, NOW())",
        [
            'admin_user_id' => currentUser()['id'],
            'action' => $action,
            'target_type' => $targetType,
            'target_id' => $targetId,
            'payload' => $payload ? json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
        ]
    );
}

function l2Chronicles(): array
{
    return [
        'Prelude','Chronicle 1: Harbingers of War','Chronicle 2: Age of Splendor','Chronicle 3: Rise of Darkness','Chronicle 4: Scions of Destiny','Chronicle 5: Oath of Blood','Interlude','The Kamael','Hellbound','Gracia Part 1','Gracia Part 2','Gracia Final','Gracia Epilogue','Freya','High Five','Awakening','Harmony','Tauti','Glory Days','Lindvior','Valiance','Ertheia','Infinite Odyssey','Infinite Odyssey: Hymn of the Soul','Helios','Grand Crusade','Salvation','Fafurion','Prelude of War','Death Knight','Homunculus','The Source of Flame','Project Wolf','Classic','Essence','Aden','Custom',
    ];
}

function serverCountries(): array
{
    return [
        'International','Argentina','Australia','Belgium','Brazil','Bulgaria','Canada','China','Croatia','Cyprus','Czech Republic','France','Germany','Greece','Hungary','India','Indonesia','Italy','Japan','Mexico','Netherlands','Philippines','Poland','Portugal','Romania','Russia','Serbia','Singapore','Slovakia','Spain','Sweden','Thailand','Turkey','Ukraine','United Kingdom','United States','Custom',
    ];
}

function serverLanguages(): array
{
    return [
        'English','Greek','Russian','Spanish','Portuguese','German','French','Italian','Polish','Turkish','Romanian','Ukrainian','Bulgarian','Serbian','Czech','Hungarian','Chinese','Japanese','Korean','Thai','Multi-language','Custom',
    ];
}

function isAllowedChronicle(string $chronicle): bool
{
    return in_array($chronicle, l2Chronicles(), true);
}

function isAllowedCountry(?string $country): bool
{
    return $country === null || $country === '' || in_array($country, serverCountries(), true);
}

function isAllowedLanguage(?string $language): bool
{
    return $language === null || $language === '' || in_array($language, serverLanguages(), true);
}

function ensureOptionalServerColumns(): void
{
    try {
        $db = db();
        $columns = $db->select('SHOW COLUMNS FROM servers');
        $existing = array_map(static fn (array $row): string => (string) ($row['Field'] ?? ''), $columns);

        $definitions = [
            'vote_gateway_url' => "ALTER TABLE servers ADD COLUMN vote_gateway_url VARCHAR(255) NULL AFTER updater_url",
            'login_server_status' => "ALTER TABLE servers ADD COLUMN login_server_status TINYINT(1) NOT NULL DEFAULT 0 AFTER vote_gateway_url",
            'game_server_status' => "ALTER TABLE servers ADD COLUMN game_server_status TINYINT(1) NOT NULL DEFAULT 0 AFTER login_server_status",
            'login_ip' => "ALTER TABLE servers ADD COLUMN login_ip VARCHAR(100) NULL AFTER game_server_status",
            'login_port' => "ALTER TABLE servers ADD COLUMN login_port INT UNSIGNED NULL AFTER login_ip",
            'game_ip' => "ALTER TABLE servers ADD COLUMN game_ip VARCHAR(100) NULL AFTER login_port",
            'game_port' => "ALTER TABLE servers ADD COLUMN game_port INT UNSIGNED NULL AFTER game_ip",
            'feature_gm_shop' => "ALTER TABLE servers ADD COLUMN feature_gm_shop TINYINT(1) NOT NULL DEFAULT 0 AFTER game_port",
            'feature_buffer' => "ALTER TABLE servers ADD COLUMN feature_buffer TINYINT(1) NOT NULL DEFAULT 0 AFTER feature_gm_shop",
            'feature_gatekeeper' => "ALTER TABLE servers ADD COLUMN feature_gatekeeper TINYINT(1) NOT NULL DEFAULT 0 AFTER feature_buffer",
            'safe_enchant' => "ALTER TABLE servers ADD COLUMN safe_enchant INT UNSIGNED NULL AFTER feature_gatekeeper",
            'max_enchant' => "ALTER TABLE servers ADD COLUMN max_enchant INT UNSIGNED NULL AFTER safe_enchant",
            'normal_enchant_rate' => "ALTER TABLE servers ADD COLUMN normal_enchant_rate DECIMAL(5,2) NULL AFTER max_enchant",
            'blessed_enchant_rate' => "ALTER TABLE servers ADD COLUMN blessed_enchant_rate DECIMAL(5,2) NULL AFTER normal_enchant_rate",
        ];

        foreach ($definitions as $column => $sql) {
            if (!in_array($column, $existing, true)) {
                $db->statement($sql);
            }
        }
    } catch (Throwable $e) {
        // Ignore optional migration failures so the app can still boot.
    }
}

function markVoteGatewayVisit(int $serverId): void
{
    $_SESSION['vote_gateway'][$serverId] = time();
}

function hasRecentVoteGatewayVisit(int $serverId, int $ttlSeconds = 1800): bool
{
    $visitedAt = (int) ($_SESSION['vote_gateway'][$serverId] ?? 0);

    return $visitedAt > 0 && $visitedAt >= (time() - $ttlSeconds);
}

function clearVoteGatewayVisit(int $serverId): void
{
    unset($_SESSION['vote_gateway'][$serverId]);
}

function db(): Database
{
    static $database = null;

    if ($database === null) {
        $database = new Database([
            'host' => (string) config('db.host'),
            'port' => (int) config('db.port', 3306),
            'database' => (string) config('db.database'),
            'username' => (string) config('db.username'),
            'password' => (string) config('db.password'),
            'charset' => (string) config('db.charset', 'utf8mb4'),
        ]);
    }

    return $database;
}

function isLoggedIn(): bool
{
    return isset($_SESSION['user']);
}

function currentUser(): ?array
{
    return $_SESSION['user'] ?? null;
}

function isAdmin(): bool
{
    return (currentUser()['role'] ?? null) === 'admin';
}

function requireAuth(): void
{
    if (!isLoggedIn()) {
        $_SESSION['flash'] = 'Πρέπει να συνδεθείς πρώτα.';
        redirect('/login');
    }
}

function requireAdmin(): void
{
    requireAuth();
    if (!isAdmin()) {
        renderErrorPage(403, 'Δεν έχεις δικαίωμα πρόσβασης σε αυτή τη σελίδα.', 'Απαγορευμένη πρόσβαση');
    }
}

function e(string|null $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return (string) $_SESSION['csrf_token'];
}

function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrfToken()) . '">';
}

function verifyCsrf(): void
{
    $token = (string) ($_POST['csrf_token'] ?? '');
    $sessionToken = (string) ($_SESSION['csrf_token'] ?? '');

    if ($token === '' || $sessionToken === '' || !hash_equals($sessionToken, $token)) {
        http_response_code(419);
        $_SESSION['flash'] = 'Η συνεδρία έληξε ή το αίτημα δεν είναι έγκυρο.';
        echo 'Invalid CSRF token';
        exit;
    }
}

function regenerateCsrfToken(): void
{
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function clientIp(): string
{
    $candidates = [
        (string) ($_SERVER['HTTP_CF_CONNECTING_IP'] ?? ''),
        (string) ($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''),
        (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
    ];

    foreach ($candidates as $candidate) {
        foreach (explode(',', $candidate) as $ip) {
            $ip = trim($ip);
            if ($ip !== '' && filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }

    return '0.0.0.0';
}

function rateLimitFile(string $key): string
{
    return BASE_PATH . '/storage/rate_limits/' . hash('sha256', $key) . '.json';
}

function checkRateLimit(string $action, string $subject, int $maxAttempts, int $windowSeconds): bool
{
    $file = rateLimitFile($action . '|' . $subject);
    $now = time();
    $attempts = [];

    if (is_file($file)) {
        $decoded = json_decode((string) file_get_contents($file), true);
        if (is_array($decoded)) {
            $attempts = array_values(array_filter($decoded, static fn ($ts): bool => is_int($ts) && $ts > ($now - $windowSeconds)));
        }
    }

    return count($attempts) < $maxAttempts;
}

function hitRateLimit(string $action, string $subject, int $windowSeconds): void
{
    $file = rateLimitFile($action . '|' . $subject);
    $now = time();
    $attempts = [];

    if (is_file($file)) {
        $decoded = json_decode((string) file_get_contents($file), true);
        if (is_array($decoded)) {
            $attempts = array_values(array_filter($decoded, static fn ($ts): bool => is_int($ts) && $ts > ($now - $windowSeconds)));
        }
    }

    $attempts[] = $now;
    file_put_contents($file, json_encode($attempts, JSON_THROW_ON_ERROR));
}

function enforceRateLimit(string $action, string $subject, int $maxAttempts, int $windowSeconds, string $message, string $redirectPath): void
{
    if (!checkRateLimit($action, $subject, $maxAttempts, $windowSeconds)) {
        $_SESSION['flash'] = $message;
        redirect($redirectPath);
    }

    hitRateLimit($action, $subject, $windowSeconds);
}

function isValidPublicUrl(?string $url): bool
{
    if ($url === null || trim($url) === '') {
        return false;
    }

    $validated = filter_var(trim($url), FILTER_VALIDATE_URL);
    if ($validated === false) {
        return false;
    }

    $parts = parse_url($validated);
    $scheme = strtolower((string) ($parts['scheme'] ?? ''));

    return in_array($scheme, ['http', 'https'], true);
}

function safeExternalUrl(?string $url): ?string
{
    return isValidPublicUrl($url) ? trim((string) $url) : null;
}

function appUrl(string $path = ''): string
{
    $baseUrl = rtrim((string) config('app.url', ''), '/');

    if ($baseUrl === '') {
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ((string) ($_SERVER['SERVER_PORT'] ?? '') === '443');
        $scheme = $https ? 'https' : 'http';
        $host = (string) ($_SERVER['HTTP_HOST'] ?? '');

        if ($host !== '') {
            $baseUrl = $scheme . '://' . $host;
        }
    }

    $path = '/' . ltrim($path, '/');

    return $baseUrl !== '' ? $baseUrl . ($path === '/' ? '' : $path) : $path;
}

function serverViewUrl(int $serverId): string
{
    return '/server?id=' . $serverId;
}

function voteGatewayPath(int $serverId): string
{
    return '/vote-gateway?id=' . $serverId;
}

function voteGatewayUrl(int $serverId): string
{
    return appUrl(voteGatewayPath($serverId));
}

function voteBannerAssetPath(): string
{
    return '/assets/topflame-vote-banner-468x120.png';
}

function voteBannerAssetUrl(): string
{
    return appUrl(voteBannerAssetPath());
}

function voteBannerEmbedCode(int $serverId, string $serverTitle = 'server'): string
{
    $gatewayUrl = voteGatewayUrl($serverId);
    $bannerUrl = voteBannerAssetUrl();
    $alt = 'Vote for ' . trim($serverTitle) . ' on TopFlame';

    return '<a href="' . e($gatewayUrl) . '" target="_blank" rel="noopener noreferrer">' . PHP_EOL
        . '    <img src="' . e($bannerUrl) . '" alt="' . e($alt) . '" border="0">' . PHP_EOL
        . '</a>';
}

function qs(array $overrides = []): string
{
    $params = array_merge($_GET, $overrides);

    foreach ($params as $key => $value) {
        if ($value === null || $value === '') {
            unset($params[$key]);
        }
    }

    $query = http_build_query($params);

    return $query !== '' ? '?' . $query : '';
}

function selectedIf(string $expected, mixed $actual): string
{
    return (string) $actual === $expected ? 'selected' : '';
}

function checkedIf(string $expected, mixed $actual): string
{
    return (string) $actual === $expected ? 'checked' : '';
}

function validPremiumBoostType(string $type): string
{
    return in_array($type, ['percent', 'fixed'], true) ? $type : 'percent';
}

function calculateRankingScore(int $votes, int $isPremium, string $boostType, float $boostValue): float
{
    if ($isPremium === 1) {
        if ($boostType === 'fixed') {
            return round($votes + $boostValue, 2);
        }

        return round($votes * (1 + ($boostValue / 100)), 2);
    }

    return (float) $votes;
}

function installerChecks(): array
{
    $configDir = BASE_PATH . '/config';
    $storageDir = BASE_PATH . '/storage';
    $schemaFile = BASE_PATH . '/database/schema.sql';

    return [
        ['label' => 'PHP version >= 8.0','ok' => version_compare(PHP_VERSION, '8.0.0', '>='),'details' => PHP_VERSION],
        ['label' => 'PDO extension','ok' => extension_loaded('pdo'),'details' => extension_loaded('pdo') ? 'enabled' : 'missing'],
        ['label' => 'PDO MySQL extension','ok' => extension_loaded('pdo_mysql'),'details' => extension_loaded('pdo_mysql') ? 'enabled' : 'missing'],
        ['label' => 'config/ writable','ok' => is_dir($configDir) && is_writable($configDir),'details' => $configDir],
        ['label' => 'storage/ writable','ok' => is_dir($storageDir) && is_writable($storageDir),'details' => $storageDir],
        ['label' => 'database/schema.sql readable','ok' => is_file($schemaFile) && is_readable($schemaFile),'details' => $schemaFile],
    ];
}


function ensureServerBannerTable(): void
{
    try {
        db()->statement(
            "CREATE TABLE IF NOT EXISTS server_banners (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                server_id BIGINT UNSIGNED NULL,
                title VARCHAR(140) NOT NULL,
                image_url VARCHAR(255) NOT NULL,
                size_label VARCHAR(40) NULL,
                sort_order INT UNSIGNED NOT NULL DEFAULT 0,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NULL,
                updated_at DATETIME NULL,
                KEY idx_server_banners_scope (server_id, is_active, sort_order)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {
        // silent compatibility fallback
    }
}

function adminMenuItems(): array
{
    return [
        '/admin' => 'Dashboard',
        '/admin/servers' => 'Servers',
        '/admin/premium' => 'Premium',
        '/admin/users' => 'Users',
        '/admin/banners' => 'Banners',
        '/admin/plugins' => 'Plugins',
        '/admin/themes' => 'Themes',
        '/admin/updater' => 'Updater',
        '/admin/logs' => 'Logs',
    ];
}

function bannerGatewayHtml(array $banner, array $server): string
{
    $gateway = appUrl('/vote-gateway?id=' . (int) ($server['id'] ?? 0) . '&banner=' . (int) ($banner['id'] ?? 0));
    $image = safeExternalUrl((string) ($banner['image_url'] ?? '')) ?? '';
    $title = trim((string) ($banner['title'] ?? (($server['title'] ?? 'Server') . ' Vote Banner')));
    if ($image === '') {
        $image = voteBannerAssetUrl();
    }

    return '<a href="' . e($gateway) . '" target="_blank" rel="noopener noreferrer">' . PHP_EOL
        . '    <img src="' . e($image) . '" alt="' . e($title) . '" border="0">' . PHP_EOL
        . '</a>';
}

function premiumBrandingAllowed(array $server): bool
{
    return isAdmin() || (int) ($server['is_premium'] ?? 0) === 1;
}


if (!function_exists('public_asset_url')) {
    function public_asset_url(string $relativePath): string
    {
        $relativePath = '/' . ltrim(str_replace('\\', '/', $relativePath), '/');
        $base = rtrim((string) config('app.url', ''), '/');

        if ($base !== '') {
            return $base . $relativePath;
        }

        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
        $basePath = rtrim($scriptDir, '/');
        if (substr($basePath, -6) === '/public') {
            $basePath = substr($basePath, 0, -6);
        }

        return $scheme . '://' . $host . $basePath . $relativePath;
    }
}

if (!function_exists('handle_image_upload')) {
    function handle_image_upload(string $fieldName, string $targetDirRelative = 'public/uploads'): ?string
    {
        if (!isset($_FILES[$fieldName]) || !is_array($_FILES[$fieldName])) {
            return null;
        }

        $file = $_FILES[$fieldName];
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Image upload failed.');
        }

        $tmp = $file['tmp_name'] ?? '';
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            throw new RuntimeException('Invalid uploaded file.');
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_file($finfo, $tmp) : null;
        if ($finfo) {
            finfo_close($finfo);
        }

        $allowed = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
        ];

        if (!isset($allowed[$mime])) {
            throw new RuntimeException('Only JPG, PNG, WEBP, or GIF images are allowed.');
        }

        $targetDir = base_path($targetDirRelative);
        if (!is_dir($targetDir)) {
            @mkdir($targetDir, 0775, true);
        }
        if (!is_dir($targetDir) || !is_writable($targetDir)) {
            throw new RuntimeException('Upload directory is not writable.');
        }

        $filename = date('YmdHis') . '_' . bin2hex(random_bytes(6)) . '.' . $allowed[$mime];
        $targetPath = $targetDir . DIRECTORY_SEPARATOR . $filename;

        if (!move_uploaded_file($tmp, $targetPath)) {
            throw new RuntimeException('Could not save uploaded image.');
        }

        return '/' . trim(str_replace('\\', '/', $targetDirRelative), '/') . '/' . $filename;
    }
}


if (!function_exists('base_path')) {
    function base_path(string $path = ''): string
    {
        $base = dirname(__DIR__, 2);
        if ($path === '') {
            return $base;
        }

        return $base . DIRECTORY_SEPARATOR . ltrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $path), DIRECTORY_SEPARATOR);
    }
}


if (!function_exists('ensure_global_banners_schema')) {
    function ensure_global_banners_schema(): void
    {
        try {
            $exists = db()->first("SHOW TABLES LIKE 'server_banners'");
            if (!$exists) {
                return;
            }

            $columns = db()->select("SHOW COLUMNS FROM server_banners LIKE 'server_id'");
            if (!$columns) {
                return;
            }

            $isNullable = strtoupper((string) ($columns[0]['Null'] ?? 'NO')) === 'YES';
            if ($isNullable) {
                return;
            }

            $createRow = db()->first("SHOW CREATE TABLE server_banners");
            $createSql = (string) ($createRow['Create Table'] ?? array_values($createRow ?? [])[1] ?? '');

            preg_match_all('/CONSTRAINT `?([^` ]+)`? FOREIGN KEY \(`?server_id`?\)/i', $createSql, $matches);
            $constraintNames = $matches[1] ?? [];

            foreach ($constraintNames as $constraintName) {
                try {
                    db()->statement("ALTER TABLE server_banners DROP FOREIGN KEY `" . $constraintName . "`");
                } catch (Throwable $e) {
                }
            }

            try {
                db()->statement("ALTER TABLE server_banners MODIFY server_id INT NULL");
            } catch (Throwable $e) {
            }
            $columns = db()->select('SHOW COLUMNS FROM themes');
            $existing = array_map(static fn (array $row): string => (string) ($row['Field'] ?? ''), $columns);
            $optional = [
                'compatibility' => "ALTER TABLE themes ADD COLUMN compatibility VARCHAR(120) NULL AFTER package_path",
                'homepage_layout' => "ALTER TABLE themes ADD COLUMN homepage_layout VARCHAR(120) NULL AFTER compatibility",
                'supports_json' => "ALTER TABLE themes ADD COLUMN supports_json TEXT NULL AFTER homepage_layout",
            ];
            foreach ($optional as $column => $sql) {
                if (!in_array($column, $existing, true)) {
                    db()->statement($sql);
                }
            }
        } catch (Throwable $e) {
        }
    }
}


function coreModuleRegistry(): array
{
    return [
        [
            'module_key' => 'plugin_manager',
            'name' => 'Plugin Manager',
            'type' => 'core',
            'source' => 'internal',
            'version' => '1.0.0',
            'description' => 'Core module and plugin registry manager for TopFlame.',
            'is_enabled' => 1,
            'is_locked' => 1,
            'path' => '/admin/plugins',
        ],
        [
            'module_key' => 'server_listings',
            'name' => 'Server Listings',
            'type' => 'core',
            'source' => 'internal',
            'version' => '1.0.0',
            'description' => 'Public server listing, detail pages, and search/filter logic.',
            'is_enabled' => 1,
            'is_locked' => 1,
            'path' => '/servers',
        ],
        [
            'module_key' => 'voting_system',
            'name' => 'Voting System',
            'type' => 'core',
            'source' => 'internal',
            'version' => '1.0.0',
            'description' => 'Vote gateway, vote tracking, and ranking score updates.',
            'is_enabled' => 1,
            'is_locked' => 0,
            'path' => '/vote-gateway',
        ],
        [
            'module_key' => 'premium_system',
            'name' => 'Premium System',
            'type' => 'core',
            'source' => 'internal',
            'version' => '1.0.0',
            'description' => 'Premium boosts, branding, and premium management.',
            'is_enabled' => 1,
            'is_locked' => 0,
            'path' => '/admin/premium',
        ],
        [
            'module_key' => 'banner_system',
            'name' => 'Banner System',
            'type' => 'core',
            'source' => 'internal',
            'version' => '1.0.0',
            'description' => 'Global banner inventory and per-server gateway HTML output.',
            'is_enabled' => 1,
            'is_locked' => 0,
            'path' => '/admin/banners',
        ],
        [
            'module_key' => 'user_dashboard',
            'name' => 'User Dashboard',
            'type' => 'core',
            'source' => 'internal',
            'version' => '1.0.0',
            'description' => 'User control center, server management pages, and banner codes.',
            'is_enabled' => 1,
            'is_locked' => 1,
            'path' => '/dashboard',
        ],
        [
            'module_key' => 'admin_dashboard',
            'name' => 'Admin Dashboard',
            'type' => 'core',
            'source' => 'internal',
            'version' => '1.0.0',
            'description' => 'Administrative pages for servers, users, premium, banners, and logs.',
            'is_enabled' => 1,
            'is_locked' => 1,
            'path' => '/admin',
        ],
        [
            'module_key' => 'installer',
            'name' => 'Installer',
            'type' => 'core',
            'source' => 'internal',
            'version' => '1.0.0',
            'description' => 'Installation wizard, diagnostics, and setup flow.',
            'is_enabled' => 1,
            'is_locked' => 1,
            'path' => '/installer',
        ],
        [
            'module_key' => 'notifications',
            'name' => 'Notifications',
            'type' => 'core',
            'source' => 'internal',
            'version' => '0.1.0',
            'description' => 'Reserved core module for future live notifications support.',
            'is_enabled' => 0,
            'is_locked' => 0,
            'path' => null,
        ],
        [
            'module_key' => 'messages',
            'name' => 'Messages',
            'type' => 'core',
            'source' => 'internal',
            'version' => '0.1.0',
            'description' => 'Reserved core module for future private messaging support.',
            'is_enabled' => 0,
            'is_locked' => 0,
            'path' => null,
        ],
    ];
}

function ensureModulesTable(): void
{
    try {
        db()->statement(
            "CREATE TABLE IF NOT EXISTS modules (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                module_key VARCHAR(120) NOT NULL UNIQUE,
                name VARCHAR(160) NOT NULL,
                type ENUM('core','plugin') NOT NULL DEFAULT 'core',
                source ENUM('internal','external') NOT NULL DEFAULT 'internal',
                version VARCHAR(40) NOT NULL DEFAULT '1.0.0',
                description TEXT NULL,
                is_enabled TINYINT(1) NOT NULL DEFAULT 1,
                is_locked TINYINT(1) NOT NULL DEFAULT 0,
                path VARCHAR(255) NULL,
                created_at DATETIME NULL,
                updated_at DATETIME NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {
    }
}

function scanExternalPlugins(): array
{
    $pluginsPath = BASE_PATH . '/plugins';
    if (!is_dir($pluginsPath)) {
        return [];
    }

    $results = [];
    foreach (glob($pluginsPath . '/*/plugin.json') ?: [] as $manifestPath) {
        $decoded = json_decode((string) file_get_contents($manifestPath), true);
        if (!is_array($decoded) || empty($decoded['key']) || empty($decoded['name'])) {
            continue;
        }

        $results[] = [
            'module_key' => (string) $decoded['key'],
            'name' => (string) $decoded['name'],
            'type' => 'plugin',
            'source' => 'external',
            'version' => (string) ($decoded['version'] ?? '1.0.0'),
            'description' => (string) ($decoded['description'] ?? 'External plugin'),
            'is_enabled' => !empty($decoded['enabled_by_default']) ? 1 : 0,
            'is_locked' => 0,
            'path' => str_replace(BASE_PATH, '', dirname($manifestPath)),
        ];
    }

    return $results;
}

function syncModulesRegistry(): void
{
    ensureModulesTable();
    $allModules = array_merge(coreModuleRegistry(), scanExternalPlugins());

    foreach ($allModules as $module) {
        $existing = db()->first("SELECT id, is_enabled, is_locked FROM modules WHERE module_key = :module_key LIMIT 1", [
            'module_key' => $module['module_key'],
        ]);

        if ($existing) {
            db()->statement(
                "UPDATE modules
                 SET name = :name,
                     type = :type,
                     source = :source,
                     version = :version,
                     description = :description,
                     is_locked = :is_locked,
                     path = :path,
                     updated_at = NOW()
                 WHERE module_key = :module_key",
                [
                    'module_key' => $module['module_key'],
                    'name' => $module['name'],
                    'type' => $module['type'],
                    'source' => $module['source'],
                    'version' => $module['version'],
                    'description' => $module['description'],
                    'is_locked' => $module['is_locked'],
                    'path' => $module['path'],
                ]
            );
        } else {
            db()->statement(
                "INSERT INTO modules (module_key, name, type, source, version, description, is_enabled, is_locked, path, created_at, updated_at)
                 VALUES (:module_key, :name, :type, :source, :version, :description, :is_enabled, :is_locked, :path, NOW(), NOW())",
                [
                    'module_key' => $module['module_key'],
                    'name' => $module['name'],
                    'type' => $module['type'],
                    'source' => $module['source'],
                    'version' => $module['version'],
                    'description' => $module['description'],
                    'is_enabled' => $module['is_enabled'],
                    'is_locked' => $module['is_locked'],
                    'path' => $module['path'],
                ]
            );
        }
    }
}

function moduleEnabled(string $moduleKey): bool
{
    ensureModulesTable();
    syncModulesRegistry();
    $row = db()->first("SELECT is_enabled FROM modules WHERE module_key = :module_key LIMIT 1", [
        'module_key' => $moduleKey,
    ]);

    return (int) ($row['is_enabled'] ?? 0) === 1;
}


function ensureModuleMigrationsTable(): void
{
    try {
        db()->statement(
            "CREATE TABLE IF NOT EXISTS module_migrations (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                module_key VARCHAR(120) NOT NULL,
                version VARCHAR(40) NOT NULL,
                migration_name VARCHAR(190) NOT NULL,
                executed_at DATETIME NULL,
                UNIQUE KEY uq_module_migration (module_key, version, migration_name)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {
    }
}

function pluginUploadTempPath(): string
{
    $path = BASE_PATH . '/storage/plugin_uploads';
    if (!is_dir($path)) {
        @mkdir($path, 0775, true);
    }
    return $path;
}

function normalizePluginManifest(array $manifest, string $pluginDirName = ''): array
{
    $key = trim((string) ($manifest['key'] ?? ''));
    $name = trim((string) ($manifest['name'] ?? ''));
    if ($key === '' || $name === '') {
        throw new RuntimeException('Plugin manifest must include both "key" and "name".');
    }

    if (!preg_match('/^[a-z0-9_\-]+$/i', $key)) {
        throw new RuntimeException('Plugin key contains invalid characters.');
    }

    return [
        'key' => $key,
        'name' => $name,
        'version' => trim((string) ($manifest['version'] ?? '1.0.0')),
        'description' => trim((string) ($manifest['description'] ?? 'External plugin')),
        'author' => trim((string) ($manifest['author'] ?? 'Unknown')),
        'entry' => trim((string) ($manifest['entry'] ?? 'plugin.php')),
        'requires_sql' => !empty($manifest['requires_sql']),
        'install_sql' => trim((string) ($manifest['install_sql'] ?? 'install.sql')),
        'update_sql' => trim((string) ($manifest['update_sql'] ?? 'update.sql')),
        'uninstall_sql' => trim((string) ($manifest['uninstall_sql'] ?? 'uninstall.sql')),
        'enabled_by_default' => !empty($manifest['enabled_by_default']) ? 1 : 0,
        'directory' => $pluginDirName !== '' ? $pluginDirName : $key,
    ];
}

function pluginPath(string $dir): string
{
    return BASE_PATH . '/plugins/' . trim($dir, '/');
}

function recursiveDeleteDirectory(string $dir): void
{
    if (!is_dir($dir)) {
        return;
    }

    $items = scandir($dir);
    if (!is_array($items)) {
        return;
    }

    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) {
            recursiveDeleteDirectory($path);
        } else {
            @unlink($path);
        }
    }

    @rmdir($dir);
}

function runSqlStatements(PDO $pdo, string $sql, string $moduleKey, string $version, string $migrationName): void
{
    ensureModuleMigrationsTable();

    $alreadyRan = db()->first(
        "SELECT id FROM module_migrations WHERE module_key = :module_key AND version = :version AND migration_name = :migration_name LIMIT 1",
        [
            'module_key' => $moduleKey,
            'version' => $version,
            'migration_name' => $migrationName,
        ]
    );
    if ($alreadyRan) {
        return;
    }

    $statements = array_filter(array_map('trim', preg_split('/;\s*\n|;\s*$/m', $sql) ?: []));
    if (!$statements) {
        db()->statement(
            "INSERT INTO module_migrations (module_key, version, migration_name, executed_at) VALUES (:module_key, :version, :migration_name, NOW())",
            ['module_key' => $moduleKey, 'version' => $version, 'migration_name' => $migrationName]
        );
        return;
    }

    foreach ($statements as $statement) {
        $trimmed = trim($statement);
        if ($trimmed === '' || str_starts_with($trimmed, '--')) {
            continue;
        }
        $pdo->exec($trimmed);
    }

    db()->statement(
        "INSERT INTO module_migrations (module_key, version, migration_name, executed_at) VALUES (:module_key, :version, :migration_name, NOW())",
        ['module_key' => $moduleKey, 'version' => $version, 'migration_name' => $migrationName]
    );
}

function installOrUpdatePluginFromDirectory(string $sourceDir): array
{
    ensureModulesTable();
    ensureModuleMigrationsTable();

    $manifestPath = rtrim($sourceDir, '/\\') . DIRECTORY_SEPARATOR . 'plugin.json';
    if (!is_file($manifestPath)) {
        throw new RuntimeException('plugin.json was not found in the plugin package.');
    }

    $decoded = json_decode((string) file_get_contents($manifestPath), true);
    if (!is_array($decoded)) {
        throw new RuntimeException('plugin.json is invalid JSON.');
    }

    $dirName = basename($sourceDir);
    $plugin = normalizePluginManifest($decoded, $dirName);
    $targetDir = pluginPath($plugin['directory']);
    $existing = db()->first("SELECT * FROM modules WHERE module_key = :module_key LIMIT 1", ['module_key' => $plugin['key']]);

    if (is_dir($targetDir)) {
        recursiveDeleteDirectory($targetDir);
    }
    @mkdir(dirname($targetDir), 0775, true);
    if (!@rename($sourceDir, $targetDir)) {
        throw new RuntimeException('Could not move plugin files into the plugins directory.');
    }

    $pdo = db()->pdo();

    $installSqlPath = $targetDir . DIRECTORY_SEPARATOR . $plugin['install_sql'];
    $updateSqlPath = $targetDir . DIRECTORY_SEPARATOR . $plugin['update_sql'];

    if (!$existing) {
        db()->statement(
            "INSERT INTO modules (module_key, name, type, source, version, description, is_enabled, is_locked, path, created_at, updated_at)
             VALUES (:module_key, :name, 'plugin', 'external', :version, :description, :is_enabled, 0, :path, NOW(), NOW())",
            [
                'module_key' => $plugin['key'],
                'name' => $plugin['name'],
                'version' => $plugin['version'],
                'description' => $plugin['description'],
                'is_enabled' => $plugin['enabled_by_default'],
                'path' => '/plugins/' . $plugin['directory'],
            ]
        );

        if ($plugin['requires_sql'] && is_file($installSqlPath)) {
            runSqlStatements($pdo, (string) file_get_contents($installSqlPath), $plugin['key'], $plugin['version'], basename($plugin['install_sql']));
        }
    } else {
        db()->statement(
            "UPDATE modules
             SET name = :name,
                 version = :version,
                 description = :description,
                 path = :path,
                 updated_at = NOW()
             WHERE module_key = :module_key",
            [
                'module_key' => $plugin['key'],
                'name' => $plugin['name'],
                'version' => $plugin['version'],
                'description' => $plugin['description'],
                'path' => '/plugins/' . $plugin['directory'],
            ]
        );

        if ($plugin['requires_sql'] && is_file($updateSqlPath)) {
            runSqlStatements($pdo, (string) file_get_contents($updateSqlPath), $plugin['key'], $plugin['version'], basename($plugin['update_sql']));
        }
    }

    return [
        'manifest' => $plugin,
        'installed' => $existing ? false : true,
        'updated' => $existing ? true : false,
    ];
}

function uninstallPluginModule(array $module, bool $deleteFiles = false): void
{
    ensureModuleMigrationsTable();

    $moduleKey = (string) ($module['module_key'] ?? '');
    $modulePath = (string) ($module['path'] ?? '');

    if ($moduleKey === '' || (string) ($module['type'] ?? '') !== 'plugin') {
        throw new RuntimeException('Only external plugins can be uninstalled.');
    }

    $relative = trim(str_replace('/plugins/', '', $modulePath), '/');
    $pluginDir = pluginPath($relative);
    $manifestPath = $pluginDir . DIRECTORY_SEPARATOR . 'plugin.json';

    if (is_file($manifestPath)) {
        $decoded = json_decode((string) file_get_contents($manifestPath), true);
        if (is_array($decoded)) {
            $plugin = normalizePluginManifest($decoded, basename($pluginDir));
            $uninstallPath = $pluginDir . DIRECTORY_SEPARATOR . $plugin['uninstall_sql'];
            if (is_file($uninstallPath)) {
                runSqlStatements(db()->pdo(), (string) file_get_contents($uninstallPath), $moduleKey, (string) ($module['version'] ?? '0.0.0'), basename($plugin['uninstall_sql']));
            }
        }
    }

    db()->statement("DELETE FROM modules WHERE module_key = :module_key", ['module_key' => $moduleKey]);

    if ($deleteFiles && is_dir($pluginDir)) {
        recursiveDeleteDirectory($pluginDir);
    }
}


function ensureCoreUpdaterTables(): void
{
    try {
        db()->statement(
            "CREATE TABLE IF NOT EXISTS core_update_logs (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                admin_user_id BIGINT UNSIGNED NULL,
                package_name VARCHAR(190) NOT NULL,
                package_version VARCHAR(60) NULL,
                status ENUM('started','completed','failed') NOT NULL DEFAULT 'started',
                backup_path VARCHAR(255) NULL,
                details TEXT NULL,
                created_at DATETIME NULL,
                updated_at DATETIME NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {
    }
}

function coreUpdateStoragePath(): string
{
    $path = BASE_PATH . '/storage/core-updater';
    if (!is_dir($path)) {
        @mkdir($path, 0775, true);
    }
    foreach (['incoming', 'extract', 'backups'] as $dir) {
        if (!is_dir($path . '/' . $dir)) {
            @mkdir($path . '/' . $dir, 0775, true);
        }
    }
    return $path;
}

function createCoreUpdateBackup(string $label = 'backup'): string
{
    $base = coreUpdateStoragePath() . '/backups';
    $stamp = date('Ymd_His');
    $safeLabel = preg_replace('/[^a-zA-Z0-9_\-]+/', '-', $label) ?: 'update';
    $zipPath = $base . '/core_' . $safeLabel . '_' . $stamp . '.zip';

    $exclude = [
        BASE_PATH . '/storage/core-updater/backups',
        BASE_PATH . '/storage/core-updater/incoming',
        BASE_PATH . '/storage/core-updater/extract',
    ];

    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new RuntimeException('Could not create core backup ZIP.');
    }

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator(BASE_PATH, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $file) {
        $path = $file->getPathname();
        $skip = false;
        foreach ($exclude as $ex) {
            if (str_starts_with($path, $ex)) {
                $skip = true;
                break;
            }
        }
        if ($skip) {
            continue;
        }

        $relative = ltrim(str_replace(BASE_PATH, '', $path), DIRECTORY_SEPARATOR);
        if ($relative === '') {
            continue;
        }

        if ($file->isDir()) {
            $zip->addEmptyDir(str_replace('\\', '/', $relative));
        } else {
            $zip->addFile($path, str_replace('\\', '/', $relative));
        }
    }

    $zip->close();
    return str_replace(BASE_PATH, '', $zipPath);
}

function executeSqlBatch(PDO $pdo, string $sql): void
{
    $statements = preg_split('/;\s*(?:\r?\n|$)/', $sql) ?: [];
    foreach ($statements as $statement) {
        $statement = trim($statement);
        if ($statement === '' || str_starts_with($statement, '--')) {
            continue;
        }
        $pdo->exec($statement);
    }
}

function validateCoreUpdateManifest(array $manifest): array
{
    $name = trim((string) ($manifest['name'] ?? ''));
    $version = trim((string) ($manifest['version'] ?? ''));
    if ($name === '' || $version === '') {
        throw new RuntimeException('Update manifest must include "name" and "version".');
    }

    return [
        'name' => $name,
        'version' => $version,
        'description' => trim((string) ($manifest['description'] ?? 'Core update package')),
        'files_dir' => trim((string) ($manifest['files_dir'] ?? 'files')),
        'sql_file' => trim((string) ($manifest['sql_file'] ?? 'update.sql')),
        'allow_delete' => !empty($manifest['allow_delete']),
    ];
}

function applyCoreUpdatePackage(string $zipPath, int $adminUserId = 0): array
{
    ensureCoreUpdaterTables();

    $storage = coreUpdateStoragePath();
    $token = bin2hex(random_bytes(8));
    $extractDir = $storage . '/extract/' . $token;
    @mkdir($extractDir, 0775, true);

    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) {
        throw new RuntimeException('Could not open the update ZIP package.');
    }
    if (!$zip->extractTo($extractDir)) {
        $zip->close();
        throw new RuntimeException('Could not extract the update ZIP package.');
    }
    $zip->close();

    $entries = array_values(array_filter(scandir($extractDir) ?: [], static fn(string $entry): bool => !in_array($entry, ['.', '..'], true)));
    $root = $extractDir;
    if (count($entries) === 1 && is_dir($extractDir . '/' . $entries[0])) {
        $root = $extractDir . '/' . $entries[0];
    }

    $manifestPath = $root . '/update.json';
    if (!is_file($manifestPath)) {
        throw new RuntimeException('update.json was not found in the core update package.');
    }

    $decoded = json_decode((string) file_get_contents($manifestPath), true);
    if (!is_array($decoded)) {
        throw new RuntimeException('update.json is invalid JSON.');
    }
    $manifest = validateCoreUpdateManifest($decoded);

    $logId = null;
    db()->statement(
        "INSERT INTO core_update_logs (admin_user_id, package_name, package_version, status, created_at, updated_at)
         VALUES (:admin_user_id, :package_name, :package_version, 'started', NOW(), NOW())",
        [
            'admin_user_id' => $adminUserId > 0 ? $adminUserId : null,
            'package_name' => $manifest['name'],
            'package_version' => $manifest['version'],
        ]
    );
    $logId = (int) db()->lastInsertId();

    try {
        $backupPath = createCoreUpdateBackup($manifest['name'] . '_' . $manifest['version']);
        db()->statement(
            "UPDATE core_update_logs SET backup_path = :backup_path, details = :details, updated_at = NOW() WHERE id = :id",
            [
                'id' => $logId,
                'backup_path' => $backupPath,
                'details' => 'Backup created successfully.',
            ]
        );

        $filesDir = rtrim($root . '/' . ltrim($manifest['files_dir'], '/'), '/');
        if (is_dir($filesDir)) {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($filesDir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );
            foreach ($iterator as $file) {
                $source = $file->getPathname()
                ;
                $relative = ltrim(str_replace($filesDir, '', $source), DIRECTORY_SEPARATOR);
                if ($relative === '') {
                    continue;
                }
                $target = BASE_PATH . '/' . str_replace('\\', '/', $relative);

                if ($file->isDir()) {
                    if (!is_dir($target)) {
                        @mkdir($target, 0775, true);
                    }
                } else {
                    if (!is_dir(dirname($target))) {
                        @mkdir(dirname($target), 0775, true);
                    }
                    if (!@copy($source, $target)) {
                        throw new RuntimeException('Could not copy update file: ' . $relative);
                    }
                }
            }
        }

        $sqlPath = $root . '/' . ltrim($manifest['sql_file'], '/');
        if (is_file($sqlPath)) {
            executeSqlBatch(db()->pdo(), (string) file_get_contents($sqlPath));
        }

        db()->statement(
            "UPDATE core_update_logs SET status = 'completed', details = :details, updated_at = NOW() WHERE id = :id",
            [
                'id' => $logId,
                'details' => 'Update applied successfully.',
            ]
        );

        return [
            'manifest' => $manifest,
            'backup_path' => $backupPath,
            'log_id' => $logId,
        ];
    } catch (Throwable $e) {
        if ($logId) {
            db()->statement(
                "UPDATE core_update_logs SET status = 'failed', details = :details, updated_at = NOW() WHERE id = :id",
                [
                    'id' => $logId,
                    'details' => 'Update failed: ' . $e->getMessage(),
                ]
            );
        }
        throw $e;
    } finally {
        if (is_dir($extractDir)) {
            $it = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($it as $file) {
                $file->isDir() ? @rmdir($file->getPathname()) : @unlink($file->getPathname());
            }
            @rmdir($extractDir);
        }
    }
}


if (!function_exists('ensureThemesTable')) {
    function ensureThemesTable(): void
    {
        try {
            db()->statement("CREATE TABLE IF NOT EXISTS themes (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                theme_key VARCHAR(120) NOT NULL UNIQUE,
                name VARCHAR(160) NOT NULL,
                version VARCHAR(40) NOT NULL DEFAULT '1.0.0',
                author VARCHAR(120) NULL,
                description TEXT NULL,
                preview_image VARCHAR(255) NULL,
                css_path VARCHAR(255) NULL,
                package_path VARCHAR(255) NULL,
                compatibility VARCHAR(120) NULL,
                homepage_layout VARCHAR(120) NULL,
                supports_json TEXT NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 0,
                created_at DATETIME NULL,
                updated_at DATETIME NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        } catch (Throwable $e) {
        }
    }
}

if (!function_exists('themeManagerStoragePath')) {
    function themeManagerStoragePath(): string
    {
        $path = BASE_PATH . '/storage/theme-manager';
        if (!is_dir($path)) {
            @mkdir($path, 0775, true);
        }
        foreach (['incoming', 'extract'] as $dir) {
            if (!is_dir($path . '/' . $dir)) {
                @mkdir($path . '/' . $dir, 0775, true);
            }
        }
        return $path;
    }
}

if (!function_exists('themeManagerDeleteDir')) {
    function themeManagerDeleteDir(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $items = scandir($dir);
        if (!is_array($items)) {
            return;
        }
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path)) {
                themeManagerDeleteDir($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }
}

if (!function_exists('scanThemes')) {
    function scanThemes(): array
    {
        $themesPath = BASE_PATH . '/themes';
        if (!is_dir($themesPath)) {
            return [];
        }

        $results = [];
        foreach (glob($themesPath . '/*/theme.json') ?: [] as $manifestPath) {
            $decoded = json_decode((string) file_get_contents($manifestPath), true);
            if (!is_array($decoded) || empty($decoded['key']) || empty($decoded['name'])) {
                continue;
            }

            $dir = basename(dirname($manifestPath));
            $preview = trim((string) ($decoded['preview_image'] ?? ''));
            $css = trim((string) ($decoded['css'] ?? 'theme.css'));
            $supports = $decoded['supports'] ?? [];
            if (!is_array($supports)) {
                $supports = [];
            }

            $results[] = [
                'theme_key' => (string) $decoded['key'],
                'name' => (string) $decoded['name'],
                'version' => (string) ($decoded['version'] ?? '1.0.0'),
                'author' => (string) ($decoded['author'] ?? ''),
                'description' => (string) ($decoded['description'] ?? ''),
                'preview_image' => $preview !== '' ? '/themes/' . $dir . '/' . ltrim($preview, '/') : null,
                'css_path' => '/themes/' . $dir . '/' . ltrim($css, '/'),
                'package_path' => '/themes/' . $dir,
                'compatibility' => (string) ($decoded['compatibility'] ?? ''),
                'homepage_layout' => (string) ($decoded['homepage_layout'] ?? ''),
                'supports_json' => json_encode(array_values(array_map('strval', $supports)), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ];
        }

        return $results;
    }
}

if (!function_exists('syncThemesRegistry')) {
    function syncThemesRegistry(): void
    {
        ensureThemesTable();

        foreach (scanThemes() as $theme) {
            $existing = db()->first(
                "SELECT id FROM themes WHERE theme_key = :theme_key LIMIT 1",
                ['theme_key' => $theme['theme_key']]
            );

            if ($existing) {
                db()->statement(
                    "UPDATE themes
                     SET name = :name,
                         version = :version,
                         author = :author,
                         description = :description,
                         preview_image = :preview_image,
                         css_path = :css_path,
                         package_path = :package_path,
                         compatibility = :compatibility,
                         homepage_layout = :homepage_layout,
                         supports_json = :supports_json,
                         updated_at = NOW()
                     WHERE theme_key = :theme_key",
                    [
                        'theme_key' => $theme['theme_key'],
                        'name' => $theme['name'],
                        'version' => $theme['version'],
                        'author' => $theme['author'],
                        'description' => $theme['description'],
                        'preview_image' => $theme['preview_image'],
                        'css_path' => $theme['css_path'],
                        'package_path' => $theme['package_path'],
                        'compatibility' => $theme['compatibility'],
                        'homepage_layout' => $theme['homepage_layout'],
                        'supports_json' => $theme['supports_json'],
                    ]
                );
            } else {
                db()->statement(
                    "INSERT INTO themes
                     (theme_key, name, version, author, description, preview_image, css_path, package_path, compatibility, homepage_layout, supports_json, is_active, created_at, updated_at)
                     VALUES
                     (:theme_key, :name, :version, :author, :description, :preview_image, :css_path, :package_path, :compatibility, :homepage_layout, :supports_json, 0, NOW(), NOW())",
                    [
                        'theme_key' => $theme['theme_key'],
                        'name' => $theme['name'],
                        'version' => $theme['version'],
                        'author' => $theme['author'],
                        'description' => $theme['description'],
                        'preview_image' => $theme['preview_image'],
                        'css_path' => $theme['css_path'],
                        'package_path' => $theme['package_path'],
                        'compatibility' => $theme['compatibility'],
                        'homepage_layout' => $theme['homepage_layout'],
                        'supports_json' => $theme['supports_json'],
                    ]
                );
            }
        }

        $active = db()->first("SELECT id FROM themes WHERE is_active = 1 LIMIT 1");
        if (!$active) {
            $default = db()->first("SELECT theme_key FROM themes ORDER BY id ASC LIMIT 1");
            if ($default) {
                db()->statement("UPDATE themes SET is_active = 1, updated_at = NOW() WHERE theme_key = :theme_key", [
                    'theme_key' => (string) $default['theme_key'],
                ]);
            }
        }
    }
}

if (!function_exists('activeThemeRow')) {
    function activeThemeRow(): ?array
    {
        try {
            ensureThemesTable();
            syncThemesRegistry();
            return db()->first("SELECT * FROM themes WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
        } catch (Throwable $e) {
            return null;
        }
    }
}

if (!function_exists('activeThemeCssPath')) {
    function activeThemeCssPath(): ?string
    {
        $theme = activeThemeRow();
        if (!$theme) {
            return null;
        }

        $cssPath = trim((string) ($theme['css_path'] ?? ''));
        return $cssPath !== '' ? $cssPath : null;
    }
}

if (!function_exists('resolveThemeView')) {
    function resolveThemeView(string $viewName): ?string
    {
        $theme = activeThemeRow();
        if (!$theme) {
            return null;
        }

        $packagePath = trim((string) ($theme['package_path'] ?? ''), '/');
        if ($packagePath === '') {
            return null;
        }

        $viewFile = BASE_PATH . '/' . $packagePath . '/views/' . trim($viewName, '/\\') . '.php';
        return is_file($viewFile) ? $viewFile : null;
    }
}

if (!function_exists('setActiveTheme')) {
    function setActiveTheme(string $themeKey): void
    {
        ensureThemesTable();
        syncThemesRegistry();

        $theme = db()->first("SELECT id FROM themes WHERE theme_key = :theme_key LIMIT 1", [
            'theme_key' => $themeKey,
        ]);

        if (!$theme) {
            throw new RuntimeException('Theme not found.');
        }

        db()->statement("UPDATE themes SET is_active = 0, updated_at = NOW()");
        db()->statement("UPDATE themes SET is_active = 1, updated_at = NOW() WHERE theme_key = :theme_key", [
            'theme_key' => $themeKey,
        ]);
    }
}

if (!function_exists('installUploadedThemeZip')) {
    function installUploadedThemeZip(array $file): void
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('ZIP extension is not enabled on this server.');
        }

        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Theme upload failed.');
        }

        $originalName = (string) ($file['name'] ?? 'theme.zip');
        if (strtolower(pathinfo($originalName, PATHINFO_EXTENSION)) !== 'zip') {
            throw new RuntimeException('Only ZIP theme packages are allowed.');
        }

        $storage = themeManagerStoragePath();
        $incoming = $storage . '/incoming/' . bin2hex(random_bytes(8)) . '.zip';
        $extractDir = $storage . '/extract/' . bin2hex(random_bytes(8));

        if (!@move_uploaded_file((string) $file['tmp_name'], $incoming)) {
            throw new RuntimeException('Could not store the uploaded theme ZIP.');
        }

        try {
            $zip = new ZipArchive();
            if ($zip->open($incoming) !== true) {
                throw new RuntimeException('Could not open the uploaded theme ZIP.');
            }

            @mkdir($extractDir, 0775, true);
            if (!$zip->extractTo($extractDir)) {
                $zip->close();
                throw new RuntimeException('Could not extract the uploaded theme ZIP.');
            }
            $zip->close();

            $entries = array_values(array_filter(scandir($extractDir) ?: [], static fn(string $entry): bool => !in_array($entry, ['.', '..'], true)));
            $themeRoot = $extractDir;
            if (count($entries) === 1 && is_dir($extractDir . '/' . $entries[0])) {
                $themeRoot = $extractDir . '/' . $entries[0];
            }

            $manifestPath = $themeRoot . '/theme.json';
            if (!is_file($manifestPath)) {
                throw new RuntimeException('theme.json was not found in the uploaded theme package.');
            }

            $decoded = json_decode((string) file_get_contents($manifestPath), true);
            if (!is_array($decoded) || empty($decoded['key']) || empty($decoded['name'])) {
                throw new RuntimeException('theme.json must include at least key and name.');
            }
            if (!preg_match('/^[a-z0-9_\-]+$/i', (string) $decoded['key'])) {
                throw new RuntimeException('Theme key may only contain letters, numbers, dashes, and underscores.');
            }
            $cssFile = trim((string) ($decoded['css'] ?? 'theme.css'));
            if ($cssFile === '' || !is_file($themeRoot . '/' . ltrim($cssFile, '/'))) {
                throw new RuntimeException('The theme package is missing its CSS file.');
            }
            if (!is_dir($themeRoot . '/views')) {
                throw new RuntimeException('The theme package must include a views directory with at least one override or layout.');
            }

            $dirName = basename($themeRoot);
            $targetDir = BASE_PATH . '/themes/' . $dirName;

            if (is_dir($targetDir)) {
                themeManagerDeleteDir($targetDir);
            }

            if (!is_dir(dirname($targetDir))) {
                @mkdir(dirname($targetDir), 0775, true);
            }

            if (!@rename($themeRoot, $targetDir)) {
                throw new RuntimeException('Could not move the theme package into the themes directory.');
            }

            ensureThemesTable();
            syncThemesRegistry();
        } finally {
            if (is_file($incoming)) {
                @unlink($incoming);
            }
            if (is_dir($extractDir)) {
                themeManagerDeleteDir($extractDir);
            }
        }
    }
}


if (!function_exists('resolveThemeLayoutFile')) {
    function resolveThemeLayoutFile(string $layoutName): ?string
    {
        $theme = activeThemeRow();
        if (!$theme) {
            return null;
        }

        $packagePath = trim((string) ($theme['package_path'] ?? ''), '/');
        if ($packagePath === '') {
            return null;
        }

        $layoutFile = BASE_PATH . '/' . $packagePath . '/views/layouts/' . trim($layoutName, '/\\') . '.php';
        return is_file($layoutFile) ? $layoutFile : null;
    }
}

if (!function_exists('themeLayoutOrDefault')) {
    function themeLayoutOrDefault(string $layoutName, string $defaultPath): string
    {
        $themeLayout = resolveThemeLayoutFile($layoutName);
        return $themeLayout ?? $defaultPath;
    }
}
