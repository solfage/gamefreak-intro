<section class="hero">
    <div class="hero-shell" style="max-width:820px;margin:0 auto">
        <div class="badge">Error <?= (int) $statusCode ?></div>
        <h1 class="title" style="font-size:42px"><?= e($title) ?></h1>
        <p class="subtitle"><?= e($message) ?></p>
        <div class="action-row" style="margin-top:22px">
            <a class="btn" href="/">Αρχική</a>
            <a class="btn-secondary" href="/servers">Servers</a>
        </div>
    </div>
</section>
