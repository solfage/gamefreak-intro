<?php
$websiteUrl = safeExternalUrl($server['website_url'] ?? null);
$registerUrl = safeExternalUrl($server['register_url'] ?? null);
$downloadUrl = safeExternalUrl($server['download_url'] ?? null);
$patchUrl = safeExternalUrl($server['patch_url'] ?? null);
$updaterUrl = safeExternalUrl($server['updater_url'] ?? null);
$statusClass = 'status-' . strtolower((string) ($server['status'] ?? 'pending'));
$features = [
    'GM Shop' => (int) ($server['feature_gm_shop'] ?? 0) === 1,
    'Buffer' => (int) ($server['feature_buffer'] ?? 0) === 1,
    'Gatekeeper' => (int) ($server['feature_gatekeeper'] ?? 0) === 1,
];
$xpTagValue = rtrim(rtrim(number_format((float) ($server['xp_rate'] ?? 1), 2, '.', ''), '0'), '.');
?>
<section class="hero">
    <div class="cover-banner <?= (int) $server['is_premium'] === 1 ? 'premium' : '' ?>" style="<?= (int) ($server['is_premium'] ?? 0) === 1 && !empty($server['banner_path']) ? "background-image:linear-gradient(180deg, rgba(7,10,24,.22), rgba(7,10,24,.82)), url('" . e($server['banner_path']) . "');background-size:cover;background-position:center;" : "" ?>">
        <div class="section-header" style="margin-bottom:12px">
            <div>
                <div class="action-row">
                    <?php if ((int) $server['is_premium'] === 1): ?><span class="badge badge-premium">Premium server</span><?php endif; ?>
                    <span class="status-badge <?= e($statusClass) ?>"><?= e($server['status']) ?></span>
                    <span class="server-tag"><strong>Chronicle</strong> <?= e((string) ($server['chronicle'] ?? '-')) ?></span>
                    <span class="server-tag"><strong>XP</strong> x<?= e($xpTagValue) ?></span>
                </div>
                <div class="section-header" style="margin:14px 0 0">
                    <div style="display:flex;gap:16px;align-items:center">
                        <?php if ((int) ($server['is_premium'] ?? 0) === 1 && !empty($server['logo_path'])): ?><img src="<?= e($server['logo_path']) ?>" alt="<?= e($server['title']) ?>" style="width:72px;height:72px;object-fit:cover;border-radius:18px;border:1px solid rgba(255,255,255,.14)"><?php endif; ?>
                        <div><h1 class="title" style="font-size:46px;margin-top:0"><?= e($server['title']) ?></h1></div>
                    </div>
                </div>
                <p class="subtitle"><?= e($server['short_description']) ?></p>
                <div class="badge-tag-row server-uptime-pill"><span class="listing-badge"><span class="k">Uptime</span> <?= e(rtrim(rtrim(number_format((float) ($server['uptime_percent'] ?? 100), 2, '.', ''), '0'), '.')) ?>%</span></div>

            </div>
            <div class="hero-panel" style="max-width:320px">
                <h3>Quick stats</h3>
                <div class="stats-grid">
                    <div class="stat-box"><span class="muted">Votes</span><strong><?= e((string) $server['raw_votes_total']) ?></strong></div>
                    <div class="stat-box"><span class="muted">Score</span><strong><?= e((string) $server['ranking_score']) ?></strong></div>
                    <div class="stat-box"><span class="muted">Views</span><strong><?= e((string) $server['views_count']) ?></strong></div>
                    <div class="stat-box"><span class="muted">XP Rate</span><strong>x<?= e($xpTagValue) ?></strong></div>
                </div>
            </div>
        </div>

        <div class="action-row" style="margin-top:20px">
            <a class="btn" href="<?= e(voteGatewayPath((int) $server['id'])) ?>">Open vote gateway</a>
            <?php if ($websiteUrl): ?><a class="btn-secondary" href="<?= e($websiteUrl) ?>" target="_blank" rel="noopener noreferrer nofollow">Website</a><?php endif; ?>
            <?php if ($registerUrl): ?><a class="btn-secondary" href="<?= e($registerUrl) ?>" target="_blank" rel="noopener noreferrer nofollow">Register</a><?php endif; ?>
            <?php if ($downloadUrl): ?><a class="btn-secondary" href="<?= e($downloadUrl) ?>" target="_blank" rel="noopener noreferrer nofollow">Download</a><?php endif; ?>
        </div>
    </div>
</section>

<?php if (!empty($banners)): ?>
<section class="section" style="padding-top:0">
    <div class="card">
        <div class="section-header">
            <div>
                <h2>Vote banners</h2>
                <p>External banner creatives που οδηγούν στο TopFlame vote gateway και επιστρέφουν εδώ.</p>
            </div>
        </div>
        <div class="grid grid-2">
            <?php foreach ($banners as $banner): ?>
                <div class="code-box">
                    <div class="section-header" style="margin-bottom:12px">
                        <div><strong><?= e($banner['title']) ?></strong><p><?= e((string) ($banner['size_label'] ?: 'Custom size')) ?></p></div>
                        <a class="btn-secondary" href="<?= e(appUrl('/vote-gateway?id=' . (int) $server['id'] . '&banner=' . (int) $banner['id'])) ?>" target="_blank" rel="noopener noreferrer">Open gateway</a>
                    </div>
                    <img src="<?= e($banner['image_url']) ?>" alt="<?= e($banner['title']) ?>" style="max-width:100%;height:auto;border-radius:12px">
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="section" style="padding-top:0">
    <div class="grid grid-2">
        <div class="stack">
            <div class="card">
                <h2>Server profile</h2>
                <div class="links-grid">
                    <div class="link-tile"><div class="muted">Chronicle</div><strong><?= e($server['chronicle']) ?></strong></div>
                    <div class="link-tile"><div class="muted">Country</div><strong><?= e($server['country'] ?: '—') ?></strong></div>
                    <div class="link-tile"><div class="muted">Language</div><strong><?= e($server['language'] ?: '—') ?></strong></div>
                    <div class="link-tile"><div class="muted">Premium until</div><strong><?= e($server['premium_until'] ?: '—') ?></strong></div>
                </div>

                <div class="table-wrap" style="margin-top:18px">
                    <table class="table">
                        <tbody>
                            <tr><th>XP Rate</th><td>x<?= e((string) $server['xp_rate']) ?></td></tr>
                            <tr><th>SP Rate</th><td>x<?= e((string) $server['sp_rate']) ?></td></tr>
                            <tr><th>Adena Rate</th><td>x<?= e((string) $server['adena_rate']) ?></td></tr>
                            <tr><th>Drop Rate</th><td>x<?= e((string) $server['drop_rate']) ?></td></tr>
                            <tr><th>Login Server</th><td><?= (int) ($server['login_server_status'] ?? 0) === 1 ? 'Online' : 'Offline' ?><?= !empty($server['login_ip']) ? ' · ' . e((string) $server['login_ip']) : '' ?><?= !empty($server['login_port']) ? ':' . e((string) $server['login_port']) : '' ?></td></tr>
                            <tr><th>Game Server</th><td><?= (int) ($server['game_server_status'] ?? 0) === 1 ? 'Online' : 'Offline' ?><?= !empty($server['game_ip']) ? ' · ' . e((string) $server['game_ip']) : '' ?><?= !empty($server['game_port']) ? ':' . e((string) $server['game_port']) : '' ?></td></tr>
                            <tr><th>Safe Enchant</th><td><?= e((string) ($server['safe_enchant'] ?? '—')) ?></td></tr>
                            <tr><th>Max Enchant</th><td><?= e((string) ($server['max_enchant'] ?? '—')) ?></td></tr>
                            <tr><th>Normal Enchant %</th><td><?= $server['normal_enchant_rate'] !== null ? e((string) $server['normal_enchant_rate']) . '%' : '—' ?></td></tr>
                            <tr><th>Blessed Enchant %</th><td><?= $server['blessed_enchant_rate'] !== null ? e((string) $server['blessed_enchant_rate']) . '%' : '—' ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card">
                <h2>Description</h2>
                <p class="muted" style="line-height:1.8;margin:0"><?= nl2br(e($server['full_description'])) ?></p>
            </div>
        </div>

        <div class="stack">
            <div class="card">
                <h2>Server Features</h2>
                <div class="links-grid">
                    <?php foreach ($features as $label => $enabled): ?>
                        <div class="link-tile">
                            <div class="muted"><?= e($label) ?></div>
                            <strong><?= $enabled ? '✓ Yes' : '✗ No' ?></strong>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="card">
                <h2>Useful links</h2>
                <div class="links-grid">
                    <div class="link-tile"><div class="muted">Website</div><?php if ($websiteUrl): ?><a href="<?= e($websiteUrl) ?>" target="_blank" rel="noopener noreferrer nofollow">Open website</a><?php else: ?><span class="muted">Μη διαθέσιμο</span><?php endif; ?></div>
                    <div class="link-tile"><div class="muted">Register</div><?php if ($registerUrl): ?><a href="<?= e($registerUrl) ?>" target="_blank" rel="noopener noreferrer nofollow">Create account</a><?php else: ?><span class="muted">Μη διαθέσιμο</span><?php endif; ?></div>
                    <div class="link-tile"><div class="muted">Download</div><?php if ($downloadUrl): ?><a href="<?= e($downloadUrl) ?>" target="_blank" rel="noopener noreferrer nofollow">Download files</a><?php else: ?><span class="muted">Μη διαθέσιμο</span><?php endif; ?></div>
                    <div class="link-tile"><div class="muted">Patch</div><?php if ($patchUrl): ?><a href="<?= e($patchUrl) ?>" target="_blank" rel="noopener noreferrer nofollow">Open patch</a><?php else: ?><span class="muted">Μη διαθέσιμο</span><?php endif; ?></div>
                    <div class="link-tile"><div class="muted">Updater</div><?php if ($updaterUrl): ?><a href="<?= e($updaterUrl) ?>" target="_blank" rel="noopener noreferrer nofollow">Open updater</a><?php else: ?><span class="muted">Μη διαθέσιμο</span><?php endif; ?></div>
                </div>
            </div>

            <div class="card premium">
                <h2>Player action box</h2>
                <p class="muted">Ο player περνάει από το TopFlame vote gateway, κάνει vote στο external site και μετά επιστρέφει εδώ.</p>
                <div class="action-row" style="margin-top:12px">
                    <a class="btn" href="<?= e(voteGatewayPath((int) $server['id'])) ?>">Vote through gateway</a>
                    <a class="btn-secondary" href="/servers">Back to rankings</a>
                </div>
            </div>
        </div>
    </div>
</section>
