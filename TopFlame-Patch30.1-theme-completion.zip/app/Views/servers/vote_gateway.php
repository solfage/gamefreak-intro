<section class="hero">
    <div class="hero-shell" style="max-width:980px;margin:0 auto">
        <div class="badge badge-premium">TopFlame Vote Gateway</div>
        <h1 class="title" style="font-size:42px">Vote flow for <span class="gold"><?= e($server['title']) ?></span></h1>
        <p class="subtitle">Ο player ήρθε από external banner/site, περνάει από το TopFlame gateway, συνεχίζει στο external vote page και μετά επιστρέφει ξανά στο server view.</p>

        <div class="grid grid-2" style="margin-top:22px">
            <div class="card">
                <h2>Step 1 · Open external vote</h2>
                <?php $externalVoteUrl = safeExternalUrl($server['vote_gateway_url'] ?? null); ?>
                <?php if ($externalVoteUrl): ?>
                    <p class="muted">Άνοιξε το external vote page του server σε νέο tab.</p>
                    <a class="btn" href="<?= e($externalVoteUrl) ?>" target="_blank" rel="noopener noreferrer nofollow">Continue to external vote</a>
                <?php else: ?>
                    <p class="muted">Δεν έχει οριστεί external vote URL για αυτόν τον server.</p>
                <?php endif; ?>

                <div class="code-box" style="margin-top:16px">
                    <label>Gateway link για external banners</label>
                    <input type="text" readonly value="<?= e(voteGatewayUrl((int) $server['id'])) ?>" onclick="this.select()">
                </div>
            </div>

            <div class="card premium">
                <h2>Step 2 · Complete and return</h2>
                <p class="muted">Αφού τελειώσεις στο external vote page, πάτα το κουμπί για να ολοκληρωθεί το flow και να γίνει επιστροφή στο server page.</p>
                <form method="post" action="/vote" style="margin-top:16px">
                    <?= csrfField() ?>
                    <input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>">
                    <button class="btn" type="submit">Complete vote &amp; return</button>
                </form>
                <div class="action-row" style="margin-top:12px">
                    <a class="btn-secondary" href="<?= e(serverViewUrl((int) $server['id'])) ?>">Return without vote</a>
                </div>
                <div class="form-note">Η επίσκεψη στο gateway αποθηκεύεται προσωρινά για αυτή τη συνεδρία ώστε το vote να γίνεται μόνο αφού προηγηθεί αυτό το βήμα.</div>
            </div>
        </div>

        <?php if (!empty($server['short_description'])): ?>
            <div class="card" style="margin-top:18px">
                <h3>About this server</h3>
                <p class="muted"><?= e($server['short_description']) ?></p>
            </div>
        <?php endif; ?>
    </div>
</section>
