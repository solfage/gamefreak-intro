<section class="hero">
    <div class="hero-shell" style="max-width:1100px;margin:0 auto">
        <div class="badge">Server Submission</div>
        <h1 class="title" style="font-size:42px"><?= e($pageTitle) ?></h1>
        <p class="subtitle">Fill in your server details using controlled options and technical settings.</p>

        <div class="card soft" style="margin-top:22px">
            <form method="post" action="<?= e($formAction) ?>" enctype="multipart/form-data">
                <?= csrfField() ?>
                <?php if (!empty($server['id'])): ?>
                    <input type="hidden" name="id" value="<?= (int) $server['id'] ?>">
                <?php endif; ?>

                <div class="grid grid-2">
                    <div class="form-group">
                        <label>Title *</label>
                        <input type="text" name="title" maxlength="180" required value="<?= e($server['title'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label>Chronicle</label>
                        <select name="chronicle" required>
                            <option value="">Select chronicle</option>
                            <?php foreach (($chronicleOptions ?? []) as $option): ?>
                                <option value="<?= e($option) ?>" <?= selectedIf($option, (string) ($server['chronicle'] ?? '')) ?>><?= e($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Short Description</label>
                    <input type="text" name="short_description" maxlength="300" required value="<?= e($server['short_description'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label>Full Description</label>
                    <textarea name="full_description" rows="6" required><?= e($server['full_description'] ?? '') ?></textarea>
                </div>

                <div class="grid grid-2">
                    <div class="form-group"><label>XP Rate</label><input type="number" step="0.01" min="0.01" name="xp_rate" required value="<?= e((string) ($server['xp_rate'] ?? '1.00')) ?>"></div>
                    <div class="form-group"><label>SP Rate</label><input type="number" step="0.01" min="0.01" name="sp_rate" required value="<?= e((string) ($server['sp_rate'] ?? '1.00')) ?>"></div>
                    <div class="form-group"><label>Adena Rate</label><input type="number" step="0.01" min="0.01" name="adena_rate" required value="<?= e((string) ($server['adena_rate'] ?? '1.00')) ?>"></div>
                    <div class="form-group"><label>Drop Rate</label><input type="number" step="0.01" min="0.01" name="drop_rate" required value="<?= e((string) ($server['drop_rate'] ?? '1.00')) ?>"></div>
                </div>

                <div class="grid grid-2">
                    <div class="form-group">
                        <label>Country</label>
                        <select name="country">
                            <option value="">Select country</option>
                            <?php foreach (($countryOptions ?? []) as $option): ?>
                                <option value="<?= e($option) ?>" <?= selectedIf($option, (string) ($server['country'] ?? '')) ?>><?= e($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Language</label>
                        <select name="language">
                            <option value="">Select language</option>
                            <?php foreach (($languageOptions ?? []) as $option): ?>
                                <option value="<?= e($option) ?>" <?= selectedIf($option, (string) ($server['language'] ?? '')) ?>><?= e($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="grid grid-2">
                    <div class="form-group"><label>Website URL *</label><input type="url" name="website_url" required value="<?= e($server['website_url'] ?? '') ?>"></div>
                    <div class="form-group"><label>Register URL</label><input type="url" name="register_url" value="<?= e($server['register_url'] ?? '') ?>"></div>
                    <div class="form-group"><label>Download URL</label><input type="url" name="download_url" value="<?= e($server['download_url'] ?? '') ?>"></div>
                    <div class="form-group"><label>Patch URL</label><input type="url" name="patch_url" value="<?= e($server['patch_url'] ?? '') ?>"></div>
                    <div class="form-group"><label>Updater URL</label><input type="url" name="updater_url" value="<?= e($server['updater_url'] ?? '') ?>"></div>
                    <div class="form-group">
                        <label>External Vote URL</label>
                        <input type="url" name="vote_gateway_url" placeholder="https://..." value="<?= e($server['vote_gateway_url'] ?? '') ?>">
                        <div class="form-note">Enter the external vote page for the server here. The TopFlame gateway link is generated automatically.</div>
                    </div>
                </div>

                
                <div class="card" style="margin-top:18px;padding:18px">
                    <div class="section-header" style="margin-bottom:12px">
                        <div>
                            <h3 style="margin:0">Premium Branding</h3>
                            <p style="margin:6px 0 0">Logo and header banner for premium servers.</p>
                        </div>
                        <?php if ((int) ($server['is_premium'] ?? 0) === 1 || isAdmin()): ?>
                            <span class="badge badge-premium">Premium branding enabled</span>
                        <?php else: ?>
                            <span class="pill">Premium only</span>
                        <?php endif; ?>
                    </div>
                    <?php $brandingEnabled = (int) ($server['is_premium'] ?? 0) === 1 || isAdmin(); ?>
                    <div class="grid grid-2">
                        <div class="form-group">
                            <label>Logo Upload</label>
                            <input type="file" name="logo_file" accept="image/png,image/jpeg,image/webp,image/gif" <?= $brandingEnabled ? '' : 'disabled' ?>>
                            <?php if (!empty($server['logo_path'])): ?>
                                <div class="form-note">Current logo:</div>
                                <div style="margin-top:10px"><img src="<?= e(public_asset_url((string) $server['logo_path'])) ?>" alt="Current Logo" style="max-width:120px;max-height:120px;border-radius:16px;border:1px solid rgba(255,255,255,.08);padding:8px;background:rgba(255,255,255,.03)"></div>
                            <?php elseif (!$brandingEnabled): ?>
                                <div class="form-note">Premium required for logo upload.</div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Header Banner Upload</label>
                            <input type="file" name="banner_file" accept="image/png,image/jpeg,image/webp,image/gif" <?= $brandingEnabled ? '' : 'disabled' ?>>
                            <?php if (!empty($server['banner_path'])): ?>
                                <div class="form-note">Current header banner:</div>
                                <div style="margin-top:10px"><img src="<?= e(public_asset_url((string) $server['banner_path'])) ?>" alt="Current Header Banner" style="max-width:100%;max-height:140px;border-radius:16px;border:1px solid rgba(255,255,255,.08);padding:6px;background:rgba(255,255,255,.03)"></div>
                            <?php elseif (!$brandingEnabled): ?>
                                <div class="form-note">Premium required for header banner upload.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-note">For non-premium servers, branding uploads are ignored. If you do not upload a new file, the current branding is kept.</div>
                </div>

                <div class="card" style="margin-top:18px;padding:18px">
                    <h3 style="margin-top:0">Server Network</h3>
                    <input type="hidden" name="login_online" value="online">
                    <input type="hidden" name="game_online" value="online">
                    <div class="grid grid-2">
                        <div class="form-group"><label>Login Hostname / IP</label><input type="text" maxlength="100" name="login_ip" placeholder="login.example.com or 127.0.0.1" value="<?= e((string) ($server['login_ip'] ?? '')) ?>"></div>
                        <div class="form-group"><label>Login Port</label><input type="number" min="1" max="65535" name="login_port" placeholder="2106" value="<?= e((string) ($server['login_port'] ?? '')) ?>"></div>
                        <div class="form-group"><label>Game Hostname / IP</label><input type="text" maxlength="100" name="game_ip" placeholder="game.example.com or 127.0.0.1" value="<?= e((string) ($server['game_ip'] ?? '')) ?>"></div>
                        <div class="form-group"><label>Game Port</label><input type="number" min="1" max="65535" name="game_port" placeholder="7777" value="<?= e((string) ($server['game_port'] ?? '')) ?>"></div>
                    </div>
                    <div class="form-group" style="margin-top:8px">
                        <label style="display:flex;gap:10px;align-items:center"><input type="checkbox" name="online_players_enabled" value="1" <?= !empty($server['online_players_enabled']) ? 'checked' : '' ?>> Enable Online Players display</label>
                    </div>
                    <div class="form-note">Uptime percentage is always enabled by the system. Online Players can be toggled by the server owner.</div>
                    <div class="form-note">Only online servers can be submitted. Offline servers are not allowed.</div>
                </div>
                </div>
                </div>

                <div class="card" style="margin-top:18px;padding:18px">
                    <h3 style="margin-top:0">Custom Features</h3>
                    <div class="action-row" style="gap:24px;flex-wrap:wrap">
                        <label><input type="checkbox" name="feature_gm_shop" value="1" <?= !empty($server['feature_gm_shop']) ? 'checked' : '' ?>> GM Shop</label>
                        <label><input type="checkbox" name="feature_buffer" value="1" <?= !empty($server['feature_buffer']) ? 'checked' : '' ?>> Buffer</label>
                        <label><input type="checkbox" name="feature_gatekeeper" value="1" <?= !empty($server['feature_gatekeeper']) ? 'checked' : '' ?>> Gatekeeper</label>
                    </div>
                </div>

                <div class="card" style="margin-top:18px;padding:18px">
                    <h3 style="margin-top:0">Enchant Settings</h3>
                    <div class="grid grid-2">
                        <div class="form-group"><label>Safe Enchant</label><input type="number" min="0" name="safe_enchant" value="<?= e((string) ($server['safe_enchant'] ?? '')) ?>"></div>
                        <div class="form-group"><label>Max Enchant</label><input type="number" min="0" name="max_enchant" value="<?= e((string) ($server['max_enchant'] ?? '')) ?>"></div>
                        <div class="form-group"><label>Normal Enchant %</label><input type="number" step="0.01" min="0" max="100" name="normal_enchant_rate" value="<?= e((string) ($server['normal_enchant_rate'] ?? '')) ?>"></div>
                        <div class="form-group"><label>Blessed Enchant %</label><input type="number" step="0.01" min="0" max="100" name="blessed_enchant_rate" value="<?= e((string) ($server['blessed_enchant_rate'] ?? '')) ?>"></div>
                    </div>
                </div>

                <div class="action-row" style="margin-top:18px">
                    <button class="btn" type="submit"><?= e($submitLabel ?? 'Save server') ?></button>
                    <a class="btn-secondary" href="/dashboard">Back to panel</a>
                </div>
            </form>
        </div>
    </div>
</section>
