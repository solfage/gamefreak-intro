<section class="hero">
    <div class="hero-shell">
        <div class="section-header" style="margin-bottom:0">
            <div>
                <div class="badge">Server Rankings</div>
                <h1 class="title" style="font-size:44px">Browse the <span class="gold">TopFlame</span> server list</h1>
                <p class="subtitle">Αναζήτηση, filters, premium highlighting και πιο όμορφο listing layout για να φαίνονται καλύτερα οι servers.</p>
            </div>
            <a class="btn" href="/dashboard/servers/create">Submit server</a>
        </div>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="card soft">
        <form method="get" action="/servers">
            <div class="grid grid-3">
                <div class="form-group">
                    <label>Αναζήτηση</label>
                    <input type="text" name="q" value="<?= e($filters['q'] ?? '') ?>" placeholder="π.χ. interlude, pvp, low rate">
                </div>
                <div class="form-group">
                    <label>Chronicle</label>
                    <select name="chronicle">
                        <option value="">Όλα</option>
                        <?php foreach ($chronicles as $row): ?>
                            <option value="<?= e($row['chronicle']) ?>" <?= selectedIf((string) $row['chronicle'], $filters['chronicle'] ?? '') ?>><?= e($row['chronicle']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Country</label>
                    <select name="country">
                        <option value="">Όλες</option>
                        <?php foreach ($countries as $row): ?>
                            <option value="<?= e($row['country']) ?>" <?= selectedIf((string) $row['country'], $filters['country'] ?? '') ?>><?= e($row['country']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Ταξινόμηση</label>
                    <select name="sort">
                        <option value="ranking" <?= selectedIf('ranking', $filters['sort'] ?? '') ?>>Καλύτερο score</option>
                        <option value="votes" <?= selectedIf('votes', $filters['sort'] ?? '') ?>>Περισσότερα votes</option>
                        <option value="views" <?= selectedIf('views', $filters['sort'] ?? '') ?>>Περισσότερα views</option>
                        <option value="latest" <?= selectedIf('latest', $filters['sort'] ?? '') ?>>Νεότερα</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Premium only</label>
                    <select name="premium">
                        <option value="">Όλα</option>
                        <option value="1" <?= selectedIf('1', $filters['premium'] ?? '') ?>>Μόνο premium</option>
                    </select>
                </div>
            </div>

            <div class="toolbar">
                <button class="btn" type="submit">Apply filters</button>
                <a class="btn-secondary" href="/servers">Clear</a>
            </div>
        </form>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="section-header">
        <div>
            <h2>Available servers</h2>
            <p>Βρέθηκαν <strong><?= count($servers) ?></strong> servers με τα τωρινά κριτήρια.</p>
        </div>
    </div>

    <div class="grid grid-3">
        <?php foreach ($servers as $server): ?>
            <div class="card server-card <?= (int) $server['is_premium'] === 1 ? 'premium' : '' ?>">
                <div class="server-top">
                    <div>
                        <?php if ((int) $server['is_premium'] === 1): ?><div class="badge badge-premium">Premium</div><?php endif; ?>
                        <h3 class="server-title"><?= e($server['title']) ?></h3>
                    </div>
                    <div class="mini-icon">⚔</div>
                </div>
                <p class="server-sub"><?= e($server['short_description']) ?></p>
                <div class="stats-grid">
                    <div class="stat-box"><span class="muted">Votes</span><strong><?= e((string) $server['raw_votes_total']) ?></strong></div>
                    <div class="stat-box"><span class="muted">Score</span><strong><?= e((string) $server['ranking_score']) ?></strong></div>
                    <div class="stat-box"><span class="muted">Views</span><strong><?= e((string) $server['views_count']) ?></strong></div>
                    <div class="stat-box"><span class="muted">Status</span><strong><?= e($server['status']) ?></strong></div>
                </div>

                <div class="action-row">
                    <a class="btn" href="/server?id=<?= (int) $server['id'] ?>">View server</a>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (!$servers): ?>
            <div class="empty-state">Δεν βρέθηκαν servers με αυτά τα filters.</div>
        <?php endif; ?>
    </div>
</section>
