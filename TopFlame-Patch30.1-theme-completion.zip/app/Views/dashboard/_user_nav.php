<?php
$currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '/dashboard', PHP_URL_PATH) ?: '/dashboard';
?>
<div class="dash-shell">
    <div class="dash-topbar">
        <div>
            <div class="badge">User Dashboard</div>
            <h1 class="title" style="font-size:42px;margin:8px 0 0">User Control Center</h1>
            <p class="subtitle" style="margin-top:8px">Navigate through focused sections with a synced fantasy / gold layout that matches the rest of TopFlame.</p>
        </div>
        <div class="dash-topbar-actions">
            <a class="btn-secondary" href="/servers">Public Listings</a>
            <?php if (empty($servers)): ?><a class="btn" href="/dashboard/servers/create">+ Add Server</a><?php endif; ?>
        </div>
    </div>

    <div class="user-page-shell">
        <aside class="user-page-sidebar">
            <div class="card user-nav-card">
                <a class="user-nav-link <?= $currentPath === '/dashboard' ? 'active' : '' ?>" href="/dashboard">Overview</a>
                <a class="user-nav-link <?= $currentPath === '/dashboard/my-servers' ? 'active' : '' ?>" href="/dashboard/my-servers">My Servers</a>
                <a class="user-nav-link <?= $currentPath === '/dashboard/banner-codes' ? 'active' : '' ?>" href="/dashboard/banner-codes">Banner Codes</a>
                <?php if (!empty($servers[0]['id'])): ?>
                    <a class="user-nav-link" href="/dashboard/servers/edit?id=<?= (int) $servers[0]['id'] ?>">Edit Server</a>
                <?php else: ?>
                    <a class="user-nav-link" href="/dashboard/servers/create">Create Server</a>
                <?php endif; ?>
            </div>

            <div class="card">
                <h3>Quick Notes</h3>
                <p class="muted">Global banners are uploaded by the admin. The code shown here is generated specifically for your server and vote gateway.</p>
            </div>
        </aside>
        <div class="user-page-content">
