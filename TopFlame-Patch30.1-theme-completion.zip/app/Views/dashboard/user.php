<section class="hero">
    <div class="hero-shell">
        <div class="section-header" style="margin-bottom:0">
            <div>
                <div class="badge">User Control Center</div>
                <h1 class="title" style="font-size:44px">Welcome back, <span class="gold"><?= e($user['username']) ?></span></h1>
                <p class="subtitle">Manage your server listing, vote gateway links, branding, and ready-to-use banner code from one clean dashboard.</p>
            </div>
            <?php if (!$servers): ?><a class="btn" href="/dashboard/servers/create">+ Add Server</a><?php endif; ?>
        </div>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="user-panel-grid">
        <aside class="user-sidebar">
            <div class="card">
                <h3>Account Overview</h3>
                <p class="muted">A quick summary of your account and server activity.</p>
                <div class="user-stat-grid" style="margin-top:16px">
                    <div class="user-stat-card"><span class="label">Servers</span><span class="value"><?= count($servers) ?></span></div>
                    <div class="user-stat-card"><span class="label">Premium</span><span class="value"><?= count(array_filter($servers, static fn($server) => (int) ($server['is_premium'] ?? 0) === 1)) ?></span></div>
                    <div class="user-stat-card"><span class="label">Votes</span><span class="value"><?= array_sum(array_map(static fn($server) => (int) ($server['raw_votes_total'] ?? 0), $servers)) ?></span></div>
                    <div class="user-stat-card"><span class="label">Views</span><span class="value"><?= array_sum(array_map(static fn($server) => (int) ($server['views_count'] ?? 0), $servers)) ?></span></div>
                </div>
            </div>

            <div class="card">
                <h3>Quick Links</h3>
                <p class="muted">Jump directly to the areas you use most.</p>
                <div class="stack" style="margin-top:14px">
                    <?php if (!$servers): ?>
                        <a class="btn" href="/dashboard/servers/create">Create your server</a>
                    <?php else: ?>
                        <a class="btn-secondary" href="/servers">Browse public listings</a>
                        <?php foreach ($servers as $server): ?>
                            <a class="btn-secondary" href="/server?id=<?= (int) $server['id'] ?>">Open <?= e($server['title']) ?></a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <h3>How banners work</h3>
                <p class="muted">Global banners are uploaded by the admin. You only copy the HTML code or gateway links generated for your own server.</p>
            </div>
        </aside>

        <div class="user-content">
            <div class="card">
                <div class="section-header">
                    <div>
                        <h2 style="margin:0">Your Servers</h2>
                        <p class="muted" style="margin:6px 0 0">Everything important for each server is grouped into one card so the dashboard matches the rest of the site better.</p>
                    </div>
                </div>

                <?php if (!$servers): ?>
                    <div class="user-server-card">
                        <h3 style="margin-top:0">No server added yet</h3>
                        <p class="muted">You have not created a server listing yet.</p>
                        <div style="margin-top:14px">
                            <a class="btn" href="/dashboard/servers/create">Create server</a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="user-server-stack">
                        <?php foreach ($servers as $server): ?>
                            <?php
                                $serverId = (int) ($server['id'] ?? 0);
                                $serverBanners = $globalBanners ?? [];
                                $gatewayUrl = voteGatewayUrl($serverId);
                            ?>
                            <div class="user-server-card">
                                <div class="user-server-top">
                                    <div>
                                        <div class="badge-tag-row" style="margin:0 0 10px 0">
                                            <?php if ((int) ($server['is_premium'] ?? 0) === 1): ?>
                                                <span class="pill pill-gold">Premium</span>
                                            <?php endif; ?>
                                            <span class="pill"><?= e(ucfirst((string) ($server['status'] ?? 'unknown'))) ?></span>
                                        </div>
                                        <h3 style="margin:0 0 8px 0"><?= e($server['title']) ?></h3>
                                        <p class="muted" style="margin:0">Server ID #<?= $serverId ?> · Last updated <?= e((string) ($server['updated_at'] ?? '—')) ?></p>
                                    </div>
                                    <div class="user-server-actions">
                                        <a class="btn-secondary" href="/dashboard/servers/edit?id=<?= $serverId ?>">Edit</a>
                                        <a class="btn-secondary" href="/server?id=<?= $serverId ?>">View page</a>
                                    </div>
                                </div>

                                <div class="user-meta-grid">
                                    <div class="user-mini-box"><span class="k">Votes</span><span class="v"><?= e((string) ($server['raw_votes_total'] ?? 0)) ?></span></div>
                                    <div class="user-mini-box"><span class="k">Score</span><span class="v"><?= e((string) ($server['ranking_score'] ?? 0)) ?></span></div>
                                    <div class="user-mini-box"><span class="k">Views</span><span class="v"><?= e((string) ($server['views_count'] ?? 0)) ?></span></div>
                                    <div class="user-mini-box"><span class="k">Premium Until</span><span class="v"><?= e((string) (($server['premium_until'] ?? '') !== '' ? $server['premium_until'] : '—')) ?></span></div>
                                </div>

                                <div class="user-code-grid">
                                    <div class="form-group">
                                        <label>Vote Gateway URL</label>
                                        <input type="text" readonly value="<?= e($gatewayUrl) ?>" onclick="this.select()">
                                    </div>
                                </div>

                                <?php if ($serverBanners): ?>
                                    <div style="margin-top:18px">
                                        <div class="section-header" style="margin-bottom:12px">
                                            <div>
                                                <h3 style="margin:0">Banner HTML</h3>
                                                <p class="muted" style="margin:6px 0 0">Global admin banners are loaded automatically and the HTML code below is generated for this specific server.</p>
                                            </div>
                                        </div>

                                        <div class="user-banner-grid">
                                            <?php foreach ($serverBanners as $banner): ?>
                                                <?php
                                                    $bannerUrl = public_asset_url((string) $banner['image_url']);
                                                    $bannerGatewayUrl = public_asset_url('/vote-gateway?id=' . $serverId . '&banner=' . (int) $banner['id']);
                                                    $htmlCode = '<a href="' . $bannerGatewayUrl . '" target="_blank" rel="noopener sponsored"><img src="' . $bannerUrl . '" alt="' . e($server['title']) . ' Vote Banner" border="0"></a>';
                                                ?>
                                                <div class="user-banner-item">
                                                    <div>
                                                        <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:10px;">
                                                            <strong><?= e($banner['title'] ?: 'Banner #' . $banner['id']) ?></strong>
                                                            <span class="pill"><?= e((string) ($banner['size_label'] ?: 'Custom')) ?></span>
                                                        </div>
                                                        <img src="<?= e($bannerUrl) ?>" alt="Banner Preview" style="max-width:100%;height:auto;border-radius:12px;border:1px solid rgba(255,255,255,.08);">
                                                    </div>
                                                    <div>
                                                        <div class="form-group">
                                                            <label>Banner Gateway URL</label>
                                                            <input type="text" readonly value="<?= e($bannerGatewayUrl) ?>" onclick="this.select()">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>HTML Code</label>
                                                            <textarea readonly rows="5" class="code-area" onclick="this.select()"><?= e($htmlCode) ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="card" style="margin-top:18px;background:rgba(255,255,255,.02)">
                                        <h3 style="margin-top:0">No global banners yet</h3>
                                        <p class="muted">The admin has not uploaded any global banners yet.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
