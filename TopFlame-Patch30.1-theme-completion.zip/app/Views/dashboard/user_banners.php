<section class="hero">
    <div class="hero-shell">
        <?php require __DIR__ . '/_user_nav.php'; ?>
            <div class="card">
                <div class="user-section-title">
                    <div>
                        <h2 style="margin:0">Banner Codes</h2>
                        <p class="muted" style="margin:6px 0 0">A dedicated page just for copied code, banner previews, and vote gateway URLs.</p>
                    </div>
                </div>

                <?php if (!$servers): ?>
                    <div class="empty-state-card">
                        <h3>No server added yet</h3>
                        <p class="muted">Create your server first to generate vote banner HTML codes.</p>
                        <a class="btn" href="/dashboard/servers/create">Create Server</a>
                    </div>
                <?php elseif (!$globalBanners): ?>
                    <div class="empty-state-card">
                        <h3>No global banners yet</h3>
                        <p class="muted">The admin has not uploaded any global banners yet.</p>
                    </div>
                <?php else: ?>
                    <div class="stack" style="gap:22px">
                        <?php foreach ($servers as $server): ?>
                            <div class="user-server-card user-server-card-polished">
                                <div class="section-header">
                                    <div>
                                        <h3 style="margin:0"><?= e($server['title']) ?></h3>
                                        <p class="muted" style="margin:6px 0 0">HTML code below is generated for this server only.</p>
                                    </div>
                                </div>
                                <div class="user-soft-divider"></div><div class="user-banner-grid">
                                    <?php foreach ($globalBanners as $banner): ?>
                                        <?php
                                            $bannerUrl = public_asset_url((string) $banner['image_url']);
                                            $bannerGatewayUrl = public_asset_url('/vote-gateway?id=' . (int) $server['id'] . '&banner=' . (int) $banner['id']);
                                            $htmlCode = '<a href="' . $bannerGatewayUrl . '" target="_blank" rel="noopener sponsored"><img src="' . $bannerUrl . '" alt="' . e($server['title']) . ' Vote Banner" border="0"></a>';
                                        ?>
                                        <div class="user-banner-item user-banner-item-polished">
                                            <div class="banner-preview-panel">
                                                <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:10px;">
                                                    <strong><?= e($banner['title'] ?: 'Banner #' . $banner['id']) ?></strong>
                                                    <span class="pill"><?= e((string) ($banner['size_label'] ?: 'Custom')) ?></span>
                                                </div>
                                                <img src="<?= e($bannerUrl) ?>" alt="Banner Preview" style="max-width:100%;height:auto;border-radius:12px;border:1px solid rgba(255,255,255,.08);">
                                            </div>
                                            <div class="banner-code-panel">
                                                <div class="form-group">
                                                    <label>Banner Gateway URL</label>
                                                    <input type="text" readonly value="<?= e($bannerGatewayUrl) ?>" onclick="this.select()">
                                                </div>
                                                <div class="form-group">
                                                    <label>HTML Code</label>
                                                    <textarea readonly rows="6" class="code-area" onclick="this.select()"><?= e($htmlCode) ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>