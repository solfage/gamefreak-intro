
<section class="hero"><div class="hero-shell"><div class="badge">Admin / Logs</div><h1 class="title" style="font-size:42px">Admin <span class="gold">logs</span></h1></div></section>
<section class="section" style="padding-top:0">
<?php require __DIR__ . '/_admin_nav.php'; ?>
<div class="admin-main">
    <div class="card">
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>ID</th><th>User</th><th>Action</th><th>Target</th><th>Payload</th><th>At</th></tr></thead>
                <tbody>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?= (int) $log['id'] ?></td>
                        <td><?= e((string) ($log['username'] ?: 'system')) ?></td>
                        <td><?= e((string) $log['action']) ?></td>
                        <td><?= e((string) $log['target_type']) ?> #<?= e((string) $log['target_id']) ?></td>
                        <td><code><?= e((string) $log['payload']) ?></code></td>
                        <td><?= e((string) $log['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div></div></section>
