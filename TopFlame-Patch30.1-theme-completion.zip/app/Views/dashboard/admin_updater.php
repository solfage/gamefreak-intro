<section class="hero"><div class="hero-shell"><div class="badge">Admin / Core Updater</div><h1 class="title" style="font-size:42px">Core <span class="gold">Updater</span></h1><p class="subtitle">Upload core update packages with backup, SQL migration support, and update logs.</p></div></section>
<section class="section" style="padding-top:0">
<?php require __DIR__ . '/_admin_nav.php'; ?>
<div class="admin-main">
    <div class="card" style="margin-bottom:20px">
        <div class="section-header">
            <div>
                <h2>Upload Core Update</h2>
                <p>Each package should include an <code>update.json</code> manifest, optional <code>files/</code> directory, and optional SQL update file.</p>
            </div>
        </div>

        <div class="card" style="padding:16px;background:rgba(255,255,255,.02);border:1px solid rgba(255,204,102,.12);margin-bottom:16px">
            <div style="font-weight:700;margin-bottom:10px">Update Progress</div>
            <div style="height:16px;border-radius:999px;background:rgba(255,255,255,.06);overflow:hidden;border:1px solid rgba(255,255,255,.08)">
                <div id="core-update-progress-bar" style="height:100%;width:0%;background:linear-gradient(90deg, rgba(255,204,102,.65), rgba(92,225,255,.65));transition:width .25s ease"></div>
            </div>
            <div id="core-update-progress-text" class="muted" style="margin-top:10px">Waiting for package upload...</div>
        </div>

        <form method="post" action="/admin/updater/upload" enctype="multipart/form-data" id="core-updater-form">
            <?= csrfField() ?>
            <div class="grid grid-2">
                <div class="form-group">
                    <label>Core Update ZIP</label>
                    <input type="file" name="core_update_zip" accept=".zip,application/zip" required>
                </div>
                <div class="form-group">
                    <label>Package Requirements</label>
                    <div class="form-note">
                        <strong>Manifest:</strong> <code>update.json</code><br>
                        <strong>Optional files:</strong> <code>files/</code><br>
                        <strong>Optional SQL:</strong> declared via <code>sql_file</code> in the manifest
                    </div>
                </div>
            </div>
            <div style="margin-top:16px">
                <button class="btn" type="submit">Upload & Apply Update</button>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="section-header">
            <div>
                <h2>Recent Update Logs</h2>
                <p>The updater creates a backup ZIP before applying files and SQL changes.</p>
            </div>
        </div>

        <div class="plugin-desktop-table table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Package</th>
                        <th>Version</th>
                        <th>Status</th>
                        <th>Backup</th>
                        <th>Details</th>
                        <th>Created</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach (($updates ?? []) as $update): ?>
                    <tr>
                        <td><?= (int) ($update['id'] ?? 0) ?></td>
                        <td><?= e((string) ($update['package_name'] ?? '')) ?></td>
                        <td><?= e((string) ($update['package_version'] ?? '')) ?></td>
                        <td>
                            <?php $status = (string) ($update['status'] ?? 'started'); ?>
                            <?php if ($status === 'completed'): ?>
                                <span class="status-badge status-approved">Completed</span>
                            <?php elseif ($status === 'failed'): ?>
                                <span class="status-badge status-disabled">Failed</span>
                            <?php else: ?>
                                <span class="pill">Started</span>
                            <?php endif; ?>
                        </td>
                        <td><code><?= e((string) (($update['backup_path'] ?? '') !== '' ? $update['backup_path'] : '—')) ?></code></td>
                        <td><?= e((string) ($update['details'] ?? '')) ?></td>
                        <td><?= e((string) ($update['created_at'] ?? '')) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($updates)): ?>
                    <tr><td colspan="7">No core updates applied yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div></div></section>

<script>
(function(){
  const form = document.getElementById('core-updater-form');
  const bar = document.getElementById('core-update-progress-bar');
  const text = document.getElementById('core-update-progress-text');
  if(!form || !bar || !text) return;

  form.addEventListener('submit', function(){
    let width = 8;
    bar.style.width = width + '%';
    text.textContent = 'Uploading package...';

    const steps = [
      [18, 'Validating package...'],
      [34, 'Creating backup...'],
      [52, 'Extracting files...'],
      [72, 'Applying file updates...'],
      [88, 'Running SQL migrations...'],
      [96, 'Finalizing update...']
    ];

    let i = 0;
    const timer = setInterval(function(){
      if(i >= steps.length){
        clearInterval(timer);
        return;
      }
      bar.style.width = steps[i][0] + '%';
      text.textContent = steps[i][1];
      i++;
    }, 700);
  });
})();
</script>
