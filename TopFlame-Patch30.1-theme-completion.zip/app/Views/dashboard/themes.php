
<section class="hero"><div class="hero-shell"><div class="badge">Admin / Themes</div><h1 class="title" style="font-size:42px">Advanced <span class="gold">Theme Engine</span></h1><p class="subtitle">Integrated theme manager with default fallback, CSS themes, and optional template overrides for full-site structure changes.</p></div></section>
<section class="section" style="padding-top:0">
<?php require BASE_PATH . '/app/Views/dashboard/_admin_nav.php'; ?>
<div class="admin-main">
    <div class="card" style="margin-bottom:20px">
        <div class="section-header">
            <div>
                <h2>Upload Theme ZIP</h2>
                <p>Upload a theme package with <code>theme.json</code>, <code>theme.css</code>, and optional <code>views/</code> folder for structural overrides.</p>
            </div>
        </div>
        <form method="post" action="/admin/themes/upload" enctype="multipart/form-data">
            <?= csrfField() ?>
            <div class="grid grid-2">
                <div class="form-group">
                    <label>Theme ZIP Package</label>
                    <input type="file" name="theme_zip" accept=".zip,application/zip" required>
                </div>
                <div class="form-group">
                    <label>Advanced Override Support</label>
                    <div class="form-note">
                        <strong>Required:</strong> <code>theme.json</code><br>
                        <strong>Required:</strong> <code>theme.css</code><br>
                        <strong>Optional:</strong> full <code>views/</code> folder with page overrides<br>
                        <strong>Fallback:</strong> if a view override is missing, core default view loads automatically
                    </div>
                </div>
            </div>
            <div style="margin-top:16px"><button class="btn" type="submit">Upload Theme</button></div>
        </form>
    </div>

    <div class="card">
        <div class="section-header">
            <div>
                <h2>Installed Themes</h2>
                <p>Active theme can change both the site appearance and selected page structure, while keeping safe fallback to default templates.</p>
            </div>
        </div>

        <?php if (empty($themes)): ?>
            <div class="user-empty-note">No themes found. Upload a theme package first.</div>
        <?php else: ?>
            <div class="grid grid-2">
                <?php foreach ($themes as $theme): ?>
                    <div class="card" style="padding:18px;border:1px solid rgba(255,204,102,.14);background:linear-gradient(180deg, rgba(16,23,38,.92), rgba(8,12,22,.92));">
                        <div class="section-header">
                            <div>
                                <div class="badge-tag-row" style="margin:0 0 8px 0">
                                    <?php if ((int) ($theme['is_active'] ?? 0) === 1): ?><span class="status-badge status-approved">Active</span><?php else: ?><span class="pill">Inactive</span><?php endif; ?>
                                    <span class="pill"><?= e((string) ($theme['version'] ?? '1.0.0')) ?></span>
                                </div>
                                <h3 style="margin:0 0 8px 0"><?= e((string) ($theme['name'] ?? 'Theme')) ?></h3>
                                <p class="muted" style="margin:0"><?= e((string) ($theme['description'] ?? '')) ?></p>
                                <div class="muted" style="margin-top:8px">Key: <code><?= e((string) ($theme['theme_key'] ?? '')) ?></code></div>
                            </div>
                        </div>

                        <?php if ((int) ($theme['is_active'] ?? 0) !== 1): ?>
                            <form method="post" action="/admin/themes/activate">
                                <?= csrfField() ?>
                                <input type="hidden" name="theme_key" value="<?= e((string) ($theme['theme_key'] ?? '')) ?>">
                                <button class="btn" type="submit">Activate Theme</button>
                            </form>
                        <?php else: ?>
                            <div class="muted">This theme is currently active.</div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div></section>
