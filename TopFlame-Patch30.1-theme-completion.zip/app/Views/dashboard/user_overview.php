<section class="hero">
    <div class="hero-shell">
        <?php require __DIR__ . '/_user_nav.php'; ?>
            <div class="card">
                <div class="user-section-title">
                    <div>
                        <h2 style="margin:0">Overview</h2>
                        <p class="muted" style="margin:6px 0 0">A polished overview page with a fantasy-gold style for your account activity, server progress, and quick actions.</p>
                    </div>
                </div>
                <div class="user-soft-divider"></div>
                <div class="user-stat-grid user-stat-grid-wide">
                    <div class="user-stat-card user-highlight-card"><span class="label">Servers</span><span class="value"><?= (int) ($stats['servers'] ?? 0) ?></span></div>
                    <div class="user-stat-card"><span class="label">Premium Servers</span><span class="value"><?= (int) ($stats['premium'] ?? 0) ?></span></div>
                    <div class="user-stat-card"><span class="label">Total Votes</span><span class="value"><?= (int) ($stats['votes'] ?? 0) ?></span></div>
                    <div class="user-stat-card"><span class="label">Total Views</span><span class="value"><?= (int) ($stats['views'] ?? 0) ?></span></div>
                </div>

                <?php if ($recentServer): ?>
                    <div class="user-feature-card">
                        <div>
                            <div class="badge-tag-row" style="margin:0 0 10px 0">
                                <?php if ((int) ($recentServer['is_premium'] ?? 0) === 1): ?><span class="pill pill-gold">Premium</span><?php endif; ?>
                                <span class="pill"><?= e(ucfirst((string) ($recentServer['status'] ?? 'unknown'))) ?></span>
                            </div>
                            <h3 style="margin:0 0 8px 0"><?= e($recentServer['title']) ?></h3>
                            <p class="muted" style="margin:0">Latest server activity at a glance, with quick access to editing, viewing, and banner tools.</p>
                        </div>
                        <div class="user-server-actions">
                            <a class="btn-secondary" href="/server?id=<?= (int) $recentServer['id'] ?>">Open Page</a>
                            <a class="btn-secondary" href="/dashboard/servers/edit?id=<?= (int) $recentServer['id'] ?>">Edit</a>
                            <a class="btn" href="/dashboard/banner-codes">Banner Codes</a>
                        </div>
                    </div>

                    <div class="user-soft-divider"></div><div class="user-meta-grid">
                        <div class="user-mini-box"><span class="k">Votes</span><span class="v"><?= e((string) ($recentServer['raw_votes_total'] ?? 0)) ?></span></div>
                        <div class="user-mini-box"><span class="k">Score</span><span class="v"><?= e((string) ($recentServer['ranking_score'] ?? 0)) ?></span></div>
                        <div class="user-mini-box"><span class="k">Views</span><span class="v"><?= e((string) ($recentServer['views_count'] ?? 0)) ?></span></div>
                        <div class="user-mini-box"><span class="k">Vote Gateway</span><span class="v" style="font-size:13px;word-break:break-all"><?= e(voteGatewayUrl((int) $recentServer['id'])) ?></span></div>
                    </div>
                <?php else: ?>
                    <div class="empty-state-card">
                        <h3>No server added yet</h3>
                        <p class="muted">Create your first server listing to unlock the rest of the dashboard pages.</p>
                        <a class="btn" href="/dashboard/servers/create">Create Server</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>