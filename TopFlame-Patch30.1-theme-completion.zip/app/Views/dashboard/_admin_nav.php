
<?php $currentAdminPath = strtok((string) ($_SERVER['REQUEST_URI'] ?? '/admin'), '?'); ?>
<div class="admin-shell">
    <div class="admin-side card">
        <div class="badge">Admin Navigation</div>
        <div class="admin-nav">
            <?php foreach (adminMenuItems() as $path => $label): ?>
                <a href="<?= e($path) ?>" class="admin-nav-link <?= $currentAdminPath === $path ? 'active' : '' ?>"><?= e($label) ?></a>
            <?php endforeach; ?>
        </div>
    </div>
