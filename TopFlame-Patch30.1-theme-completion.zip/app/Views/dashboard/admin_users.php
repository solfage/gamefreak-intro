
<section class="hero"><div class="hero-shell"><div class="badge">Admin / Users</div><h1 class="title" style="font-size:42px">User <span class="gold">overview</span></h1></div></section>
<section class="section" style="padding-top:0">
<?php require __DIR__ . '/_admin_nav.php'; ?>
<div class="admin-main">
    <div class="card">
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Servers</th><th>Created</th></tr></thead>
                <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= (int) $user['id'] ?></td>
                        <td><?= e($user['username']) ?></td>
                        <td><?= e($user['email']) ?></td>
                        <td><?= e($user['role']) ?></td>
                        <td><?= e((string) $user['server_count']) ?></td>
                        <td><?= e((string) $user['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div></div></section>
