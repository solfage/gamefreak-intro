
<section class="hero">
    <div class="hero-shell">
        <div class="badge">Banner Manager</div>
        <h1 class="title" style="font-size:42px"><?= e($server['title']) ?> <span class="gold">banners</span></h1>
        <p class="subtitle">List-manageable vote banners με preview, sorting, active/inactive και έτοιμο HTML code προς το TopFlame gateway.</p>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="grid grid-2">
        <div class="card">
            <div class="section-header"><div><h2>New banner</h2><p>Βάζεις image URL, size και σειρά εμφάνισης.</p></div><a class="btn-secondary" href="/dashboard">Back</a></div>
            <form method="post" action="/dashboard/banners/create">
                <?= csrfField() ?>
                <input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>">
                <div class="form-group"><label>Title</label><input type="text" name="title" required maxlength="140" placeholder="TopFlame Vote Banner"></div>
                <div class="form-group"><label>Image URL</label><input type="url" name="image_url" required placeholder="https://..."></div>
                <div class="grid grid-2">
                    <div class="form-group"><label>Size label</label><input type="text" name="size_label" maxlength="40" placeholder="468x60"></div>
                    <div class="form-group"><label>Sort order</label><input type="number" name="sort_order" min="0" value="0"></div>
                </div>
                <label><input type="checkbox" name="is_active" checked> Active</label>
                <div style="margin-top:16px"><button class="btn" type="submit">Add banner</button></div>
            </form>
        </div>

        <div class="card">
            <div class="section-header"><div><h2>Gateway & default embed</h2><p>Το shared link για external banner placements.</p></div></div>
            <div class="code-box">
                <label>Server Vote Gateway URL</label>
                <input type="text" readonly value="<?= e(voteGatewayUrl((int) $server['id'])) ?>" onclick="this.select()">
            </div>
            <div class="code-box" style="margin-top:16px">
                <label>Return URL</label>
                <input type="text" readonly value="<?= e(appUrl(serverViewUrl((int) $server['id']))) ?>" onclick="this.select()">
            </div>
            <div style="margin-top:16px"><label>Default HTML code</label><textarea readonly rows="6" class="code-area" onclick="this.select()"><?= e(voteBannerEmbedCode((int) $server['id'], $server['title'])) ?></textarea></div>
        </div>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="stack">
        <?php foreach ($banners as $banner): ?>
            <div class="card">
                <div class="section-header">
                    <div>
                        <h3><?= e($banner['title']) ?></h3>
                        <p>ID #<?= (int) $banner['id'] ?> · <?= e((string) ($banner['size_label'] ?: 'Custom size')) ?> · <?= (int) $banner['is_active'] === 1 ? 'Active' : 'Hidden' ?></p>
                    </div>
                    <a class="btn-secondary" href="<?= e(appUrl('/vote-gateway?id=' . (int) $server['id'] . '&banner=' . (int) $banner['id'])) ?>" target="_blank" rel="noopener noreferrer">Open gateway</a>
                </div>
                <div class="grid grid-2">
                    <div class="code-box" style="text-align:center">
                        <img src="<?= e($banner['image_url']) ?>" alt="<?= e($banner['title']) ?>" style="max-width:100%;height:auto;border-radius:12px">
                    </div>
                    <div>
                        <form method="post" action="/dashboard/banners/update">
                            <?= csrfField() ?>
                            <input type="hidden" name="banner_id" value="<?= (int) $banner['id'] ?>">
                            <div class="form-group"><label>Title</label><input type="text" name="title" maxlength="140" value="<?= e($banner['title']) ?>"></div>
                            <div class="form-group"><label>Image URL</label><input type="url" name="image_url" value="<?= e($banner['image_url']) ?>"></div>
                            <div class="grid grid-2">
                                <div class="form-group"><label>Size label</label><input type="text" name="size_label" maxlength="40" value="<?= e((string) $banner['size_label']) ?>"></div>
                                <div class="form-group"><label>Sort order</label><input type="number" name="sort_order" min="0" value="<?= (int) $banner['sort_order'] ?>"></div>
                            </div>
                            <label><input type="checkbox" name="is_active" <?= (int) $banner['is_active'] === 1 ? 'checked' : '' ?>> Active</label>
                            <div style="margin-top:16px"><button class="btn" type="submit">Save</button></div>
                        </form>
                        <form method="post" action="/dashboard/banners/delete" onsubmit="return confirm('Delete this banner?');" style="margin-top:10px">
                            <?= csrfField() ?>
                            <input type="hidden" name="banner_id" value="<?= (int) $banner['id'] ?>">
                            <button class="btn-danger" type="submit">Delete</button>
                        </form>
                    </div>
                </div>
                <div style="margin-top:16px">
                    <label>HTML code</label>
                    <textarea readonly rows="6" class="code-area" onclick="this.select()"><?= e(bannerGatewayHtml($banner, $server)) ?></textarea>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (!$banners): ?>
            <div class="card"><p>Δεν υπάρχουν banners ακόμα για αυτόν τον server.</p></div>
        <?php endif; ?>
    </div>
</section>
