
<section class="hero">
    <div class="hero-shell">
        <div class="badge">Admin</div>
        <h1 class="title" style="font-size:44px">TopFlame <span class="gold">dashboard</span></h1>
        <p class="subtitle">Γρήγορη εικόνα για approvals, premium, users, banners και activity χωρίς όλα να είναι πεταμένα σε μία σελίδα.</p>
    </div>
</section>

<section class="section" style="padding-top:0">
<?php require __DIR__ . '/_admin_nav.php'; ?>
    <div class="admin-main">
        <div class="grid grid-4">
            <div class="stat-card"><div class="rank"><?= e((string) $stats['users']) ?></div><div class="muted">Users</div></div>
            <div class="stat-card"><div class="rank"><?= e((string) $stats['servers']) ?></div><div class="muted">Servers</div></div>
            <div class="stat-card"><div class="rank"><?= e((string) $stats['pending']) ?></div><div class="muted">Pending</div></div>
            <div class="stat-card"><div class="rank"><?= e((string) $stats['premium']) ?></div><div class="muted">Premium</div></div>
        </div>

        <div class="grid grid-2" style="margin-top:18px">
            <div class="card">
                <div class="section-header"><div><h2>Pending approvals</h2><p>Πρόσφατα submissions που θέλουν moderation.</p></div><a class="btn-secondary" href="/admin/servers">Open servers</a></div>
                <div class="table-wrap">
                    <table class="table">
                        <thead><tr><th>ID</th><th>Title</th><th>Chronicle</th><th>Actions</th></tr></thead>
                        <tbody>
                        <?php foreach ($pendingServers as $server): ?>
                            <tr>
                                <td><?= (int) $server['id'] ?></td>
                                <td><?= e($server['title']) ?></td>
                                <td><?= e($server['chronicle']) ?></td>
                                <td>
                                    <div class="action-row">
                                        <form method="post" action="/admin/servers/approve"><?= csrfField() ?><input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>"><button class="btn" type="submit">Approve</button></form>
                                        <form method="post" action="/admin/servers/reject"><?= csrfField() ?><input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>"><button class="btn-danger" type="submit">Reject</button></form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (!$pendingServers): ?><tr><td colspan="4">Δεν υπάρχουν pending servers.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card">
                <div class="section-header"><div><h2>Recent activity</h2><p>Πιο πρόσφατες admin κινήσεις.</p></div><a class="btn-secondary" href="/admin/logs">Open logs</a></div>
                <div class="table-wrap">
                    <table class="table">
                        <thead><tr><th>Action</th><th>Target</th><th>At</th></tr></thead>
                        <tbody>
                        <?php foreach ($recentLogs as $log): ?>
                            <tr>
                                <td><?= e((string) $log['action']) ?></td>
                                <td><?= e((string) $log['target_type']) ?> #<?= e((string) $log['target_id']) ?></td>
                                <td><?= e((string) $log['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (!$recentLogs): ?><tr><td colspan="3">Δεν υπάρχουν logs.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card" style="margin-top:18px">
            <div class="section-header"><div><h2>Recent servers</h2><p>Γρήγορο overview των τελευταίων servers.</p></div><a class="btn-secondary" href="/admin/servers">Manage all</a></div>
            <div class="table-wrap">
                <table class="table">
                    <thead><tr><th>ID</th><th>Title</th><th>Status</th><th>Premium</th><th>Votes</th><th>Views</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentServers as $server): ?>
                        <tr>
                            <td><?= (int) $server['id'] ?></td>
                            <td><?= e($server['title']) ?></td>
                            <td><span class="status-badge status-<?= e(strtolower((string) $server['status'])) ?>"><?= e((string) $server['status']) ?></span></td>
                            <td><?= (int) $server['is_premium'] === 1 ? 'Yes' : 'No' ?></td>
                            <td><?= e((string) $server['raw_votes_total']) ?></td>
                            <td><?= e((string) $server['views_count']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</section>
