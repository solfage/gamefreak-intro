
<section class="hero"><div class="hero-shell"><div class="badge">Admin / Premium</div><h1 class="title" style="font-size:42px">Premium <span class="gold">management</span></h1></div></section>
<section class="section" style="padding-top:0">
<?php require __DIR__ . '/_admin_nav.php'; ?>
<div class="admin-main">
    <div class="card">
        <div class="section-header"><div><h2>Premium controls</h2><p>Boosts, διάρκεια και branding eligibility.</p></div></div>
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>ID</th><th>Server</th><th>Current</th><th>Branding</th><th>Update premium</th></tr></thead>
                <tbody>
                <?php foreach ($servers as $server): ?>
                    <tr>
                        <td><?= (int) $server['id'] ?></td>
                        <td><strong><?= e($server['title']) ?></strong><div class="muted"><?= e((string) $server['status']) ?></div></td>
                        <td>
                            <?php if ((int) $server['is_premium'] === 1): ?>
                                <span class="badge badge-premium">Premium</span>
                                <div class="muted"><?= e((string) $server['premium_boost_type']) ?> / <?= e((string) $server['premium_boost_value']) ?> μέχρι <?= e((string) $server['premium_until']) ?></div>
                            <?php else: ?>
                                <span class="muted">No premium</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="muted">Logo: <?= !empty($server['logo_path']) ? 'Yes' : 'No' ?></div>
                            <div class="muted">Header Banner: <?= !empty($server['banner_path']) ? 'Yes' : 'No' ?></div>
                        </td>
                        <td>
                            <form method="post" action="/admin/servers/premium" class="inline-form">
                                <?= csrfField() ?>
                                <input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>">
                                <select name="premium_mode">
                                    <option value="package">Package</option>
                                    <option value="manual">Manual</option>
                                    <option value="none">Remove premium</option>
                                </select>
                                <select name="package_id">
                                    <option value="0">Package</option>
                                    <?php foreach ($premiumPackages as $package): ?>
                                        <option value="<?= (int) $package['id'] ?>"><?= e($package['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="number" name="premium_days" min="1" value="30" placeholder="Days">
                                <select name="boost_type"><option value="percent">Percent</option><option value="fixed">Fixed</option></select>
                                <input type="number" step="0.01" name="boost_value" value="10">
                                <button class="btn" type="submit">Save</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div></div></section>
