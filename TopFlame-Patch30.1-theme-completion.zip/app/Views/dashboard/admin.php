<section class="hero">
    <div class="hero-shell">
        <div class="badge badge-premium">Admin Control</div>
        <h1 class="title" style="font-size:44px">TopFlame <span class="gold">admin panel</span></h1>
        <p class="subtitle">Overview, approvals, premium controls και moderation με πιο καθαρό dashboard styling.</p>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="grid grid-4">
        <div class="stat-card"><div class="rank"><?= e((string) $stats['users']) ?></div><div class="muted">Users</div></div>
        <div class="stat-card"><div class="rank"><?= e((string) $stats['servers']) ?></div><div class="muted">Servers</div></div>
        <div class="stat-card"><div class="rank"><?= e((string) $stats['pending']) ?></div><div class="muted">Pending approvals</div></div>
        <div class="stat-card"><div class="rank"><?= e((string) $stats['votes']) ?></div><div class="muted">Votes</div></div>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="section-header">
        <div>
            <h2>Pending servers</h2>
            <p>Servers που περιμένουν approval.</p>
        </div>
    </div>

    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>ID</th><th>Title</th><th>Chronicle</th><th>Submitted</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($pendingServers as $server): ?>
                <tr>
                    <td><?= (int) $server['id'] ?></td>
                    <td><strong><?= e($server['title']) ?></strong></td>
                    <td><?= e($server['chronicle']) ?></td>
                    <td><?= e((string) $server['created_at']) ?></td>
                    <td>
                        <div class="action-row">
                            <a class="btn-secondary" href="/dashboard/servers/edit?id=<?= (int) $server['id'] ?>">Review</a>
                            <form method="post" action="/admin/servers/approve" style="margin:0"><?= csrfField() ?><input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>"><button class="btn" type="submit">Approve</button></form>
                            <form method="post" action="/admin/servers/reject" style="margin:0"><?= csrfField() ?><input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>"><button class="btn-danger" type="submit">Reject</button></form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$pendingServers): ?>
                <tr><td colspan="5">Δεν υπάρχουν pending submissions.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="section-header">
        <div>
            <h2>Recent servers / premium management</h2>
            <p>Basic moderation και premium controls.</p>
        </div>
    </div>

    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>ID</th><th>Title</th><th>Status</th><th>Premium</th><th>Votes</th><th>Score</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($recentServers as $server): ?>
                <tr>
                    <td><?= (int) $server['id'] ?></td>
                    <td><strong><?= e($server['title']) ?></strong></td>
                    <td><span class="status-badge status-<?= e(strtolower((string) $server['status'])) ?>"><?= e($server['status']) ?></span></td>
                    <td>
                        <?php if ((int) $server['is_premium'] === 1): ?>
                            <span class="badge badge-premium">Premium</span><br>
                            <span class="muted"><?= e((string) $server['premium_boost_type']) ?> / <?= e((string) $server['premium_boost_value']) ?><br>έως <?= e((string) $server['premium_until']) ?></span>
                        <?php else: ?>
                            <span class="muted">No</span>
                        <?php endif; ?>
                    </td>
                    <td><?= e((string) $server['raw_votes_total']) ?></td>
                    <td><?= e((string) $server['ranking_score']) ?></td>
                    <td>
                        <div class="action-row">
                            <a class="btn-secondary" href="/dashboard/servers/edit?id=<?= (int) $server['id'] ?>">Edit</a>
                            <?php if ($server['status'] !== 'disabled'): ?>
                                <form method="post" action="/admin/servers/disable" style="margin:0"><?= csrfField() ?><input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>"><button class="btn-danger" type="submit">Disable</button></form>
                            <?php endif; ?>
                        </div>

                        <form method="post" action="/admin/servers/premium" style="margin-top:12px;min-width:260px">
                            <?= csrfField() ?>
                            <input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>">
                            <div class="grid grid-2">
                                <div class="form-group">
                                    <label>Mode</label>
                                    <select name="premium_mode">
                                        <option value="none">Χωρίς premium</option>
                                        <option value="package">Package</option>
                                        <option value="manual">Manual</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Package</label>
                                    <select name="package_id">
                                        <option value="0">—</option>
                                        <?php foreach ($premiumPackages as $package): ?>
                                            <option value="<?= (int) $package['id'] ?>"><?= e($package['name']) ?> (<?= e((string) $package['duration_days']) ?>d / <?= e((string) $package['boost_value']) ?> <?= e((string) $package['boost_type']) ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Days</label>
                                    <input type="number" min="1" name="premium_days" value="30">
                                </div>
                                <div class="form-group">
                                    <label>Boost Type</label>
                                    <select name="boost_type">
                                        <option value="percent">percent</option>
                                        <option value="fixed">fixed</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Boost Value</label>
                                    <input type="number" step="0.01" min="0" name="boost_value" value="10">
                                </div>
                            </div>
                            <button class="btn" type="submit">Save premium</button>
                        </form>
                        <form method="post" action="/admin/servers/delete" style="margin-top:12px" onsubmit="return confirm('Delete this server permanently?');">
                            <?= csrfField() ?>
                            <input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>">
                            <button class="btn-danger" type="submit">Delete Server</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="section-header">
        <div>
            <h2>Recent admin logs</h2>
            <p>Latest moderation and admin actions.</p>
        </div>
    </div>

    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>Action</th><th>Target</th><th>Target ID</th><th>When</th></tr></thead>
            <tbody>
            <?php foreach ($recentLogs as $log): ?>
                <tr>
                    <td><?= e($log['action']) ?></td>
                    <td><?= e((string) $log['target_type']) ?></td>
                    <td><?= e((string) $log['target_id']) ?></td>
                    <td><?= e((string) $log['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$recentLogs): ?>
                <tr><td colspan="4">Δεν υπάρχουν logs ακόμη.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
