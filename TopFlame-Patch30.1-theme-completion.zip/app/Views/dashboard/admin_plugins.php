<section class="hero"><div class="hero-shell"><div class="badge">Admin / Plugins</div><h1 class="title" style="font-size:42px">Plugin <span class="gold">Manager</span></h1><p class="subtitle">Upload, install, update, enable, disable, and uninstall plugins. Core modules and external plugins are managed from the same registry.</p></div></section>
<section class="section" style="padding-top:0">
<?php require __DIR__ . '/_admin_nav.php'; ?>
<div class="admin-main">
    <div class="grid grid-4" style="margin-bottom:20px">
        <div class="card"><div class="muted">Total Modules</div><div style="font-size:32px;font-weight:800"><?= (int) ($moduleStats['total'] ?? 0) ?></div></div>
        <div class="card"><div class="muted">Enabled</div><div style="font-size:32px;font-weight:800"><?= (int) ($moduleStats['enabled'] ?? 0) ?></div></div>
        <div class="card"><div class="muted">Core Modules</div><div style="font-size:32px;font-weight:800"><?= (int) ($moduleStats['core'] ?? 0) ?></div></div>
        <div class="card"><div class="muted">Migration Runs</div><div style="font-size:32px;font-weight:800"><?= (int) ($migrationCount ?? 0) ?></div></div>
    </div>

    <div class="card" style="margin-bottom:20px">
        <div class="section-header">
            <div>
                <h2>Upload Plugin ZIP</h2>
                <p>Upload a plugin package that includes a <code>plugin.json</code> manifest. If the manifest declares SQL files, the installer will run them and track the migration history.</p>
            </div>
        </div>

        <form method="post" action="/admin/plugins/upload" enctype="multipart/form-data">
            <?= csrfField() ?>
            <div class="grid grid-2">
                <div class="form-group">
                    <label>Plugin ZIP Package</label>
                    <input type="file" name="plugin_zip" accept=".zip,application/zip" required>
                </div>
                <div class="form-group">
                    <label>Package Notes</label>
                    <div class="form-note">Supported manifest keys: key, name, version, description, author, entry, requires_sql, install_sql, update_sql, uninstall_sql.</div>
                </div>
            </div>
            <div style="margin-top:16px">
                <button class="btn" type="submit">Upload & Install</button>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="section-header">
            <div>
                <h2>Module Registry</h2>
                <p>Core modules are part of the platform. External plugins are discovered from the <code>plugins/</code> folder and synced into the registry automatically.</p>
            </div>
        </div>

        <div class="plugin-desktop-table table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Key</th>
                        <th>Type</th>
                        <th>Source</th>
                        <th>Version</th>
                        <th>Status</th>
                        <th>Path</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach (($modules ?? []) as $module): ?>
                    <tr>
                        <td>
                            <strong><?= e((string) ($module['name'] ?? 'Module')) ?></strong>
                            <div class="muted" style="margin-top:6px"><?= e((string) ($module['description'] ?? '')) ?></div>
                        </td>
                        <td><code><?= e((string) ($module['module_key'] ?? '')) ?></code></td>
                        <td><span class="pill"><?= e(ucfirst((string) ($module['type'] ?? 'core'))) ?></span></td>
                        <td><span class="pill"><?= e(ucfirst((string) ($module['source'] ?? 'internal'))) ?></span></td>
                        <td><?= e((string) ($module['version'] ?? '1.0.0')) ?></td>
                        <td>
                            <?php if ((int) ($module['is_enabled'] ?? 0) === 1): ?>
                                <span class="status-badge status-approved">Enabled</span>
                            <?php else: ?>
                                <span class="status-badge status-disabled">Disabled</span>
                            <?php endif; ?>
                            <?php if ((int) ($module['is_locked'] ?? 0) === 1): ?>
                                <div class="muted" style="margin-top:6px">Locked</div>
                            <?php endif; ?>
                        </td>
                        <td><?= e((string) (($module['path'] ?? '') !== '' ? $module['path'] : '—')) ?></td>
                        <td>
                            <div style="display:grid;gap:10px">
                                <?php if ((int) ($module['is_locked'] ?? 0) === 1): ?>
                                    <span class="muted">Locked</span>
                                <?php else: ?>
                                    <form method="post" action="/admin/plugins/toggle">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="module_key" value="<?= e((string) ($module['module_key'] ?? '')) ?>">
                                        <button class="btn-secondary" type="submit"><?= (int) ($module['is_enabled'] ?? 0) === 1 ? 'Disable' : 'Enable' ?></button>
                                    </form>
                                <?php endif; ?>

                                <?php if ((string) ($module['type'] ?? '') === 'plugin'): ?>
                                    <form method="post" action="/admin/plugins/uninstall" onsubmit="return confirm('Uninstall this plugin?')">
                                        <?= csrfField() ?>
                                        <input type="hidden" name="module_key" value="<?= e((string) ($module['module_key'] ?? '')) ?>">
                                        <label style="display:flex;gap:10px;align-items:center;margin-bottom:8px"><input type="checkbox" name="delete_files" value="1"> Delete plugin files</label>
                                        <button class="btn-secondary" type="submit">Uninstall</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($modules)): ?>
                    <tr><td colspan="8">No modules found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="plugin-mobile-list">
            <?php foreach (($modules ?? []) as $module): ?>
                <div class="plugin-mobile-card">
                    <div class="plugin-mobile-top">
                        <div>
                            <strong style="display:block;font-size:18px"><?= e((string) ($module['name'] ?? 'Module')) ?></strong>
                            <div class="muted" style="margin-top:6px"><?= e((string) ($module['description'] ?? '')) ?></div>
                        </div>
                        <div>
                            <?php if ((int) ($module['is_enabled'] ?? 0) === 1): ?>
                                <span class="status-badge status-approved">Enabled</span>
                            <?php else: ?>
                                <span class="status-badge status-disabled">Disabled</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="plugin-mobile-meta">
                        <div class="mini"><span class="k">Key</span><span class="v"><?= e((string) ($module['module_key'] ?? '')) ?></span></div>
                        <div class="mini"><span class="k">Version</span><span class="v"><?= e((string) ($module['version'] ?? '1.0.0')) ?></span></div>
                        <div class="mini"><span class="k">Type</span><span class="v"><?= e(ucfirst((string) ($module['type'] ?? 'core'))) ?></span></div>
                        <div class="mini"><span class="k">Source</span><span class="v"><?= e(ucfirst((string) ($module['source'] ?? 'internal'))) ?></span></div>
                        <div class="mini"><span class="k">Path</span><span class="v"><?= e((string) (($module['path'] ?? '') !== '' ? $module['path'] : '—')) ?></span></div>
                        <div class="mini"><span class="k">State</span><span class="v"><?= (int) ($module['is_locked'] ?? 0) === 1 ? 'Locked' : 'Editable' ?></span></div>
                    </div>

                    <div class="plugin-mobile-actions">
                        <?php if ((int) ($module['is_locked'] ?? 0) === 1): ?>
                            <span class="muted">This module is locked.</span>
                        <?php else: ?>
                            <form method="post" action="/admin/plugins/toggle">
                                <?= csrfField() ?>
                                <input type="hidden" name="module_key" value="<?= e((string) ($module['module_key'] ?? '')) ?>">
                                <button class="btn-secondary" type="submit" style="width:100%"><?= (int) ($module['is_enabled'] ?? 0) === 1 ? 'Disable' : 'Enable' ?></button>
                            </form>
                        <?php endif; ?>

                        <?php if ((string) ($module['type'] ?? '') === 'plugin'): ?>
                            <form method="post" action="/admin/plugins/uninstall" onsubmit="return confirm('Uninstall this plugin?')">
                                <?= csrfField() ?>
                                <input type="hidden" name="module_key" value="<?= e((string) ($module['module_key'] ?? '')) ?>">
                                <label style="display:flex;gap:10px;align-items:center;margin-bottom:8px"><input type="checkbox" name="delete_files" value="1"> Delete plugin files</label>
                                <button class="btn-secondary" type="submit" style="width:100%">Uninstall</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if (empty($modules)): ?>
                <div class="plugin-mobile-card">No modules found.</div>
            <?php endif; ?>
        </div>
    </div>

    <div class="card" style="margin-top:20px">
        <h3 style="margin-top:0">Plugin package structure</h3>
        <div class="grid grid-3">
            <div>
                <strong>Manifest</strong>
                <p class="muted">Every plugin ZIP should include a root <code>plugin.json</code> file with key, name, version, and optional SQL metadata.</p>
            </div>
            <div>
                <strong>SQL Support</strong>
                <p class="muted">If <code>requires_sql</code> is enabled, the installer can run <code>install.sql</code>, <code>update.sql</code>, and <code>uninstall.sql</code> while tracking migration history.</p>
            </div>
            <div>
                <strong>Registry Sync</strong>
                <p class="muted">Installed plugins are synced into the same registry as core modules so future systems can be built as true plug-in features.</p>
            </div>
        </div>
    </div>
</div></div></section>
