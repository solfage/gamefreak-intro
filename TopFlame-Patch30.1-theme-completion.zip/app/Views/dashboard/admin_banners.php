
<section class="section" style="padding-top:0">
    <div class="card">
        <div class="section-header">
            <div>
                <h2>Upload Banner</h2>
                <p>Upload a global banner once and TopFlame will automatically load it for every server owner with server-specific vote gateway HTML code.</p>
            </div>
        </div>
        <form method="post" action="/admin/banners/upload" enctype="multipart/form-data">
            <?= csrfField() ?>
            <div class="grid grid-2">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" placeholder="TopFlame Vote Banner">
                </div>
                <div class="form-group">
                    <label>Size label</label>
                    <input type="text" name="size_label" placeholder="468x60">
                </div>
                <div class="form-group">
                    <label>Sort order</label>
                    <input type="number" name="sort_order" value="0" min="0">
                </div>
                <div class="form-group">
                    <label>Banner image</label>
                    <input type="file" name="banner_image" accept="image/png,image/jpeg,image/webp,image/gif" required>
                </div>
                <div class="form-group">
                    <label style="display:flex;gap:10px;align-items:center;margin-top:36px"><input type="checkbox" name="is_active" checked> Active</label>
                </div>
            </div>
            <div style="margin-top:16px"><button class="btn" type="submit">Upload banner</button></div>
        </form>
    </div>
</section>


<section class="hero"><div class="hero-shell"><div class="badge">Admin / Banners</div><h1 class="title" style="font-size:42px">Banner <span class="gold">Inventory</span></h1></div></section>
<section class="section" style="padding-top:0">
<?php require __DIR__ . '/_admin_nav.php'; ?>
<div class="admin-main">
    <div class="card">
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>ID</th><th>Scope</th><th>Preview</th><th>Title</th><th>Size</th><th>Status</th><th>Sort</th><th>Usage</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($banners as $banner): ?>
                    <?php
                        $gatewayUrl = '';
                        $bannerUrl = public_asset_url((string) $banner['image_url']);
                        $htmlCode = 'Generated automatically per server in the User Panel';
                    ?>
                    <tr>
                        <td><?= (int) $banner['id'] ?></td>
                        <td><a href="/dashboard/banners?id=<?= (int) $banner['server_id'] ?>"><?= e((string) (($banner['server_title'] ?? (((int) ($banner['server_id'] ?? 0) <= 0) ? 'Global / All Servers' : ('Server #' . (int) $banner['server_id']))) ?? (((int) ($banner['server_id'] ?? 0) <= 0) ? 'Global / All Servers' : ('Server #' . (int) $banner['server_id'])))) ?></a></td>
                        <td><img src="<?= e($banner['image_url']) ?>" alt="<?= e($banner['title']) ?>" style="max-width:180px;max-height:60px;border-radius:10px"></td>
                        <td><?= e($banner['title']) ?></td>
                        <td><?= e((string) ($banner['size_label'] ?: '—')) ?></td>
                        <td><?= (int) $banner['is_active'] === 1 ? 'Active' : 'Hidden' ?></td>
                        <td><?= (int) $banner['sort_order'] ?></td>
                    <td style="min-width:280px"><textarea readonly rows="4" class="code-area" onclick="this.select()"><?= e($htmlCode) ?></textarea></td><td><form method="post" action="/admin/banners/delete" onsubmit="return confirm('Delete this banner?')"><?= csrfField() ?><input type="hidden" name="id" value="<?= (int) $banner['id'] ?>"><button class="btn-secondary" type="submit">Delete</button></form></td></tr>
                <?php endforeach; ?>
                <?php if (!$banners): ?><tr><td colspan="9">Δεν υπάρχουν banners ακόμη.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div></div></section>
