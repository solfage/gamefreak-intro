<section class="hero">
    <div class="hero-shell">
        <?php require __DIR__ . '/_user_nav.php'; ?>
            <div class="card">
                <div class="user-section-title">
                    <div>
                        <h2 style="margin:0">My Servers</h2>
                        <p class="muted" style="margin:6px 0 0">Each server has its own polished card, synced with the overall fantasy / gold design language of the site.</p>
                    </div>
                </div>

                <?php if (!$servers): ?>
                    <div class="empty-state-card">
                        <h3>No server added yet</h3>
                        <p class="muted">You have not created a server listing yet.</p>
                        <a class="btn" href="/dashboard/servers/create">Create Server</a>
                    </div>
                <?php else: ?>
                    <div class="user-soft-divider"></div><div class="user-server-stack">
                        <?php foreach ($servers as $server): ?>
                            <div class="user-server-card user-server-card-polished">
                                <div class="user-server-top">
                                    <div>
                                        <div class="badge-tag-row" style="margin:0 0 10px 0">
                                            <?php if ((int) ($server['is_premium'] ?? 0) === 1): ?><span class="pill pill-gold">Premium</span><?php endif; ?>
                                            <span class="pill"><?= e(ucfirst((string) ($server['status'] ?? 'unknown'))) ?></span>
                                        </div>
                                        <h3 style="margin:0 0 8px 0"><?= e($server['title']) ?></h3>
                                        <p class="muted" style="margin:0">Updated <?= e((string) ($server['updated_at'] ?? '—')) ?></p>
                                    </div>
                                    <div class="user-server-actions">
                                        <a class="btn-secondary" href="/server?id=<?= (int) $server['id'] ?>">View Page</a>
                                        <a class="btn-secondary" href="/dashboard/servers/edit?id=<?= (int) $server['id'] ?>">Edit</a>
                                    </div>
                                </div>
                                <div class="user-meta-grid">
                                    <div class="user-mini-box"><span class="k">Votes</span><span class="v"><?= e((string) ($server['raw_votes_total'] ?? 0)) ?></span></div>
                                    <div class="user-mini-box"><span class="k">Score</span><span class="v"><?= e((string) ($server['ranking_score'] ?? 0)) ?></span></div>
                                    <div class="user-mini-box"><span class="k">Views</span><span class="v"><?= e((string) ($server['views_count'] ?? 0)) ?></span></div>
                                    <div class="user-mini-box"><span class="k">Gateway</span><span class="v" style="font-size:13px;word-break:break-all"><?= e(voteGatewayUrl((int) $server['id'])) ?></span></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>