
<section class="hero"><div class="hero-shell"><div class="badge">Admin / Servers</div><h1 class="title" style="font-size:42px">Manage <span class="gold">servers</span></h1></div></section>
<section class="section" style="padding-top:0">
<?php require __DIR__ . '/_admin_nav.php'; ?>
<div class="admin-main">
    <div class="card">
        <div class="section-header"><div><h2>All servers</h2><p>Approval, disable, delete και γρήγορο moderation.</p></div></div>
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>ID</th><th>Title</th><th>Chronicle</th><th>Status</th><th>Premium</th><th>Votes</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($servers as $server): ?>
                    <tr>
                        <td><?= (int) $server['id'] ?></td>
                        <td><?= e($server['title']) ?></td>
                        <td><?= e((string) $server['chronicle']) ?></td>
                        <td><span class="status-badge status-<?= e(strtolower((string) $server['status'])) ?>"><?= e((string) $server['status']) ?></span></td>
                        <td><?= (int) $server['is_premium'] === 1 ? 'Yes' : 'No' ?></td>
                        <td><?= e((string) $server['raw_votes_total']) ?></td>
                        <td>
                            <div class="action-row">
                                <a class="btn-secondary" href="/dashboard/servers/edit?id=<?= (int) $server['id'] ?>">Edit</a>
                                <?php if ((string) $server['status'] !== 'approved'): ?><form method="post" action="/admin/servers/approve"><?= csrfField() ?><input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>"><button class="btn" type="submit">Approve</button></form><?php endif; ?>
                                <?php if ((string) $server['status'] !== 'rejected'): ?><form method="post" action="/admin/servers/reject"><?= csrfField() ?><input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>"><button class="btn-secondary" type="submit">Reject</button></form><?php endif; ?>
                                <?php if ((string) $server['status'] !== 'disabled'): ?><form method="post" action="/admin/servers/disable"><?= csrfField() ?><input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>"><button class="btn-danger" type="submit">Disable</button></form><?php endif; ?>
                                <form method="post" action="/admin/servers/delete" onsubmit="return confirm('Delete this server permanently?');"><?= csrfField() ?><input type="hidden" name="server_id" value="<?= (int) $server['id'] ?>"><button class="btn-danger" type="submit">Delete</button></form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div></div></section>
