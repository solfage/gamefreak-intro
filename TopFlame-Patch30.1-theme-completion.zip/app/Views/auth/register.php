<section class="hero">
    <div class="hero-shell" style="max-width:700px;margin:0 auto">
        <div class="badge badge-premium">New Owner Registration</div>
        <h1 class="title" style="font-size:40px">Create your <span class="gold">TopFlame</span> account</h1>
        <p class="subtitle">Φτιάξε account για να προσθέσεις τον server σου, να πάρεις gateway link και να διαχειρίζεσαι το listing σου από το panel.</p>

        <div class="card soft" style="margin-top:22px">
            <form method="post" action="/register">
                <?= csrfField() ?>
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" required>
                </div>
                <div class="action-row">
                    <button class="btn" type="submit">Create account</button>
                    <a class="btn-secondary" href="/login">Already have account?</a>
                </div>
            </form>
        </div>
    </div>
</section>
