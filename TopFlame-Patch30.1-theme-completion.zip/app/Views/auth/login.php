<section class="hero">
    <div class="hero-shell" style="max-width:620px;margin:0 auto">
        <div class="badge">Account Access</div>
        <h1 class="title" style="font-size:40px">Sign in to your <span class="gold">TopFlame</span> account</h1>
        <p class="subtitle">Login στο panel για να διαχειρίζεσαι τον server, το vote gateway και τα στοιχεία της καταχώρησής σου.</p>

        <div class="card soft" style="margin-top:22px">
            <form method="post" action="/login">
                <?= csrfField() ?>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" required>
                </div>
                <div class="action-row">
                    <button class="btn" type="submit">Sign in</button>
                    <a class="btn-secondary" href="/register">Create account</a>
                </div>
            </form>
        </div>
    </div>
</section>
