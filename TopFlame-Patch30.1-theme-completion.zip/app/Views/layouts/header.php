<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e(config('app.name', 'TopFlame')) ?></title>
    <style>
        :root{
            --bg:#070910;
            --bg-soft:#0d111d;
            --bg-panel:#101726;
            --bg-panel-2:#151d2f;
            --text:#edf2ff;
            --muted:#95a1bb;
            --line:rgba(122, 202, 255, .16);
            --line-strong:rgba(255, 184, 76, .24);
            --cyan:#5ce1ff;
            --violet:#b36cff;
            --gold:#ffcc66;
            --pink:#ff5ad9;
            --green:#5bff9e;
            --danger:#ff7b7b;
            --shadow:0 24px 80px rgba(0,0,0,.35);
            --glow-cyan:0 0 24px rgba(92,225,255,.18);
            --glow-gold:0 0 26px rgba(255,204,102,.16);
            --radius:22px;
            --radius-sm:16px;
        }
        *{box-sizing:border-box}
        html{scroll-behavior:smooth}
        body{
            margin:0;
            font-family:Inter,Segoe UI,Arial,Helvetica,sans-serif;
            color:var(--text);
            background:
                radial-gradient(circle at 10% 0%, rgba(255,204,102,.16), transparent 28%),
                radial-gradient(circle at 100% 10%, rgba(179,108,255,.18), transparent 26%),
                radial-gradient(circle at 50% 100%, rgba(92,225,255,.10), transparent 35%),
                linear-gradient(180deg, #090c14 0%, #070910 55%, #06070d 100%);
            min-height:100vh;
        }
        body:before{
            content:"";
            position:fixed; inset:0; pointer-events:none; z-index:-1;
            background:
                linear-gradient(rgba(255,255,255,.015) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,.015) 1px, transparent 1px);
            background-size: 22px 22px;
            mask-image: linear-gradient(to bottom, rgba(0,0,0,.5), transparent 85%);
        }
        a{color:var(--cyan);text-decoration:none}
        a:hover{opacity:.95}
        img{max-width:100%}
        .container{width:min(1240px,92%);margin:0 auto}
        .nav{
            position:sticky;top:0;z-index:50;
            background:rgba(7,9,16,.72);
            border-bottom:1px solid var(--line);
            backdrop-filter: blur(16px);
            box-shadow:0 8px 30px rgba(0,0,0,.18);
        }
        .nav-inner{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:14px 0}
        .brand-wrap{display:flex;align-items:center;gap:14px}
        .brand-badge{
            width:42px;height:42px;border-radius:14px;
            border:1px solid rgba(255,204,102,.28);
            background:
                radial-gradient(circle at 30% 30%, rgba(255,204,102,.40), transparent 35%),
                linear-gradient(180deg, rgba(255,204,102,.18), rgba(179,108,255,.18));
            box-shadow:var(--glow-gold);
        }
        .brand{font-size:20px;font-weight:800;letter-spacing:.14em;color:#fff;text-transform:uppercase}
        .brand-sub{font-size:11px;color:var(--muted);letter-spacing:.22em;text-transform:uppercase;margin-top:2px}
        .menu{display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:flex-end}
        .nav-link{
            padding:10px 14px;border-radius:999px;color:#dce6ff;
            border:1px solid transparent;transition:.2s ease;
        }
        .nav-link:hover{background:rgba(255,255,255,.03);border-color:var(--line)}
        .btn,.btn-secondary,.btn-danger{
            appearance:none;border:none;cursor:pointer;
            display:inline-flex;align-items:center;justify-content:center;gap:8px;
            min-height:46px;padding:12px 18px;border-radius:14px;
            font-weight:700;letter-spacing:.02em;
            transition:transform .15s ease, box-shadow .15s ease, border-color .15s ease, background .15s ease;
        }
        .btn:hover,.btn-secondary:hover,.btn-danger:hover{transform:translateY(-1px)}
        .btn{
            color:#fff;
            border:1px solid rgba(255,204,102,.30);
            background:linear-gradient(180deg, rgba(255,191,73,.26), rgba(255,116,52,.18));
            box-shadow:var(--glow-gold);
        }
        .btn-secondary{
            color:#eaf3ff;
            border:1px solid var(--line);
            background:linear-gradient(180deg, rgba(92,225,255,.10), rgba(179,108,255,.10));
            box-shadow:var(--glow-cyan);
        }
        .btn-danger{
            color:#fff;
            border:1px solid rgba(255,123,123,.30);
            background:linear-gradient(180deg, rgba(255,123,123,.24), rgba(255,90,217,.14));
        }
        .hero{padding:60px 0 26px}
        .hero-shell{
            position:relative; overflow:hidden;
            border:1px solid rgba(255,255,255,.06);
            background:
                radial-gradient(circle at 15% 20%, rgba(255,204,102,.20), transparent 28%),
                radial-gradient(circle at 85% 20%, rgba(179,108,255,.16), transparent 26%),
                linear-gradient(180deg, rgba(18,24,38,.96), rgba(10,14,24,.96));
            border-radius:30px;
            padding:34px;
            box-shadow:var(--shadow);
        }
        .hero-shell:after{
            content:"";position:absolute;inset:0;pointer-events:none;
            border:1px solid rgba(255,255,255,.04);border-radius:30px;
        }
        .title{font-size:clamp(34px,5vw,58px);line-height:1.02;margin:0 0 14px;font-weight:900;letter-spacing:.02em}
        .title .gold{color:var(--gold);text-shadow:0 0 16px rgba(255,204,102,.15)}
        .subtitle{max-width:820px;color:var(--muted);font-size:17px;line-height:1.65;margin:0}
        .section{padding:18px 0 34px}
        .section-header{display:flex;justify-content:space-between;align-items:end;gap:20px;flex-wrap:wrap;margin-bottom:18px}
        .section-header h2,.card h2,.card h3{margin:0 0 8px}
        .section-header p{margin:0;color:var(--muted)}
        .grid{display:grid;gap:18px}
        .grid-2{grid-template-columns:repeat(auto-fit,minmax(280px,1fr))}
        .grid-3{grid-template-columns:repeat(auto-fit,minmax(250px,1fr))}
        .grid-4{grid-template-columns:repeat(auto-fit,minmax(200px,1fr))}
        .card,.stat-card,.feature-card{
            background:
                linear-gradient(180deg, rgba(18,24,39,.95), rgba(10,14,24,.95));
            border:1px solid var(--line);
            border-radius:var(--radius);
            padding:20px;
            box-shadow:var(--shadow);
        }
        .card.soft{background:linear-gradient(180deg, rgba(17,23,36,.88), rgba(10,14,24,.88))}
        .premium{
            border-color:rgba(255,204,102,.26);
            box-shadow:var(--shadow), var(--glow-gold);
            background:
                radial-gradient(circle at top right, rgba(255,204,102,.08), transparent 28%),
                linear-gradient(180deg, rgba(24,22,24,.96), rgba(11,13,21,.96));
        }
        .feature-card{padding:22px}
        .feature-icon,.mini-icon{
            display:inline-flex;align-items:center;justify-content:center;
            border-radius:16px;border:1px solid var(--line);
            background:linear-gradient(180deg, rgba(92,225,255,.12), rgba(179,108,255,.10));
            box-shadow:var(--glow-cyan);
        }
        .feature-icon{width:54px;height:54px;font-size:22px;margin-bottom:12px}
        .mini-icon{width:38px;height:38px;font-size:16px}
        .stat-card .rank{
            font-size:34px;font-weight:900;color:#fff;margin-bottom:6px;
            text-shadow:0 0 14px rgba(92,225,255,.18);
        }
        .muted{color:var(--muted)}
        .badge,.status-badge{
            display:inline-flex;align-items:center;gap:8px;
            padding:8px 12px;border-radius:999px;
            border:1px solid var(--line);
            background:rgba(255,255,255,.03);
            font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
        }
        .badge-premium{border-color:rgba(255,204,102,.30);color:#ffe1a0;background:rgba(255,204,102,.08)}
        .status-approved{border-color:rgba(91,255,158,.28);color:#c9ffe0;background:rgba(91,255,158,.08)}
        .status-pending{border-color:rgba(255,204,102,.28);color:#ffe7b1;background:rgba(255,204,102,.08)}
        .status-disabled,.status-rejected{border-color:rgba(255,123,123,.28);color:#ffd0d0;background:rgba(255,123,123,.08)}
        .flash{
            padding:14px 16px;margin:20px 0;border-radius:16px;
            border:1px solid rgba(91,255,158,.28);background:rgba(91,255,158,.08);
            box-shadow:0 0 20px rgba(91,255,158,.08)
        }
        .stats-inline,.pill-row,.meta-grid,.action-row,.toolbar{display:flex;gap:12px;flex-wrap:wrap}
        
        .tag-row{display:flex;flex-wrap:wrap;gap:10px;margin:14px 0 0}

        .badge-tag-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:8px 0 0}

        .listing-badge-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:8px 0 0}
        .listing-badge{
            display:inline-flex;align-items:center;gap:8px;
            padding:7px 11px;border-radius:999px;
            border:1px solid rgba(255,204,102,.18);
            background:linear-gradient(180deg, rgba(255,204,102,.09), rgba(179,108,255,.06));
            color:#fff;font-size:12px;font-weight:700;letter-spacing:.03em;
            box-shadow:var(--glow-gold);
        }
        .listing-badge .k{color:var(--gold);font-size:11px;text-transform:uppercase;letter-spacing:.08em}


        .admin-shell{display:grid;grid-template-columns:280px minmax(0,1fr);gap:22px;align-items:start}
        .admin-side{position:sticky;top:100px}
        .admin-main{min-width:0}
        .admin-nav{display:flex;flex-direction:column;gap:10px;margin-top:14px}
        .admin-nav-link{display:block;padding:12px 14px;border-radius:14px;border:1px solid var(--line);background:rgba(255,255,255,.02);color:#dbe8ff;text-decoration:none}
        .admin-nav-link.active,.admin-nav-link:hover{background:linear-gradient(180deg, rgba(92,225,255,.12), rgba(179,108,255,.12));box-shadow:var(--glow-cyan)}
        .inline-form{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;align-items:center}
        .stack{display:grid;gap:18px}
        @media (max-width:980px){.admin-shell{grid-template-columns:1fr}.admin-side{position:static}.inline-form{grid-template-columns:1fr 1fr}}

        .badge-tag-row .pill,.badge-tag-row .server-tag{margin:0}
        .badge-tag-row .server-tag{
            padding:6px 10px;
            font-size:12px;
            box-shadow:none;
            background:linear-gradient(180deg, rgba(92,225,255,.06), rgba(179,108,255,.06));
        }
        .badge-tag-row .server-tag strong{font-size:11px}

        .server-tag{
            display:inline-flex;align-items:center;gap:8px;
            padding:8px 12px;border-radius:999px;
            border:1px solid var(--line);
            background:linear-gradient(180deg, rgba(92,225,255,.08), rgba(179,108,255,.08));
            color:#eef6ff;font-size:13px;font-weight:700;letter-spacing:.02em;
            box-shadow:var(--glow-cyan);
        }
        .server-tag strong{color:var(--gold);font-size:12px;text-transform:uppercase;letter-spacing:.08em}

        .pill{
            padding:10px 14px;border-radius:999px;
            border:1px solid var(--line);
            background:rgba(255,255,255,.03);color:#eef5ff
        }
        .server-card{
            position:relative;overflow:hidden;display:flex;flex-direction:column;gap:14px;min-height:100%;
        }
        .server-card:before{
            content:"";position:absolute;inset:auto -20% 78% auto;width:180px;height:180px;border-radius:50%;
            background:radial-gradient(circle, rgba(92,225,255,.18), transparent 70%);pointer-events:none;
        }
        .server-top{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}
        .server-title{font-size:24px;font-weight:800;margin:0}
        .server-sub{margin:0;color:var(--muted);line-height:1.6}
        .stats-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
        .stat-box{
            padding:14px;border-radius:16px;border:1px solid rgba(255,255,255,.05);
            background:rgba(255,255,255,.03)
        }
        .stat-box strong{display:block;font-size:22px;margin-top:6px}
        .table-wrap{
            border:1px solid var(--line);border-radius:20px;overflow:hidden;
            background:linear-gradient(180deg, rgba(14,18,28,.96), rgba(8,11,18,.96));
            box-shadow:var(--shadow)
        }
        .table{width:100%;border-collapse:collapse}
        .table th,.table td{padding:14px 16px;border-bottom:1px solid rgba(255,255,255,.06);text-align:left;vertical-align:top}
        .table th{font-size:12px;letter-spacing:.10em;text-transform:uppercase;color:#c2d1ef;background:rgba(255,255,255,.02)}
        .table tr:last-child td{border-bottom:none}
        .table tr:hover td{background:rgba(255,255,255,.015)}
        .code-box{
            padding:16px;border-radius:18px;border:1px solid var(--line);background:#0b111d
        }
        .code-area,input,textarea,select{
            width:100%;padding:13px 14px;border-radius:14px;
            border:1px solid var(--line);
            background:#0c1320;color:#fff;outline:none;
        }
        input:focus,textarea:focus,select:focus{border-color:rgba(92,225,255,.40);box-shadow:0 0 0 4px rgba(92,225,255,.08)}
        .code-area{min-height:148px;font-family:Consolas,Monaco,"Courier New",monospace;font-size:13px;line-height:1.5}
        label{display:block;margin:0 0 8px;font-size:13px;color:#dfe8ff;font-weight:700}
        .form-group{margin-bottom:16px}
        .form-note{font-size:13px;color:var(--muted);margin-top:8px}
        .split-hero{display:grid;grid-template-columns:1.35fr .9fr;gap:18px}
        .hero-panel{
            border:1px solid rgba(255,255,255,.06);border-radius:24px;padding:22px;
            background:rgba(255,255,255,.03)
        }
        .hero-panel h3{margin:0 0 8px}
        .list-clean{list-style:none;margin:0;padding:0}
        .list-clean li{padding:10px 0;border-bottom:1px solid rgba(255,255,255,.06)}
        .list-clean li:last-child{border-bottom:none}
        .footer{
            margin-top:36px;padding:30px 0 42px;border-top:1px solid var(--line);
            color:var(--muted);background:linear-gradient(180deg, transparent, rgba(255,255,255,.02))
        }
        .footer-grid{display:grid;grid-template-columns:1.2fr .8fr .8fr;gap:18px}
        .empty-state{
            padding:28px;border-radius:20px;border:1px dashed rgba(255,255,255,.12);
            background:rgba(255,255,255,.025);text-align:center;color:var(--muted)
        }
        .cover-banner{
            min-height:180px;border-radius:24px;padding:24px;border:1px solid rgba(255,255,255,.06);
            background:
                radial-gradient(circle at top left, rgba(255,204,102,.18), transparent 30%),
                radial-gradient(circle at bottom right, rgba(92,225,255,.12), transparent 30%),
                linear-gradient(135deg, rgba(31,22,22,.95), rgba(14,19,33,.95));
            box-shadow:var(--shadow)
        }
        .links-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}
        .link-tile{
            padding:14px;border-radius:16px;border:1px solid var(--line);
            background:rgba(255,255,255,.03)
        }
        .stack{display:grid;gap:18px}
        @media (max-width: 900px){
            .split-hero,.footer-grid{grid-template-columns:1fr}
            .menu{justify-content:flex-start}
            .hero-shell{padding:24px}
            .title{font-size:36px}
        }
            .theme-preview-frame{border-radius:18px;border:1px solid rgba(255,204,102,.18);padding:8px;background:rgba(255,255,255,.03)}
    </style>
    <?php if (function_exists('activeThemeCssPath') && activeThemeCssPath()): ?>
        <link rel="stylesheet" href="<?= e((string) activeThemeCssPath()) ?>?v=<?= e((string) ((activeThemeRow()['version'] ?? '1.0.0'))) ?>">
    <?php endif; ?>
</head>
<body>
    <nav class="nav">
        <div class="container nav-inner">
            <div class="brand-wrap">
                <div class="brand-badge"></div>
                <div>
                    <div class="brand"><?= e(config('app.name', 'TopFlame')) ?></div>
                    <div class="brand-sub">Lineage 2 Server Ranking</div>
                </div>
            </div>

            <div class="menu">
                <a class="nav-link" href="/">Home</a>
                <a class="nav-link" href="/servers">Servers</a>
                <?php if (isLoggedIn()): ?>
                    <a class="nav-link" href="/dashboard">Panel</a>
                    <a class="nav-link" href="/dashboard/servers/create">Submit Server</a>
                    <?php if (isAdmin()): ?><a class="nav-link" href="/admin">Admin</a><?php endif; ?>
                    <form method="post" action="/logout" style="margin:0">
                        <?= csrfField() ?>
                        <button class="btn-secondary" type="submit">Logout</button>
                    </form>
                <?php else: ?>
                    <a class="nav-link" href="/login">Login</a>
                    <a class="btn" href="/register">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <main class="container">
        <?php if (!empty($_SESSION['flash'])): ?>
            <div class="flash"><?= e($_SESSION['flash']); unset($_SESSION['flash']); ?></div>
        <?php endif; ?>
