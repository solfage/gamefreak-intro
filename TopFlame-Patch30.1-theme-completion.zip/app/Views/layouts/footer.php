    </main>
    <footer class="footer">
        <div class="container footer-grid">
            <div>
                <div class="brand" style="font-size:18px"><?= e(config('app.name', 'TopFlame')) ?></div>
                <p class="muted" style="margin:10px 0 0;max-width:560px">
                    Fantasy / neon portal για Lineage 2 private servers με listings, premium placement, vote gateway flow και dashboard για owners και admins.
                </p>
            </div>
            <div>
                <h3 style="margin:0 0 10px">Navigation</h3>
                <ul class="list-clean">
                    <li><a href="/">Home</a></li>
                    <li><a href="/servers">Server List</a></li>
                    <li><a href="/register">Create Account</a></li>
                </ul>
            </div>
            <div>
                <h3 style="margin:0 0 10px">Portal</h3>
                <ul class="list-clean">
                    <li>Premium ranking ready</li>
                    <li>Vote gateway support</li>
                    <li>Installer included</li>
                </ul>
            </div>
        </div>
    </footer>
</body>
</html>
