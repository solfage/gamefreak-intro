<section class="hero">
    <div class="hero-shell">
        <div class="split-hero">
            <div>
                <div class="badge badge-premium">TopFlame Portal</div>
                <h1 class="title"><span class="gold">Lineage 2</span> private servers with a stronger, cleaner, more premium look.</h1>
                <p class="subtitle">
                    Ranking portal για L2 servers με premium visibility, vote gateway flow, user panel, admin moderation
                    και γρήγορο installer. Το design πλέον είναι πιο fantasy, πιο polished και πιο έτοιμο για σοβαρό listing site.
                </p>

                <div class="action-row" style="margin-top:22px">
                    <a class="btn" href="/servers">Explore Servers</a>
                    <a class="btn-secondary" href="/dashboard/servers/create">Submit Your Server</a>
                </div>

                <div class="stats-inline" style="margin-top:22px">
                    <div class="pill">Premium-ready ranking</div>
                    <div class="pill">External banner gateway flow</div>
                    <div class="pill">Admin approvals</div>
                    <div class="pill">One-click installer</div>
                </div>
            </div>

            <div class="hero-panel">
                <h3>Why it feels stronger now</h3>
                <ul class="list-clean">
                    <li>Πιο όμορφο homepage και καλύτερη πρώτη εικόνα</li>
                    <li>Καλύτερα cards, tables, panels και forms</li>
                    <li>Fantasy / gold / neon ύφος σε όλο το site</li>
                    <li>Πιο premium server detail experience</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="grid grid-4">
        <div class="stat-card">
            <div class="rank"><?= count($topServers) ?></div>
            <div class="muted">Top ranked entries</div>
        </div>
        <div class="stat-card">
            <div class="rank"><?= count($premiumServers) ?></div>
            <div class="muted">Premium placements</div>
        </div>
        <div class="stat-card">
            <div class="rank"><?= count($latestServers) ?></div>
            <div class="muted">Latest approved</div>
        </div>
        <div class="stat-card">
            <div class="rank">24/7</div>
            <div class="muted">Portal visibility</div>
        </div>
    </div>
</section>

<section class="section">
    <div class="section-header">
        <div>
            <h2>Portal features</h2>
            <p>Ένα πιο “γεμάτο” landing section για να δείχνει το site πιο ολοκληρωμένο.</p>
        </div>
    </div>

    <div class="grid grid-3">
        <div class="feature-card">
            <div class="feature-icon">⚔</div>
            <h3>Vote gateway flow</h3>
            <p class="muted">External banner/site → TopFlame gateway → external vote page → επιστροφή στο server page.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon">★</div>
            <h3>Premium visibility</h3>
            <p class="muted">Boosted ranking, πιο έντονο styling και καλύτερη παρουσίαση για premium servers.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon">🛡</div>
            <h3>Protected workflow</h3>
            <p class="muted">Register/login, approvals, dashboards και ασφαλέστερη συνολική δομή από το αρχικό starter.</p>
        </div>
    </div>
</section>

<section class="section">
    <div class="section-header">
        <div>
            <h2>Featured premium servers</h2>
            <p>Οι premium καταχωρήσεις δείχνουν αμέσως πιο δυνατές και πιο ξεχωριστές.</p>
        </div>
        <a class="btn-secondary" href="/servers?premium=1">View premium list</a>
    </div>

    <div class="grid grid-3">
        <?php foreach ($premiumServers as $server): ?>
<?php
    $serverStatusValue = strtolower((string)(($server['status'] ?? 'approved') ?? 'approved'));
    $serverVotesValue = (int)(($server['raw_votes_total'] ?? 0) ?? 0);
    $serverRankingValue = (float)(($server['ranking_score'] ?? 0) ?? 0);
?>

            <div class="card premium server-card">
                <div class="server-top">
                    <div>
                        <div class="badge badge-premium">Premium</div>
                        <h3 class="server-title"><?= e($server['title']) ?></h3>
                    </div>
                    <div class="mini-icon">🔥</div>
                </div>
                <p class="server-sub"><?= e($server['short_description']) ?></p>
                <div class="stats-grid">
                    <div class="stat-box"><span class="muted">Chronicle</span><strong><?= e($server['chronicle']) ?></strong></div>
                    <div class="stat-box"><span class="muted">Votes</span><strong><?= e((string) (($server['raw_votes_total'] ?? 0) ?? 0)) ?></strong></div>
                    <div class="stat-box"><span class="muted">Score</span><strong><?= e((string) (($server['ranking_score'] ?? 0) ?? 0)) ?></strong></div>
                    <div class="stat-box"><span class="muted">Status</span><strong><?= e(ucfirst((string) ($server['status'] ?? 'approved'))) ?></strong></div>
                </div>
                <div class="action-row">
                    <a class="btn" href="/server?id=<?= (int) $server['id'] ?>">View server</a>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (!$premiumServers): ?>
            <div class="empty-state">Δεν υπάρχουν ακόμη premium servers.</div>
        <?php endif; ?>
    </div>
</section>

<section class="section">
    <div class="section-header">
        <div>
            <h2>Top ranked servers</h2>
            <p>Πιο καθαρό ranking table με καλύτερο visual depth.</p>
        </div>
        <a class="btn-secondary" href="/servers">Full rankings</a>
    </div>

    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr><th>#</th><th>Server</th><th>Chronicle</th><th>Votes</th><th>Score</th></tr>
            </thead>
            <tbody>
            <?php foreach ($topServers as $i => $server): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td>
                        <a href="/server?id=<?= (int) $server['id'] ?>"><?= e($server['title']) ?></a>
                        <?php if ((int) $server['is_premium'] === 1): ?>
                            <span class="badge badge-premium">Premium</span>
                        <?php endif; ?>
                    </td>
                    <td><?= e($server['chronicle']) ?></td>
                    <td><?= e((string) (($server['raw_votes_total'] ?? 0) ?? 0)) ?></td>
                    <td><?= e((string) (($server['ranking_score'] ?? 0) ?? 0)) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$topServers): ?>
                <tr><td colspan="5">Δεν υπάρχουν ακόμη καταχωρήσεις.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="section">
    <div class="section-header">
        <div>
            <h2>Latest approved servers</h2>
            <p>Πιο όμορφα latest cards για καλύτερο browsing.</p>
        </div>
    </div>

    <div class="grid grid-2">
        <?php foreach ($latestServers as $server): ?>
            <div class="card server-card <?= (int) $server['is_premium'] === 1 ? 'premium' : '' ?>">
                <div class="server-top">
                    <div>
                        <?php if ((int) $server['is_premium'] === 1): ?><div class="badge badge-premium">Premium</div><?php endif; ?>
                        <h3 class="server-title"><?= e($server['title']) ?></h3>
                    </div>
                    <div class="mini-icon">⚡</div>
                </div>
                <p class="server-sub"><?= e($server['short_description']) ?></p>
                <div class="pill-row">
                    <span class="pill"><?= e($server['chronicle']) ?></span>
                    <span class="pill">Votes <?= e((string) (($server['raw_votes_total'] ?? 0) ?? 0)) ?></span>
                    <span class="pill">Score <?= e((string) (($server['ranking_score'] ?? 0) ?? 0)) ?></span>
                </div>
                <div class="action-row">
                    <a class="btn-secondary" href="/server?id=<?= (int) $server['id'] ?>">Open details</a>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (!$latestServers): ?>
            <div class="empty-state">Μόλις μπουν οι πρώτοι servers, θα εμφανίζονται εδώ.</div>
        <?php endif; ?>
    </div>
</section>
