<?php

declare(strict_types=1);

final class ServerController
{
    public function index(): void
    {
        $filters = [
            'q' => trim((string) ($_GET['q'] ?? '')),
            'chronicle' => trim((string) ($_GET['chronicle'] ?? '')),
            'country' => trim((string) ($_GET['country'] ?? '')),
            'premium' => trim((string) ($_GET['premium'] ?? '')),
            'sort' => trim((string) ($_GET['sort'] ?? 'ranking')),
        ];

        $where = ["status = 'approved'"];
        $params = [];

        if ($filters['q'] !== '') {
            $where[] = "(title LIKE :q OR short_description LIKE :q OR full_description LIKE :q)";
            $params['q'] = '%' . $filters['q'] . '%';
        }

        if ($filters['chronicle'] !== '') {
            $where[] = "chronicle = :chronicle";
            $params['chronicle'] = $filters['chronicle'];
        }

        if ($filters['country'] !== '') {
            $where[] = "country = :country";
            $params['country'] = $filters['country'];
        }

        if ($filters['premium'] === '1') {
            $where[] = "is_premium = 1";
        }

        $allowedSorts = [
            'ranking' => 'ranking_score DESC, raw_votes_total DESC, id DESC',
            'votes' => 'raw_votes_total DESC, ranking_score DESC, id DESC',
            'latest' => 'id DESC',
            'views' => 'views_count DESC, ranking_score DESC, id DESC',
        ];
        $orderBy = $allowedSorts[$filters['sort']] ?? $allowedSorts['ranking'];

        $servers = db()->select(
            "SELECT id, title, short_description, chronicle, xp_rate, uptime_percent, raw_votes_total, ranking_score, is_premium, logo_path, country, views_count
             FROM servers
             WHERE " . implode(' AND ', $where) . "
             ORDER BY {$orderBy}",
            $params
        );

        $chronicles = array_map(static fn (string $chronicle): array => ['chronicle' => $chronicle], l2Chronicles());
        $countries = array_map(static fn (string $country): array => ['country' => $country], serverCountries());

        view('servers/index', compact('servers', 'filters', 'chronicles', 'countries'));
    }

    public function show(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        $server = db()->first(
            "SELECT * FROM servers WHERE id = :id AND status = 'approved' LIMIT 1",
            ['id' => $id]
        );

        if (!$server) {
            renderErrorPage(404, 'The server was not found or is not available.');
        }

        db()->statement("UPDATE servers SET views_count = views_count + 1 WHERE id = :id", ['id' => $id]);
        $server['views_count'] = (int) ($server['views_count'] ?? 0) + 1;

        $banners = db()->select(
            "SELECT id, title, image_url, size_label, sort_order, is_active
             FROM server_banners
             WHERE server_id = :server_id AND is_active = 1
             ORDER BY sort_order ASC, id ASC",
            ['server_id' => $id]
        );

        view('servers/show', compact('server', 'banners'));
    }

    public function createForm(): void
    {
        requireAuth();
        $user = currentUser();
        if (!isAdmin()) {
            $existing = db()->first("SELECT id FROM servers WHERE user_id = :user_id LIMIT 1", ['user_id' => $user['id']]);
            if ($existing) {
                $_SESSION['flash'] = 'Each account can only have 1 server.';
                redirect('/dashboard');
            }
        }

        $server = $this->emptyServer();
        $formAction = '/dashboard/servers/create';
        $submitLabel = 'Submit Server';
        $pageTitle = 'Create New Server';
        $chronicleOptions = l2Chronicles();
        $countryOptions = serverCountries();
        $languageOptions = serverLanguages();
        view('servers/form', compact('server', 'formAction', 'submitLabel', 'pageTitle', 'chronicleOptions', 'countryOptions', 'languageOptions'));
    }

    public function create(): void
    {
        requireAuth();
        verifyCsrf();

        $user = currentUser();
        if (!isAdmin()) {
            $existing = db()->first("SELECT id FROM servers WHERE user_id = :user_id LIMIT 1", ['user_id' => $user['id']]);
            if ($existing) {
                validationRedirect('Each account can only submit 1 server.');
            }
        }

        $data = $this->validatedInput();
        $slug = uniqueServerSlug($data['title']);

        db()->statement(
            "INSERT INTO servers (
                user_id, title, slug, short_description, full_description, chronicle,
                xp_rate, sp_rate, adena_rate, drop_rate, country, language,
                website_url, register_url, download_url, patch_url, updater_url, vote_gateway_url,
                login_server_status, game_server_status, login_ip, login_port, game_ip, game_port,
                feature_gm_shop, feature_buffer, feature_gatekeeper,
                safe_enchant, max_enchant, normal_enchant_rate, blessed_enchant_rate,
                uptime_percent, online_players_enabled, online_players, last_status_check_at,
                logo_path, banner_path,
                status, created_at, updated_at
             ) VALUES (
                :user_id, :title, :slug, :short_description, :full_description, :chronicle,
                :xp_rate, :sp_rate, :adena_rate, :drop_rate, :country, :language,
                :website_url, :register_url, :download_url, :patch_url, :updater_url, :vote_gateway_url,
                :login_server_status, :game_server_status, :login_ip, :login_port, :game_ip, :game_port,
                :feature_gm_shop, :feature_buffer, :feature_gatekeeper,
                :safe_enchant, :max_enchant, :normal_enchant_rate, :blessed_enchant_rate,
                :uptime_percent, :online_players_enabled, :online_players, :last_status_check_at,
                :logo_path, :banner_path,
                :status, NOW(), NOW()
             )",
            array_merge($data, [
                'user_id' => $user['id'],
                'slug' => $slug,
                'status' => 'pending',
            ])
        );

        $_SESSION['flash'] = 'The server has been submitted and is waiting for admin approval.';
        redirect('/dashboard');
    }

    public function editForm(): void
    {
        requireAuth();

        $server = $this->findOwnedOrAdminServer((int) ($_GET['id'] ?? 0));
        if (!$server) {
            renderErrorPage(404, 'The server was not found.');
        }

        $formAction = '/dashboard/servers/update';
        $submitLabel = 'Save Changes';
        $pageTitle = 'Edit Server';
        $chronicleOptions = l2Chronicles();
        $countryOptions = serverCountries();
        $languageOptions = serverLanguages();
        view('servers/form', compact('server', 'formAction', 'submitLabel', 'pageTitle', 'chronicleOptions', 'countryOptions', 'languageOptions'));
    }

    public function update(): void
    {
        requireAuth();
        verifyCsrf();

        $id = (int) ($_POST['id'] ?? 0);
        $server = $this->findOwnedOrAdminServer($id);
        if (!$server) {
            renderErrorPage(404, 'The server was not found.');
        }

        $data = $this->validatedInput($server);
        $isPremium = (int) ($server['is_premium'] ?? 0) === 1;
        $newStatus = isAdmin() ? ($server['status'] ?? 'pending') : ($isPremium ? 'approved' : 'pending');

        db()->statement(
            "UPDATE servers SET
                title = :title,
                short_description = :short_description,
                full_description = :full_description,
                chronicle = :chronicle,
                xp_rate = :xp_rate,
                sp_rate = :sp_rate,
                adena_rate = :adena_rate,
                drop_rate = :drop_rate,
                country = :country,
                language = :language,
                website_url = :website_url,
                register_url = :register_url,
                download_url = :download_url,
                patch_url = :patch_url,
                updater_url = :updater_url,
                vote_gateway_url = :vote_gateway_url,
                login_server_status = :login_server_status,
                game_server_status = :game_server_status,
                login_ip = :login_ip,
                login_port = :login_port,
                game_ip = :game_ip,
                game_port = :game_port,
                feature_gm_shop = :feature_gm_shop,
                feature_buffer = :feature_buffer,
                feature_gatekeeper = :feature_gatekeeper,
                safe_enchant = :safe_enchant,
                max_enchant = :max_enchant,
                normal_enchant_rate = :normal_enchant_rate,
                blessed_enchant_rate = :blessed_enchant_rate,
                uptime_percent = :uptime_percent,
                online_players_enabled = :online_players_enabled,
                online_players = :online_players,
                last_status_check_at = :last_status_check_at,
                logo_path = :logo_path,
                banner_path = :banner_path,
                status = :status,
                updated_at = NOW()
             WHERE id = :id",
            array_merge($data, [
                'id' => $id,
                'status' => $newStatus,
            ])
        );

        if (!isAdmin()) {
            logAdminAction('server_updated_by_user', 'server', $id, [
                'status' => $newStatus,
                'premium_auto_accept' => $isPremium,
            ]);
        }

        $_SESSION['flash'] = isAdmin()
            ? 'Changes saved successfully.'
            : ($isPremium
                ? 'Changes saved successfully and the premium server stayed approved.'
                : 'Changes saved successfully and the server was sent back for approval.');
        redirect('/dashboard');
    }

    public function bannerManager(): void
    {
        requireAuth();
        redirect('/dashboard');
    }

    public function createBanner(): void
    {
        requireAuth();
        redirect('/dashboard');
    }

    public function updateBanner(): void
    {
        requireAuth();
        redirect('/dashboard');
    }

    public function deleteBanner(): void
    {
        requireAuth();
        redirect('/dashboard');
    }

    public function voteGateway(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        $server = db()->first(
            "SELECT id, title, short_description, vote_gateway_url, register_url, website_url, status FROM servers WHERE id = :id LIMIT 1",
            ['id' => $id]
        );

        if (!$server || $server['status'] !== 'approved') {
            renderErrorPage(404, 'The server was not found or is not available for vote gateway access.');
        }

        $selectedBanner = null;
        $bannerId = (int) ($_GET['banner'] ?? 0);
        if ($bannerId > 0) {
            $selectedBanner = db()->first(
                "SELECT id, title, image_url, size_label FROM server_banners WHERE id = :id AND server_id = :server_id AND is_active = 1 LIMIT 1",
                ['id' => $bannerId, 'server_id' => $id]
            );
        }

        markVoteGatewayVisit($id);
        view('servers/vote_gateway', compact('server', 'selectedBanner'));
    }

    public function vote(): void
    {
        verifyCsrf();

        $id = (int) ($_POST['server_id'] ?? 0);
        if ($id < 1) {
            redirect('/servers');
        }

        $server = db()->first("SELECT id, title, status, vote_gateway_url FROM servers WHERE id = :id LIMIT 1", ['id' => $id]);
        if (!$server || $server['status'] !== 'approved') {
            $_SESSION['flash'] = 'This server is not available for voting.';
            redirect('/servers');
        }

        if (!hasRecentVoteGatewayVisit($id)) {
            $_SESSION['flash'] = 'You must first pass through the server vote gateway.';
            redirect(voteGatewayPath($id));
        }

        $ip = clientIp();
        enforceRateLimit('vote', $ip . '|' . $id, 12, 3600, 'Πολύ γρήγορες προσπάθειες ψήφου. Δοκίμασε ξανά αργότερα.', '/server?id=' . $id);

        $existing = db()->first(
            "SELECT id FROM server_votes WHERE server_id = :server_id AND ip_address = :ip AND vote_date = CURDATE() LIMIT 1",
            ['server_id' => $id, 'ip' => $ip]
        );

        if ($existing) {
            $_SESSION['flash'] = 'A vote from this IP has already been recorded today.';
            redirect(serverViewUrl($id));
        }

        db()->statement(
            "INSERT INTO server_votes (server_id, user_id, ip_address, user_agent, vote_date, created_at)
             VALUES (:server_id, :user_id, :ip, :ua, CURDATE(), NOW())",
            [
                'server_id' => $id,
                'user_id' => currentUser()['id'] ?? null,
                'ip' => $ip,
                'ua' => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown'), 0, 255),
            ]
        );

        db()->statement(
            "UPDATE servers
             SET raw_votes_total = raw_votes_total + 1,
                 raw_votes_daily = raw_votes_daily + 1,
                 raw_votes_weekly = raw_votes_weekly + 1,
                 raw_votes_monthly = raw_votes_monthly + 1,
                 ranking_score = CASE
                     WHEN is_premium = 1 AND premium_boost_type = 'percent'
                        THEN ROUND((raw_votes_total + 1) * (1 + (premium_boost_value / 100)), 2)
                     WHEN is_premium = 1 AND premium_boost_type = 'fixed'
                        THEN (raw_votes_total + 1) + premium_boost_value
                     ELSE raw_votes_total + 1
                 END
             WHERE id = :id",
            ['id' => $id]
        );

        clearVoteGatewayVisit($id);
        $_SESSION['flash'] = 'Your vote was recorded successfully.';
        redirect(serverViewUrl($id));
    }

    private function emptyServer(): array
    {
        return [
            'id' => null,
            'title' => '',
            'short_description' => '',
            'full_description' => '',
            'chronicle' => '',
            'xp_rate' => '1.00',
            'sp_rate' => '1.00',
            'adena_rate' => '1.00',
            'drop_rate' => '1.00',
            'country' => '',
            'language' => '',
            'website_url' => '',
            'register_url' => '',
            'download_url' => '',
            'patch_url' => '',
            'updater_url' => '',
            'vote_gateway_url' => '',
            'login_server_status' => 0,
            'game_server_status' => 0,
            'login_ip' => '',
            'login_port' => '',
            'game_ip' => '',
            'game_port' => '',
            'uptime_percent' => '100.00',
            'online_players_enabled' => 0,
            'online_players' => '',
            'last_status_check_at' => null,
            'feature_gm_shop' => 0,
            'feature_buffer' => 0,
            'feature_gatekeeper' => 0,
            'safe_enchant' => '',
            'max_enchant' => '',
            'normal_enchant_rate' => '',
            'blessed_enchant_rate' => '',
            'logo_path' => '',
            'banner_path' => '',
            'is_premium' => 0,
        ];
    }

    private function validatedInput(array $existingServer = []): array
    {
        $title = trim((string) ($_POST['title'] ?? ''));
        $short = trim((string) ($_POST['short_description'] ?? ''));
        $full = trim((string) ($_POST['full_description'] ?? ''));
        $chronicle = trim((string) ($_POST['chronicle'] ?? ''));
        $country = trim((string) ($_POST['country'] ?? ''));
        $language = trim((string) ($_POST['language'] ?? ''));

        if ($title === '' || mb_strlen($title) > 180) {
            validationRedirect('Enter a valid title up to 180 characters.');
        }
        if ($short === '' || mb_strlen($short) > 300) {
            validationRedirect('Enter a short description up to 300 characters.');
        }
        if ($full === '') {
            validationRedirect('Enter a full description.');
        }
        if ($chronicle === '' || !isAllowedChronicle($chronicle)) {
            validationRedirect('Select a valid chronicle from the list.');
        }
        if (!isAllowedCountry($country === '' ? null : $country)) {
            validationRedirect('Select a valid country from the list.');
        }
        if (!isAllowedLanguage($language === '' ? null : $language)) {
            validationRedirect('Select a valid language from the list.');
        }

        $rates = [];
        foreach (['xp_rate', 'sp_rate', 'adena_rate', 'drop_rate'] as $field) {
            $value = (float) ($_POST[$field] ?? 0);
            if ($value <= 0) {
                validationRedirect('All rates must be greater than 0.');
            }
            $rates[$field] = number_format($value, 2, '.', '');
        }

        $urlFields = ['website_url', 'register_url', 'download_url', 'patch_url', 'updater_url', 'vote_gateway_url'];
        $urls = [];
        foreach ($urlFields as $field) {
            $value = trim((string) ($_POST[$field] ?? ''));
            if ($field === 'website_url' && $value === '') {
                validationRedirect('Website URL is required.');
            }
            if ($value !== '' && !isValidPublicUrl($value)) {
                validationRedirect('One or more links are not valid public URLs.');
            }
            $urls[$field] = $value !== '' ? $value : null;
        }

        $loginIp = trim((string) ($_POST['login_ip'] ?? ''));
        $gameIp = trim((string) ($_POST['game_ip'] ?? ''));
        foreach ([$loginIp, $gameIp] as $value) {
            if ($value !== '' && mb_strlen($value) > 100) {
                validationRedirect('Hostname/IP fields must be up to 100 characters long.');
            }
        }

        $loginPort = trim((string) ($_POST['login_port'] ?? ''));
        $gamePort = trim((string) ($_POST['game_port'] ?? ''));
        foreach ([$loginPort, $gamePort] as $port) {
            if ($port !== '' && (!ctype_digit($port) || (int) $port < 1 || (int) $port > 65535)) {
                validationRedirect('Ports must be between 1 and 65535.');
            }
        }

        $loginOnlineRaw = trim((string) ($_POST['login_online'] ?? ''));
        $gameOnlineRaw = trim((string) ($_POST['game_online'] ?? ''));
        $loginOnline = in_array(strtolower($loginOnlineRaw), ['1', 'true', 'yes', 'online'], true);
        $gameOnline = in_array(strtolower($gameOnlineRaw), ['1', 'true', 'yes', 'online'], true);

        if (!$loginOnline || !$gameOnline) {
            validationRedirect('Only online servers can be submitted. Both Login and Game server must be online.');
        }

        $currentId = (int) ($existingServer['id'] ?? 0);
        foreach ([$loginIp, $gameIp] as $value) {
            if ($value === '') {
                continue;
            }
            $duplicate = db()->first(
                "SELECT id, title FROM servers
                 WHERE id <> :id
                   AND (
                        LOWER(COALESCE(login_ip, '')) = LOWER(:value)
                        OR LOWER(COALESCE(game_ip, '')) = LOWER(:value)
                   )
                 LIMIT 1",
                ['id' => $currentId, 'value' => $value]
            );
            if ($duplicate) {
                validationRedirect('The IP/hostname "' . $value . '" is already used by another server.');
            }
        }

        $safeEnchant = trim((string) ($_POST['safe_enchant'] ?? ''));
        $maxEnchant = trim((string) ($_POST['max_enchant'] ?? ''));
        foreach ([$safeEnchant, $maxEnchant] as $value) {
            if ($value !== '' && (!ctype_digit($value) || (int) $value < 0 || (int) $value > 100000)) {
                validationRedirect('Enchant values must be positive numbers.');
            }
        }
        if ($safeEnchant !== '' && $maxEnchant !== '' && (int) $safeEnchant > (int) $maxEnchant) {
            validationRedirect('Safe Enchant cannot be greater than Max Enchant.');
        }

        $normalEnchantRate = trim((string) ($_POST['normal_enchant_rate'] ?? ''));
        $blessedEnchantRate = trim((string) ($_POST['blessed_enchant_rate'] ?? ''));
        foreach (['Normal Enchant %' => $normalEnchantRate, 'Blessed Enchant %' => $blessedEnchantRate] as $name => $value) {
            if ($value !== '' && (!is_numeric($value) || (float) $value < 0 || (float) $value > 100)) {
                validationRedirect($name . ' must be between 0 and 100.');
            }
        }

        $brandingAllowed = premiumBrandingAllowed($existingServer);
        $logoPath = $existingServer['logo_path'] ?? null;
        $bannerPath = $existingServer['banner_path'] ?? null;

        if (!$brandingAllowed && !isAdmin()) {
            $logoPath = null;
            $bannerPath = null;
        } else {
            try {
                $uploadedLogo = handle_image_upload('logo_file', 'public/uploads/server-branding/logos');
                if ($uploadedLogo !== null) {
                    $logoPath = $uploadedLogo;
                }
            } catch (Throwable $e) {
                validationRedirect('Premium logo upload failed: ' . $e->getMessage());
            }

            try {
                $uploadedBanner = handle_image_upload('banner_file', 'public/uploads/server-branding/headers');
                if ($uploadedBanner !== null) {
                    $bannerPath = $uploadedBanner;
                }
            } catch (Throwable $e) {
                validationRedirect('Premium header banner upload failed: ' . $e->getMessage());
            }

            $logoPath = $logoPath !== '' ? $logoPath : null;
            $bannerPath = $bannerPath !== '' ? $bannerPath : null;
        }

        return array_merge([
            'title' => $title,
            'short_description' => $short,
            'full_description' => $full,
            'chronicle' => $chronicle,
            'country' => $country !== '' ? $country : null,
            'language' => $language !== '' ? $language : null,
            'login_server_status' => 1,
            'game_server_status' => 1,
            'uptime_percent' => (float) ($existingServer['uptime_percent'] ?? 100),
            'online_players_enabled' => isset($_POST['online_players_enabled']) ? 1 : 0,
            'online_players' => isset($_POST['online_players_enabled']) ? (int) ($existingServer['online_players'] ?? 0) : null,
            'last_status_check_at' => $existingServer['last_status_check_at'] ?? null,
            'login_ip' => $loginIp !== '' ? $loginIp : null,
            'login_port' => $loginPort !== '' ? (int) $loginPort : null,
            'game_ip' => $gameIp !== '' ? $gameIp : null,
            'game_port' => $gamePort !== '' ? (int) $gamePort : null,
            'feature_gm_shop' => isset($_POST['feature_gm_shop']) ? 1 : 0,
            'feature_buffer' => isset($_POST['feature_buffer']) ? 1 : 0,
            'feature_gatekeeper' => isset($_POST['feature_gatekeeper']) ? 1 : 0,
            'safe_enchant' => $safeEnchant !== '' ? (int) $safeEnchant : null,
            'max_enchant' => $maxEnchant !== '' ? (int) $maxEnchant : null,
            'normal_enchant_rate' => $normalEnchantRate !== '' ? number_format((float) $normalEnchantRate, 2, '.', '') : null,
            'blessed_enchant_rate' => $blessedEnchantRate !== '' ? number_format((float) $blessedEnchantRate, 2, '.', '') : null,
            'logo_path' => $logoPath,
            'banner_path' => $bannerPath,
        ], $rates, $urls);
    }

    private function findOwnedOrAdminServer(int $id): ?array
    {
        if ($id < 1) {
            return null;
        }

        if (isAdmin()) {
            return db()->first("SELECT * FROM servers WHERE id = :id LIMIT 1", ['id' => $id]);
        }

        return db()->first(
            "SELECT * FROM servers WHERE id = :id AND user_id = :user_id LIMIT 1",
            ['id' => $id, 'user_id' => currentUser()['id']]
        );
    }
}
