<?php

declare(strict_types=1);

final class DashboardController
{
    public function user(): void
    {
        requireAuth();

        [$user, $servers, $globalBanners] = $this->loadUserDashboardData();

        $stats = [
            'servers' => count($servers),
            'premium' => count(array_filter($servers, static fn(array $server): bool => (int) ($server['is_premium'] ?? 0) === 1)),
            'votes' => array_sum(array_map(static fn(array $server): int => (int) ($server['raw_votes_total'] ?? 0), $servers)),
            'views' => array_sum(array_map(static fn(array $server): int => (int) ($server['views_count'] ?? 0), $servers)),
        ];

        $recentServer = $servers[0] ?? null;

        view('dashboard/user_overview', compact('user', 'servers', 'globalBanners', 'stats', 'recentServer'));
    }


    public function userServers(): void
    {
        requireAuth();

        [$user, $servers, $globalBanners] = $this->loadUserDashboardData();

        view('dashboard/user_servers', compact('user', 'servers', 'globalBanners'));
    }

    public function userBannerCodes(): void
    {
        requireAuth();

        [$user, $servers, $globalBanners] = $this->loadUserDashboardData();

        view('dashboard/user_banners', compact('user', 'servers', 'globalBanners'));
    }

    private function loadUserDashboardData(): array
    {
        $user = currentUser();
        $servers = db()->select(
            "SELECT id, title, status, is_premium, premium_until, premium_boost_type, premium_boost_value, raw_votes_total, ranking_score, views_count, uptime_percent, online_players_enabled, online_players, updated_at
             FROM servers
             WHERE user_id = :user_id
             ORDER BY id DESC",
            ['user_id' => $user['id']]
        );

        $globalBanners = [];
        ensure_global_banners_schema();

        if (db()->first("SHOW TABLES LIKE 'server_banners'")) {
            $globalBanners = db()->select(
                "SELECT id, title, image_url, size_label, sort_order, is_active
                 FROM server_banners
                 WHERE is_active = 1 AND (server_id IS NULL OR server_id = 0)
                 ORDER BY sort_order ASC, id ASC"
            );
        }

        return [$user, $servers, $globalBanners];
    }

    public function admin(): void
    {
        requireAdmin();

        $stats = [
            'users' => db()->first("SELECT COUNT(*) AS count FROM users")['count'] ?? 0,
            'servers' => db()->first("SELECT COUNT(*) AS count FROM servers")['count'] ?? 0,
            'pending' => db()->first("SELECT COUNT(*) AS count FROM servers WHERE status = 'pending'")['count'] ?? 0,
            'premium' => db()->first("SELECT COUNT(*) AS count FROM servers WHERE is_premium = 1")['count'] ?? 0,
            'votes' => db()->first("SELECT COUNT(*) AS count FROM server_votes")['count'] ?? 0,
            'banners' => db()->first("SELECT COUNT(*) AS count FROM server_banners")['count'] ?? 0,
        ];

        $pendingServers = db()->select("SELECT id, title, chronicle, status, created_at FROM servers WHERE status = 'pending' ORDER BY id DESC LIMIT 8");
        $recentServers = db()->select("SELECT id, title, status, is_premium, raw_votes_total, ranking_score, views_count, updated_at FROM servers ORDER BY id DESC LIMIT 8");
        $recentLogs = db()->select("SELECT action, target_type, target_id, created_at FROM admin_logs ORDER BY id DESC LIMIT 8");

        view('dashboard/admin_index', compact('stats', 'pendingServers', 'recentServers', 'recentLogs'));
    }

    public function adminServers(): void
    {
        requireAdmin();
        $servers = db()->select(
            "SELECT id, title, chronicle, country, status, is_premium, raw_votes_total, ranking_score, created_at
             FROM servers ORDER BY id DESC LIMIT 100"
        );
        view('dashboard/admin_servers', compact('servers'));
    }

    public function adminPremium(): void
    {
        requireAdmin();
        $servers = db()->select(
            "SELECT id, title, status, is_premium, premium_until, premium_boost_type, premium_boost_value, raw_votes_total, ranking_score, logo_path, banner_path
             FROM servers ORDER BY is_premium DESC, id DESC LIMIT 100"
        );
        $premiumPackages = db()->select("SELECT id, name, duration_days, boost_type, boost_value FROM premium_packages ORDER BY id ASC");
        view('dashboard/admin_premium', compact('servers', 'premiumPackages'));
    }

    public function adminUsers(): void
    {
        requireAdmin();
        $users = db()->select(
            "SELECT u.id, u.username, u.email, u.role, u.created_at,
                    (SELECT COUNT(*) FROM servers s WHERE s.user_id = u.id) AS server_count
             FROM users u
             ORDER BY u.id DESC LIMIT 100"
        );
        view('dashboard/admin_users', compact('users'));
    }

    public function adminBanners(): void
    {
        requireAdmin();

        ensure_global_banners_schema();

        $banners = db()->select(
            "SELECT b.id, b.server_id, b.title, b.image_url, b.size_label, b.sort_order, b.is_active, b.updated_at
             FROM server_banners b
             ORDER BY b.sort_order ASC, b.id ASC
             LIMIT 500"
        );

        view('dashboard/admin_banners', compact('banners'));
    }

    public function adminLogs(): void
    {
        requireAdmin();
        $logs = db()->select(
            "SELECT l.id, l.action, l.target_type, l.target_id, l.payload, l.created_at, u.username
             FROM admin_logs l
             LEFT JOIN users u ON u.id = l.admin_user_id
             ORDER BY l.id DESC LIMIT 150"
        );
        view('dashboard/admin_logs', compact('logs'));
    }

    public function approveServer(): void
    {
        requireAdmin(); verifyCsrf();
        $this->changeServerStatus((int) ($_POST['server_id'] ?? 0), 'approved', 'Ο server εγκρίθηκε.');
    }

    public function rejectServer(): void
    {
        requireAdmin(); verifyCsrf();
        $this->changeServerStatus((int) ($_POST['server_id'] ?? 0), 'rejected', 'Ο server απορρίφθηκε.');
    }

    public function disableServer(): void
    {
        requireAdmin(); verifyCsrf();
        $this->changeServerStatus((int) ($_POST['server_id'] ?? 0), 'disabled', 'Ο server απενεργοποιήθηκε.');
    }

    public function deleteServer(): void
    {
        requireAdmin();
        verifyCsrf();

        $serverId = (int) ($_POST['server_id'] ?? 0);
        if ($serverId < 1) {
            renderErrorPage(404, 'Μη έγκυρος server.');
        }

        $server = db()->first("SELECT id, title FROM servers WHERE id = :id LIMIT 1", ['id' => $serverId]);
        if (!$server) {
            renderErrorPage(404, 'Ο server δεν βρέθηκε.');
        }

        db()->statement("DELETE FROM servers WHERE id = :id", ['id' => $serverId]);
        logAdminAction('server_deleted', 'server', $serverId, ['title' => $server['title']]);
        $_SESSION['flash'] = 'Ο server διαγράφηκε οριστικά.';
        redirect('/admin/servers');
    }

    public function updatePremium(): void
    {
        requireAdmin();
        verifyCsrf();

        $serverId = (int) ($_POST['server_id'] ?? 0);
        if ($serverId < 1) {
            renderErrorPage(404, 'Μη έγκυρος server.');
        }

        $server = db()->first("SELECT id, title, raw_votes_total FROM servers WHERE id = :id LIMIT 1", ['id' => $serverId]);
        if (!$server) {
            renderErrorPage(404, 'Ο server δεν βρέθηκε.');
        }

        $mode = (string) ($_POST['premium_mode'] ?? 'none');
        $packageId = (int) ($_POST['package_id'] ?? 0);
        $days = max(1, (int) ($_POST['premium_days'] ?? 30));
        $boostType = validPremiumBoostType((string) ($_POST['boost_type'] ?? 'percent'));
        $boostValue = max(0, (float) ($_POST['boost_value'] ?? 10));

        if ($mode === 'package' && $packageId > 0) {
            $package = db()->first("SELECT id, duration_days, boost_type, boost_value FROM premium_packages WHERE id = :id LIMIT 1", ['id' => $packageId]);
            if (!$package) {
                validationRedirect('Το premium package δεν βρέθηκε.');
            }
            $days = (int) $package['duration_days'];
            $boostType = validPremiumBoostType((string) $package['boost_type']);
            $boostValue = (float) $package['boost_value'];
        }

        if ($mode === 'none') {
            db()->statement(
                "UPDATE servers SET is_premium = 0, premium_until = NULL, premium_boost_type = 'percent', premium_boost_value = 0.00, ranking_score = raw_votes_total, logo_path = NULL, banner_path = NULL, updated_at = NOW() WHERE id = :id",
                ['id' => $serverId]
            );
            logAdminAction('server_premium_removed', 'server', $serverId, ['title' => $server['title']]);
            $_SESSION['flash'] = 'Το premium αφαιρέθηκε.';
            redirect('/admin/premium');
        }

        $rankingScore = calculateRankingScore((int) $server['raw_votes_total'], 1, $boostType, $boostValue);
        db()->statement(
            "UPDATE servers
             SET is_premium = 1,
                 premium_until = DATE_ADD(NOW(), INTERVAL :days DAY),
                 premium_boost_type = :boost_type,
                 premium_boost_value = :boost_value,
                 ranking_score = :ranking_score,
                 updated_at = NOW()
             WHERE id = :id",
            [
                'id' => $serverId,
                'days' => $days,
                'boost_type' => $boostType,
                'boost_value' => number_format($boostValue, 2, '.', ''),
                'ranking_score' => number_format($rankingScore, 2, '.', ''),
            ]
        );

        logAdminAction('server_premium_updated', 'server', $serverId, ['title' => $server['title'], 'days' => $days, 'boost_type' => $boostType, 'boost_value' => $boostValue]);
        $_SESSION['flash'] = 'Το premium ενημερώθηκε.';
        redirect('/admin/premium');
    }

    private function changeServerStatus(int $serverId, string $status, string $flash): void
    {
        if ($serverId < 1) {
            renderErrorPage(404, 'Μη έγκυρος server.');
        }

        $server = db()->first("SELECT id, title FROM servers WHERE id = :id LIMIT 1", ['id' => $serverId]);
        if (!$server) {
            renderErrorPage(404, 'Ο server δεν βρέθηκε.');
        }

        db()->statement("UPDATE servers SET status = :status, updated_at = NOW() WHERE id = :id", ['status' => $status, 'id' => $serverId]);
        logAdminAction('server_status_changed', 'server', $serverId, ['status' => $status, 'title' => $server['title']]);
        $_SESSION['flash'] = $flash;
        redirect('/admin/servers');
    }


    public function adminBannerUpload(): void
    {
        requireAdmin();
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            redirect('/admin/banners');
        }
        verifyCsrf();

        $title = trim((string) ($_POST['title'] ?? ''));
        $sizeLabel = trim((string) ($_POST['size_label'] ?? ''));
        $sortOrder = (int) ($_POST['sort_order'] ?? 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        ensure_global_banners_schema();

        try {
            $imagePath = handle_image_upload('banner_image', 'public/uploads/server-banners');
            if (!$imagePath) {
                throw new RuntimeException('Please upload a banner image.');
            }

            db()->statement(
                "INSERT INTO server_banners (server_id, title, image_url, size_label, sort_order, is_active, created_at, updated_at)
                 VALUES (NULL, :title, :image_url, :size_label, :sort_order, :is_active, NOW(), NOW())",
                [
                    'title' => $title !== '' ? $title : 'Global Vote Banner',
                    'image_url' => $imagePath,
                    'size_label' => $sizeLabel !== '' ? $sizeLabel : 'Custom',
                    'sort_order' => $sortOrder,
                    'is_active' => $isActive,
                ]
            );

            if (db()->first("SHOW TABLES LIKE 'admin_logs'")) {
                db()->statement(
                    "INSERT INTO admin_logs (admin_user_id, action, target_type, target_id, details, created_at)
                     VALUES (:admin_user_id, :action, :target_type, :target_id, :details, NOW())",
                    [
                        'admin_user_id' => (int) (currentUser()['id'] ?? 0),
                        'action' => 'global_banner_upload',
                        'target_type' => 'banner',
                        'target_id' => 0,
                        'details' => 'Uploaded global banner for all servers',
                    ]
                );
            }

            $_SESSION['flash'] = 'Global banner uploaded successfully. It is now available to all servers.';
        } catch (Throwable $e) {
            $_SESSION['flash'] = $e->getMessage();
        }

        redirect('/admin/banners');
    }


    public function adminBannerDelete(): void
    {
        requireAdmin();
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            redirect('/admin/banners');
        }
        verifyCsrf();

        $id = (int) ($_POST['id'] ?? 0);
        if ($id < 1) {
            $_SESSION['flash'] = 'Invalid banner.';
            redirect('/admin/banners');
        }

        $banner = db()->first("SELECT * FROM server_banners WHERE id = :id LIMIT 1", ['id' => $id]);
        if (!$banner) {
            $_SESSION['flash'] = 'Banner not found.';
            redirect('/admin/banners');
        }

        try {
            db()->statement("DELETE FROM server_banners WHERE id = :id", ['id' => $id]);

            $imagePath = (string) ($banner['image_url'] ?? '');
            if ($imagePath !== '') {
                $fullPath = base_path(ltrim($imagePath, '/'));
                if (is_file($fullPath)) {
                    @unlink($fullPath);
                }
            }

            if (db()->first("SHOW TABLES LIKE 'admin_logs'")) {
                db()->statement(
                    "INSERT INTO admin_logs (admin_user_id, action, target_type, target_id, details, created_at)
                     VALUES (:admin_user_id, :action, :target_type, :target_id, :details, NOW())",
                    [
                        'admin_user_id' => (int) (currentUser()['id'] ?? 0),
                        'action' => 'banner_delete',
                        'target_type' => 'banner',
                        'target_id' => $id,
                        'details' => 'Deleted global banner #' . $id,
                    ]
                );
            }

            $_SESSION['flash'] = 'Banner deleted successfully.';
        } catch (Throwable $e) {
            $_SESSION['flash'] = 'Banner deletion failed: ' . $e->getMessage();
        }

        redirect('/admin/banners');
    }


    public function adminPlugins(): void
    {
        requireAdmin();
        ensureModulesTable();
        syncModulesRegistry();

        $modules = db()->select(
            "SELECT *
             FROM modules
             ORDER BY FIELD(type, 'core', 'plugin'), name ASC"
        );

        $migrationCount = db()->first("SELECT COUNT(*) AS count FROM module_migrations")['count'] ?? 0;

        $moduleStats = [
            'total' => count($modules),
            'enabled' => count(array_filter($modules, static fn(array $module): bool => (int) ($module['is_enabled'] ?? 0) === 1)),
            'core' => count(array_filter($modules, static fn(array $module): bool => (string) ($module['type'] ?? '') === 'core')),
            'external' => count(array_filter($modules, static fn(array $module): bool => (string) ($module['source'] ?? '') === 'external')),
        ];

        view('dashboard/admin_plugins', compact('modules', 'moduleStats', 'migrationCount'));
    }

    public function toggleModule(): void
    {
        requireAdmin();
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            redirect('/admin/plugins');
        }
        verifyCsrf();

        ensureModulesTable();
        syncModulesRegistry();

        $moduleKey = trim((string) ($_POST['module_key'] ?? ''));
        if ($moduleKey === '') {
            $_SESSION['flash'] = 'Invalid module.';
            redirect('/admin/plugins');
        }

        $module = db()->first("SELECT * FROM modules WHERE module_key = :module_key LIMIT 1", [
            'module_key' => $moduleKey,
        ]);

        if (!$module) {
            $_SESSION['flash'] = 'Module not found.';
            redirect('/admin/plugins');
        }

        if ((int) ($module['is_locked'] ?? 0) === 1) {
            $_SESSION['flash'] = 'This core module is locked and cannot be disabled.';
            redirect('/admin/plugins');
        }

        $newState = (int) ($module['is_enabled'] ?? 0) === 1 ? 0 : 1;

        db()->statement(
            "UPDATE modules SET is_enabled = :is_enabled, updated_at = NOW() WHERE module_key = :module_key",
            [
                'module_key' => $moduleKey,
                'is_enabled' => $newState,
            ]
        );

        if (db()->first("SHOW TABLES LIKE 'admin_logs'")) {
            db()->statement(
                "INSERT INTO admin_logs (admin_user_id, action, target_type, target_id, details, created_at)
                 VALUES (:admin_user_id, :action, :target_type, :target_id, :details, NOW())",
                [
                    'admin_user_id' => (int) (currentUser()['id'] ?? 0),
                    'action' => 'module_toggle',
                    'target_type' => 'module',
                    'target_id' => 0,
                    'details' => sprintf('%s => %s', $moduleKey, $newState === 1 ? 'enabled' : 'disabled'),
                ]
            );
        }

        $_SESSION['flash'] = 'Module status updated successfully.';
        redirect('/admin/plugins');
    }



    public function uploadPlugin(): void
    {
        requireAdmin();
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            redirect('/admin/plugins');
        }
        verifyCsrf();

        ensureModulesTable();
        ensureModuleMigrationsTable();

        if (!isset($_FILES['plugin_zip']) || !is_array($_FILES['plugin_zip'])) {
            $_SESSION['flash'] = 'No plugin ZIP file was uploaded.';
            redirect('/admin/plugins');
        }

        $file = $_FILES['plugin_zip'];
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $_SESSION['flash'] = 'Plugin upload failed.';
            redirect('/admin/plugins');
        }

        $originalName = (string) ($file['name'] ?? 'plugin.zip');
        if (strtolower(pathinfo($originalName, PATHINFO_EXTENSION)) !== 'zip') {
            $_SESSION['flash'] = 'Only ZIP plugin packages are allowed.';
            redirect('/admin/plugins');
        }

        $tempBase = pluginUploadTempPath() . '/' . bin2hex(random_bytes(8));
        $zipPath = $tempBase . '.zip';
        $extractDir = $tempBase . '_extract';

        if (!@move_uploaded_file((string) $file['tmp_name'], $zipPath)) {
            $_SESSION['flash'] = 'Could not store the uploaded ZIP file.';
            redirect('/admin/plugins');
        }

        try {
            $zip = new ZipArchive();
            if ($zip->open($zipPath) !== true) {
                throw new RuntimeException('Could not open the plugin ZIP archive.');
            }

            @mkdir($extractDir, 0775, true);
            if (!$zip->extractTo($extractDir)) {
                $zip->close();
                throw new RuntimeException('Could not extract the plugin ZIP archive.');
            }
            $zip->close();

            $entries = array_values(array_filter(scandir($extractDir) ?: [], static fn(string $entry): bool => !in_array($entry, ['.', '..'], true)));
            $pluginRoot = $extractDir;

            if (count($entries) === 1 && is_dir($extractDir . '/' . $entries[0])) {
                $pluginRoot = $extractDir . '/' . $entries[0];
            }

            if (!is_file($pluginRoot . '/plugin.json')) {
                throw new RuntimeException('plugin.json was not found in the uploaded package.');
            }

            $result = installOrUpdatePluginFromDirectory($pluginRoot);

            if (db()->first("SHOW TABLES LIKE 'admin_logs'")) {
                db()->statement(
                    "INSERT INTO admin_logs (admin_user_id, action, target_type, target_id, details, created_at)
                     VALUES (:admin_user_id, :action, :target_type, :target_id, :details, NOW())",
                    [
                        'admin_user_id' => (int) (currentUser()['id'] ?? 0),
                        'action' => $result['installed'] ? 'plugin_install' : 'plugin_update',
                        'target_type' => 'plugin',
                        'target_id' => 0,
                        'details' => ($result['installed'] ? 'Installed ' : 'Updated ') . (string) ($result['manifest']['key'] ?? 'plugin'),
                    ]
                );
            }

            $_SESSION['flash'] = $result['installed']
                ? 'Plugin installed successfully.'
                : 'Plugin updated successfully.';
        } catch (Throwable $e) {
            $_SESSION['flash'] = 'Plugin upload/install failed: ' . $e->getMessage();
        }

        if (is_file($zipPath)) {
            @unlink($zipPath);
        }
        if (is_dir($extractDir)) {
            recursiveDeleteDirectory($extractDir);
        }

        redirect('/admin/plugins');
    }

    public function uninstallPlugin(): void
    {
        requireAdmin();
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            redirect('/admin/plugins');
        }
        verifyCsrf();

        ensureModulesTable();
        ensureModuleMigrationsTable();

        $moduleKey = trim((string) ($_POST['module_key'] ?? ''));
        $deleteFiles = isset($_POST['delete_files']) && (string) $_POST['delete_files'] === '1';

        if ($moduleKey === '') {
            $_SESSION['flash'] = 'Invalid plugin.';
            redirect('/admin/plugins');
        }

        $module = db()->first("SELECT * FROM modules WHERE module_key = :module_key LIMIT 1", ['module_key' => $moduleKey]);
        if (!$module) {
            $_SESSION['flash'] = 'Plugin not found.';
            redirect('/admin/plugins');
        }

        try {
            uninstallPluginModule($module, $deleteFiles);

            if (db()->first("SHOW TABLES LIKE 'admin_logs'")) {
                db()->statement(
                    "INSERT INTO admin_logs (admin_user_id, action, target_type, target_id, details, created_at)
                     VALUES (:admin_user_id, :action, :target_type, :target_id, :details, NOW())",
                    [
                        'admin_user_id' => (int) (currentUser()['id'] ?? 0),
                        'action' => 'plugin_uninstall',
                        'target_type' => 'plugin',
                        'target_id' => 0,
                        'details' => 'Uninstalled ' . $moduleKey . ($deleteFiles ? ' with file deletion' : ''),
                    ]
                );
            }

            $_SESSION['flash'] = 'Plugin uninstalled successfully.';
        } catch (Throwable $e) {
            $_SESSION['flash'] = 'Plugin uninstall failed: ' . $e->getMessage();
        }

        redirect('/admin/plugins');
    }



    public function adminUpdater(): void
    {
        requireAdmin();
        ensureCoreUpdaterTables();

        $updates = db()->select(
            "SELECT * FROM core_update_logs ORDER BY id DESC LIMIT 50"
        );

        view('dashboard/admin_updater', compact('updates'));
    }

    public function uploadCoreUpdate(): void
    {
        requireAdmin();
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            redirect('/admin/updater');
        }
        verifyCsrf();

        ensureCoreUpdaterTables();

        if (!isset($_FILES['core_update_zip']) || !is_array($_FILES['core_update_zip'])) {
            $_SESSION['flash'] = 'No core update ZIP file was uploaded.';
            redirect('/admin/updater');
        }

        $file = $_FILES['core_update_zip'];
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $_SESSION['flash'] = 'Core update upload failed.';
            redirect('/admin/updater');
        }

        $originalName = (string) ($file['name'] ?? 'core-update.zip');
        if (strtolower(pathinfo($originalName, PATHINFO_EXTENSION)) !== 'zip') {
            $_SESSION['flash'] = 'Only ZIP core update packages are allowed.';
            redirect('/admin/updater');
        }

        $storage = coreUpdateStoragePath();
        $incoming = $storage . '/incoming/' . bin2hex(random_bytes(8)) . '.zip';

        if (!@move_uploaded_file((string) $file['tmp_name'], $incoming)) {
            $_SESSION['flash'] = 'Could not store the uploaded core update package.';
            redirect('/admin/updater');
        }

        try {
            $result = applyCoreUpdatePackage($incoming, (int) (currentUser()['id'] ?? 0));

            if (db()->first("SHOW TABLES LIKE 'admin_logs'")) {
                db()->statement(
                    "INSERT INTO admin_logs (admin_user_id, action, target_type, target_id, details, created_at)
                     VALUES (:admin_user_id, :action, :target_type, :target_id, :details, NOW())",
                    [
                        'admin_user_id' => (int) (currentUser()['id'] ?? 0),
                        'action' => 'core_update_applied',
                        'target_type' => 'core_update',
                        'target_id' => (int) ($result['log_id'] ?? 0),
                        'details' => 'Applied core update ' . (string) ($result['manifest']['name'] ?? 'package') . ' v' . (string) ($result['manifest']['version'] ?? ''),
                    ]
                );
            }

            $_SESSION['flash'] = 'Core update applied successfully. Backup: ' . (string) ($result['backup_path'] ?? 'created');
        } catch (Throwable $e) {
            $_SESSION['flash'] = 'Core update failed: ' . $e->getMessage();
        }

        if (is_file($incoming)) {
            @unlink($incoming);
        }

        redirect('/admin/updater');
    }

}
