<?php

declare(strict_types=1);

final class HomeController
{
    public function index(): void
    {
        $premiumServers = [];
        $topServers = [];
        $latestServers = [];

        try {
            $premiumServers = db()->select(
                "SELECT id, title, short_description, chronicle, xp_rate, banner_path, logo_path, raw_votes_total, ranking_score, status
                 FROM servers
                 WHERE status = 'approved' AND is_premium = 1
                 ORDER BY featured_order ASC, ranking_score DESC, id DESC
                 LIMIT 6"
            );

            $topServers = db()->select(
                "SELECT id, title, chronicle, xp_rate, raw_votes_total, ranking_score, is_premium, status
                 FROM servers
                 WHERE status = 'approved'
                 ORDER BY ranking_score DESC, raw_votes_total DESC, id DESC
                 LIMIT 10"
            );

            $latestServers = db()->select(
                "SELECT id, title, short_description, chronicle, xp_rate, created_at, is_premium, raw_votes_total, ranking_score, status
                 FROM servers
                 WHERE status = 'approved'
                 ORDER BY id DESC
                 LIMIT 8"
            );
        } catch (Throwable $e) {
            // Fresh install without data should still render.
        }

        view('home', compact('premiumServers', 'topServers', 'latestServers'));
    }
}
