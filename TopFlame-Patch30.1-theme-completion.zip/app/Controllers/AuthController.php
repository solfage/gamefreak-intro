<?php

declare(strict_types=1);

final class AuthController
{
    public function loginForm(): void
    {
        view('auth/login');
    }

    public function login(): void
    {
        verifyCsrf();

        $email = trim((string) ($_POST['email'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $ip = clientIp();

        enforceRateLimit('login', strtolower($email) . '|' . $ip, 6, 900, 'Πολλές προσπάθειες login. Δοκίμασε ξανά αργότερα.', '/login');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
            $_SESSION['flash'] = 'Λάθος email ή κωδικός.';
            redirect('/login');
        }

        $user = db()->first("SELECT * FROM users WHERE email = :email LIMIT 1", ['email' => $email]);

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $_SESSION['flash'] = 'Λάθος email ή κωδικός.';
            redirect('/login');
        }

        session_regenerate_id(true);
        regenerateCsrfToken();
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'role' => $user['role'],
        ];

        redirect($user['role'] === 'admin' ? '/admin' : '/dashboard');
    }

    public function registerForm(): void
    {
        view('auth/register');
    }

    public function register(): void
    {
        verifyCsrf();

        $username = trim((string) ($_POST['username'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $ip = clientIp();

        enforceRateLimit('register', strtolower($email) . '|' . $ip, 4, 3600, 'Πολλές προσπάθειες εγγραφής. Δοκίμασε ξανά αργότερα.', '/register');

        if ($username === '' || strlen($username) < 3 || strlen($username) > 50 || !preg_match('/^[\p{L}\p{N}_\- ]+$/u', $username)) {
            $_SESSION['flash'] = 'Το username πρέπει να έχει 3-50 έγκυρους χαρακτήρες.';
            redirect('/register');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
            $_SESSION['flash'] = 'Συμπλήρωσε σωστά τα στοιχεία. Ο κωδικός πρέπει να είναι τουλάχιστον 8 χαρακτήρες.';
            redirect('/register');
        }

        $exists = db()->first("SELECT id FROM users WHERE email = :email LIMIT 1", ['email' => $email]);
        if ($exists) {
            $_SESSION['flash'] = 'Το email υπάρχει ήδη.';
            redirect('/register');
        }

        db()->statement(
            "INSERT INTO users (username, email, password_hash, role, status, created_at, updated_at)
             VALUES (:username, :email, :password_hash, 'user', 'active', NOW(), NOW())",
            [
                'username' => $username,
                'email' => $email,
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            ]
        );

        $_SESSION['flash'] = 'Ο λογαριασμός δημιουργήθηκε.';
        redirect('/login');
    }

    public function logout(): void
    {
        verifyCsrf();
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], (bool) $params['secure'], (bool) $params['httponly']);
        }

        session_destroy();
        session_start();
        regenerateCsrfToken();
        $_SESSION['flash'] = 'Έγινε αποσύνδεση.';
        redirect('/');
    }
}
