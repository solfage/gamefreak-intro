Advanced Theme Engine integrated into this project.
Admin path: /admin/themes
