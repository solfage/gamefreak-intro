# Lineage 2 Private Servers Starter

Gaming private-server portal starter built with plain PHP + MySQL.

## Included
- Public homepage
- Server listing page
- Server details page
- Login/register pages
- User dashboard
- Admin dashboard
- Internal vote system schema
- Premium server fields
- Installer wizard
- Automatic first admin account creation
- SQL schema import during install

## Requirements
- PHP 8.1+
- MySQL 8+ or MariaDB 10.4+
- Apache or Nginx
- PDO MySQL extension enabled

## Installation
1. Upload files to your server.
2. Point the webroot to the project root or use the included `.htaccess`.
3. Open `/installer/` in the browser.
4. Fill in:
   - Database host/name/user/password
   - Site name / base URL
   - Admin username/email/password
5. Finish installation.
6. Delete or keep the installer locked via `storage/installed.lock`.

## Default routes
- `/` home
- `/servers`
- `/server?id=1`
- `/login`
- `/register`
- `/dashboard`
- `/admin`

## Notes
- This is a clean starter foundation, not a finished production product.
- Voting, premium placement, and admin moderation are scaffolded in the schema and starter UI so the project can be expanded quickly.


## Patch 3 additions
- Search and filter on /servers
- Admin premium management on /admin
- Installer environment diagnostics
